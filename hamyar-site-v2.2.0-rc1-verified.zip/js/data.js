import { bulkPut, get, getAll, put, remove } from './db.js?v=2.2.0-rc1';

export const APP_VERSION = '2.2.0-rc1';
export const CURRENT_USER_ID = 'teacher-1';

export function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export const DEFAULT_YEAR = '405/406';

const defaultSettings = {
  selectedYear: DEFAULT_YEAR,
  selectedSchoolId: null,
  selectedClassId: null,
  currentMonth: 'مهر',
  theme: 'light',
  onboardingDone: false,
  apiBase: '',
};

function normalizeYear(value) {
  const raw = String(value || '').replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)));
  if (/^\d{3}\/\d{3}$/.test(raw)) return raw;
  if (/1405|۱۴۰۵/.test(String(value))) return '405/406';
  if (/1406|۱۴۰۶/.test(String(value))) return '406/407';
  return DEFAULT_YEAR;
}

export async function ensureSeed() {
  const seeded = await get('meta', 'seeded');
  if (!seeded) {
    await put('meta', { key: 'profile', value: { id: CURRENT_USER_ID, name: '', role: 'teacher', roleLabel: 'دبیر کار و فناوری' } });
    await put('meta', { key: 'settings', value: defaultSettings });
    await put('meta', { key: 'localAdmin', value: { enabled: false, managerName: '', pinHash: '', createdAt: null } });
    await put('meta', { key: 'seeded', value: { version: APP_VERSION, createdAt: new Date().toISOString() } });
    return;
  }

  const settingsMeta = await get('meta', 'settings');
  const settings = { ...defaultSettings, ...(settingsMeta?.value || {}) };
  settings.selectedYear = normalizeYear(settings.selectedYear || settings.schoolYear);
  settings.theme = settings.theme === 'dark' ? 'dark' : 'light';
  await put('meta', { key: 'settings', value: settings });

  const profileMeta = await get('meta', 'profile');
  if (!profileMeta?.value) await put('meta', { key: 'profile', value: { id: CURRENT_USER_ID, name: '', role: 'teacher', roleLabel: 'دبیر کار و فناوری' } });
  if (!await get('meta', 'localAdmin')) await put('meta', { key: 'localAdmin', value: { enabled: false, managerName: '', pinHash: '', createdAt: null } });

  const schools = await getAll('schools');
  if (schools.length) {
    await bulkPut('schools', schools.map((item, index) => ({
      ...item,
      code: item.code || `SCH-${String(index + 1).padStart(3, '0')}`,
      schoolYear: normalizeYear(item.schoolYear),
      active: item.active !== false,
    })));
  }

  const classes = await getAll('classes');
  if (classes.length) {
    await bulkPut('classes', classes.map((item, index) => ({
      ...item,
      code: item.code || `CLS-${String(index + 1).padStart(3, '0')}`,
      schoolYear: normalizeYear(item.schoolYear),
      active: item.active !== false,
    })));
  }

  const classMap = new Map((await getAll('classes')).map(item => [item.id, item]));
  const students = await getAll('students');
  if (students.length) {
    await bulkPut('students', students.map((item, index) => {
      const cls = classMap.get(item.classId) || {};
      return {
        ...item,
        schoolId: item.schoolId || cls.schoolId || '',
        schoolYear: normalizeYear(item.schoolYear || cls.schoolYear),
        studentCode: item.studentCode || `${cls.code || 'CLS'}-${String(index + 1).padStart(3, '0')}`,
        active: item.active !== false,
      };
    }));
  }

  const assessments = await getAll('assessments');
  if (assessments.length) {
    await bulkPut('assessments', assessments.map(item => ({
      ...item,
      schoolYear: normalizeYear(item.schoolYear || classMap.get(item.classId)?.schoolYear),
      month: item.month || 'مهر',
      score: Number(item.score ?? item.finalScore ?? item.baseScore ?? 0),
    })));
  }

  for (const id of ['channel-demo-1', 'channel-demo-2', 'content-1', 'content-2', 'podcast-1', 'podcast-2']) {
    await remove(id.startsWith('channel') ? 'channels' : 'content', id);
  }

  await put('meta', { key: 'seeded', value: { ...(seeded.value || {}), version: APP_VERSION, migratedAt: new Date().toISOString() } });
}

export async function readModel() {
  const [
    schools, classes, students, sessions, attendance, assessments, content, media,
    approvals, audit, favorites, channels, follows, structureRequests, comments,
    reactions, syncQueue, profileMeta, settingsMeta, adminMeta,
  ] = await Promise.all([
    getAll('schools'), getAll('classes'), getAll('students'), getAll('sessions'),
    getAll('attendance'), getAll('assessments'), getAll('content'), getAll('media'),
    getAll('approvals'), getAll('audit'), getAll('favorites'), getAll('channels'),
    getAll('follows'), getAll('structureRequests'), getAll('comments'), getAll('reactions'),
    getAll('syncQueue'), get('meta', 'profile'), get('meta', 'settings'), get('meta', 'localAdmin'),
  ]);
  return {
    schools, classes, students, sessions, attendance, assessments, content, media,
    approvals, audit, favorites, channels, follows, structureRequests, comments,
    reactions, syncQueue,
    profile: profileMeta?.value || { id: CURRENT_USER_ID, name: '', role: 'teacher', roleLabel: 'دبیر کار و فناوری' },
    settings: { ...defaultSettings, ...(settingsMeta?.value || {}) },
    localAdmin: adminMeta?.value || { enabled: false, managerName: '', pinHash: '' },
  };
}

export async function saveSettings(settings) {
  await put('meta', { key: 'settings', value: settings });
}

export async function saveProfile(profile) {
  await put('meta', { key: 'profile', value: profile });
}

export async function saveLocalAdmin(localAdmin) {
  await put('meta', { key: 'localAdmin', value: localAdmin });
}
