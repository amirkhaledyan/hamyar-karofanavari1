export const PERSIAN_MONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
export const PERSIAN_WEEKDAYS = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];

const div = (a, b) => ~~(a / b);
const mod = (a, b) => a - ~~(a / b) * b;

function jalCal(jy) {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  const bl = breaks.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = breaks[0];
  let jump = 0;
  if (jy < jp || jy >= breaks[bl - 1]) throw new Error('سال شمسی خارج از محدوده پشتیبانی است.');
  for (let i = 1; i < bl; i += 1) {
    const jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

function g2d(gy, gm, gd) {
  let d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4)
    + div(153 * mod(gm + 9, 12) + 2, 5)
    + gd - 34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn) {
  let j = 4 * jdn + 139361631;
  j += div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

function j2d(jy, jm, jd) {
  const r = jalCal(jy);
  return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
}

function d2j(jdn) {
  const g = d2g(jdn);
  let jy = g.gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(g.gy, 3, r.march);
  let k = jdn - jdn1f;
  let jm;
  let jd;
  if (k >= 0) {
    if (k <= 185) {
      jm = 1 + div(k, 31);
      jd = mod(k, 31) + 1;
      return { jy, jm, jd };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  jm = 7 + div(k, 30);
  jd = mod(k, 30) + 1;
  return { jy, jm, jd };
}

export function toJalali(input = new Date()) {
  const date = input instanceof Date ? input : new Date(input);
  return d2j(g2d(date.getFullYear(), date.getMonth() + 1, date.getDate()));
}

export function toGregorian(jy, jm, jd) {
  return d2g(j2d(Number(jy), Number(jm), Number(jd)));
}

export function isLeapJalaliYear(jy) {
  return jalCal(Number(jy)).leap === 0;
}

export function jalaliMonthLength(jy, jm) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalaliYear(jy) ? 30 : 29;
}

export function pad2(value) { return String(value).padStart(2, '0'); }
export function jalaliKey(jy, jm, jd) { return `${jy}/${pad2(jm)}/${pad2(jd)}`; }

export function formatJalaliDate(input = new Date(), { withWeekday = false } = {}) {
  const { jy, jm, jd } = input instanceof Date || typeof input === 'string' ? toJalali(input) : input;
  const value = `${jy}/${pad2(jm)}/${pad2(jd)}`;
  if (!withWeekday) return value;
  const g = toGregorian(jy, jm, jd);
  const weekday = weekdayIndex(new Date(g.gy, g.gm - 1, g.gd));
  return `${PERSIAN_WEEKDAYS[weekday]} ${jd} ${PERSIAN_MONTHS[jm - 1]} ${jy}`;
}

export function weekdayIndex(date) {
  return (date.getDay() + 1) % 7;
}


export function isJalaliFriday(jy, jm, jd) {
  const g = toGregorian(jy, jm, jd);
  return new Date(g.gy, g.gm - 1, g.gd).getDay() === 5;
}

export function firstWeekdayOfJalaliMonth(jy, jm) {
  const g = toGregorian(jy, jm, 1);
  return weekdayIndex(new Date(g.gy, g.gm - 1, g.gd));
}

export function schoolYearStart(selectedYear = '405/406') {
  const start = Number(String(selectedYear).split('/')[0]);
  return 1000 + (Number.isFinite(start) ? start : 405);
}

export function assessmentJalaliYear(selectedYear, schoolMonthName) {
  const start = schoolYearStart(selectedYear);
  const monthIndex = PERSIAN_MONTHS.indexOf(schoolMonthName);
  return monthIndex >= 6 ? start : start + 1;
}

export function parseJalaliDate(value) {
  const normalized = String(value || '').replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/-/g, '/');
  const match = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(normalized.trim());
  if (!match) return null;
  const jy = Number(match[1]);
  const jm = Number(match[2]);
  const jd = Number(match[3]);
  if (jm < 1 || jm > 12 || jd < 1 || jd > jalaliMonthLength(jy, jm)) return null;
  return { jy, jm, jd, value: jalaliKey(jy, jm, jd) };
}

// تعطیلات رسمی سال ۱۴۰۵ بر پایه تقویم رسمی ایران. تعطیلی‌های موردی استانی در این فهرست نیستند.
export const OFFICIAL_HOLIDAYS_1405 = {
  '1405/01/01': 'نوروز و تعطیلی پس از عید فطر',
  '1405/01/02': 'عید نوروز',
  '1405/01/03': 'عید نوروز',
  '1405/01/04': 'عید نوروز',
  '1405/01/12': 'روز جمهوری اسلامی ایران',
  '1405/01/13': 'روز طبیعت (سیزده‌بدر)',
  '1405/01/24': 'شهادت امام جعفر صادق (ع)',
  '1405/03/03': 'شهادت امام محمد باقر (ع)',
  '1405/03/06': 'عید قربان',
  '1405/03/14': 'رحلت امام خمینی و عید غدیر',
  '1405/03/15': 'قیام ۱۵ خرداد',
  '1405/04/03': 'تاسوعا',
  '1405/04/04': 'عاشورا',
  '1405/04/14': 'تعطیلی سراسری اعلام‌شده',
  '1405/04/15': 'تعطیلی سراسری اعلام‌شده',
  '1405/05/13': 'اربعین',
  '1405/05/21': 'رحلت پیامبر و شهادت امام حسن مجتبی (ع)',
  '1405/05/22': 'شهادت امام رضا (ع)',
  '1405/05/30': 'شهادت امام حسن عسکری (ع)',
  '1405/06/08': 'ولادت پیامبر و امام صادق (ع)',
  '1405/08/22': 'شهادت حضرت فاطمه زهرا (س)',
  '1405/10/02': 'ولادت امام علی (ع) و روز پدر',
  '1405/10/16': 'مبعث پیامبر',
  '1405/11/04': 'نیمه شعبان',
  '1405/11/22': 'پیروزی انقلاب اسلامی',
  '1405/12/09': 'شهادت امام علی (ع)',
  '1405/12/19': 'عید فطر',
  '1405/12/20': 'تعطیلی پس از عید فطر',
  '1405/12/29': 'ملی‌شدن صنعت نفت',
};

export const SCHOOL_EVENTS = {
  '01/01': 'آغاز سال نو',
  '02/12': 'روز معلم',
  '04/22': 'روز فناوری اطلاعات',
  '06/31': 'آغاز هفته دفاع مقدس',
  '07/01': 'آغاز سال تحصیلی',
  '07/07': 'روز آتش‌نشانی و ایمنی',
  '08/08': 'روز نوجوان',
  '08/13': 'روز دانش‌آموز',
  '09/07': 'روز فناوری آموزشی',
  '09/16': 'روز دانشجو',
  '09/25': 'روز پژوهش',
  '10/08': 'روز سوادآموزی',
  '11/12': 'بازگشت امام خمینی به ایران',
  '11/22': 'پیروزی انقلاب اسلامی',
};

export function eventsForJalali(jy, jm, jd) {
  const key = jalaliKey(jy, jm, jd);
  const fixedKey = `${pad2(jm)}/${pad2(jd)}`;
  const events = [];
  if (OFFICIAL_HOLIDAYS_1405[key]) events.push({ title: OFFICIAL_HOLIDAYS_1405[key], holiday: true, source: 'official-1405' });
  if (SCHOOL_EVENTS[fixedKey] && SCHOOL_EVENTS[fixedKey] !== OFFICIAL_HOLIDAYS_1405[key]) events.push({ title: SCHOOL_EVENTS[fixedKey], holiday: false, source: 'school' });
  return events;
}

export function calendarMonth(jy, jm) {
  const first = firstWeekdayOfJalaliMonth(jy, jm);
  const length = jalaliMonthLength(jy, jm);
  const cells = Array.from({ length: first }, () => null);
  for (let day = 1; day <= length; day += 1) cells.push({ day, events: eventsForJalali(jy, jm, day) });
  while (cells.length % 7) cells.push(null);
  return cells;
}
