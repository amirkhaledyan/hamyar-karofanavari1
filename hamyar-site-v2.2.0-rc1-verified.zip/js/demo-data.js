import { bulkPut, get, getAll, put } from './db.js?v=2.2.0-rc1';
import { CURRENT_USER_ID } from './data.js?v=2.2.0-rc1';

export const DEMO_VERSION = '2.2.0-rc1';
export const DEMO_YEAR = '405/406';

const BOY_NAMES = ['آرمان احمدی','امیررضا محمدی','سامان کریمی','یوسف مرادی','آریا رحیمی','محمدطاها حسینی','سینا صادقی','پارسا عزیزی','شایان محمودی','متین رسولی','رضا نادری','آرش یوسفی','علی اکبری','ماهان حیدری','عرفان قادری','کیان ناصری'];
const GIRL_NAMES = ['آوا احمدی','هانا محمدی','سارا کریمی','یسنا مرادی','روناک رحیمی','نازنین حسینی','آیلین صادقی','زهرا عزیزی','باران محمودی','مبینا رسولی','الینا نادری','ستایش یوسفی','فاطمه اکبری','مهسا حیدری','نیایش قادری','رها ناصری'];
const FATHERS = ['محمد','رضا','احمد','علی','حسین','کمال','یاسر','فرهاد'];
const MONTHS = ['مهر','آبان','آذر','دی'];
const MONTH_NUMBER = { مهر: 7, آبان: 8, آذر: 9, دی: 10 };
const DOMAINS = [
  ['analysis','problemAnalysis','direct'],
  ['build','productQuality','product'],
  ['operation','correctExecution','performance'],
  ['professional','responsibility','process'],
];

function levelScore(level) {
  return { 1: 12, 2: 15, 3: 17, 4: 19 }[level] || 17;
}

function deterministicLevel(schoolIndex, classIndex, studentIndex, monthIndex, recordIndex) {
  const value = (schoolIndex * 7 + classIndex * 5 + studentIndex * 3 + monthIndex * 2 + recordIndex) % 10;
  if (value <= 1) return 2;
  if (value >= 8) return 4;
  return 3;
}

function dateFor(month, recordIndex, studentIndex) {
  const day = 5 + recordIndex * 7 + (studentIndex % 3);
  return `1405/${String(MONTH_NUMBER[month]).padStart(2,'0')}/${String(day).padStart(2,'0')}`;
}

function demoSchools() {
  return [
    { id: 'demo-school-boys-1', code: 'DEMO-B-101', name: 'مدرسه پسرانه روستایی سروستان (آزمایشی)', province: 'کردستان', district: 'دهگلان', village: 'سروستان', gender: 'پسرانه', schoolYear: DEMO_YEAR, active: true, demo: true },
    { id: 'demo-school-boys-2', code: 'DEMO-B-202', name: 'مدرسه پسرانه روستایی چشمه‌سفید (آزمایشی)', province: 'کردستان', district: 'دهگلان', village: 'چشمه‌سفید', gender: 'پسرانه', schoolYear: DEMO_YEAR, active: true, demo: true },
    { id: 'demo-school-girls-1', code: 'DEMO-G-303', name: 'مدرسه دخترانه روستایی بهارستان (آزمایشی)', province: 'کردستان', district: 'دهگلان', village: 'بهارستان', gender: 'دخترانه', schoolYear: DEMO_YEAR, active: true, demo: true },
  ];
}

function demoClasses() {
  return [
    { id: 'demo-class-701', schoolId: 'demo-school-boys-1', code: 'DEMO-701', title: '۷۰۱', grade: 'هفتم', gender: 'پسرانه', schoolYear: DEMO_YEAR, active: true, demo: true, activityWeight: 4 },
    { id: 'demo-class-801', schoolId: 'demo-school-boys-1', code: 'DEMO-801', title: '۸۰۱', grade: 'هشتم', gender: 'پسرانه', schoolYear: DEMO_YEAR, active: true, demo: true, activityWeight: 3 },
    { id: 'demo-class-702', schoolId: 'demo-school-boys-2', code: 'DEMO-702', title: '۷۰۲', grade: 'هفتم', gender: 'پسرانه', schoolYear: DEMO_YEAR, active: true, demo: true, activityWeight: 2 },
    { id: 'demo-class-901', schoolId: 'demo-school-boys-2', code: 'DEMO-901', title: '۹۰۱', grade: 'نهم', gender: 'پسرانه', schoolYear: DEMO_YEAR, active: true, demo: true, activityWeight: 1 },
    { id: 'demo-class-703', schoolId: 'demo-school-girls-1', code: 'DEMO-703', title: '۷۰۳', grade: 'هفتم', gender: 'دخترانه', schoolYear: DEMO_YEAR, active: true, demo: true, activityWeight: 4 },
    { id: 'demo-class-803', schoolId: 'demo-school-girls-1', code: 'DEMO-803', title: '۸۰۳', grade: 'هشتم', gender: 'دخترانه', schoolYear: DEMO_YEAR, active: true, demo: true, activityWeight: 2 },
  ];
}

function buildStudents(classes) {
  const students = [];
  classes.forEach((cls, classIndex) => {
    const names = cls.gender === 'دخترانه' ? GIRL_NAMES : BOY_NAMES;
    names.forEach((name, studentIndex) => {
      students.push({
        id: `${cls.id}-student-${String(studentIndex + 1).padStart(2,'0')}`,
        classId: cls.id,
        schoolId: cls.schoolId,
        schoolYear: cls.schoolYear,
        name,
        studentCode: `${cls.code}-${String(studentIndex + 1).padStart(2,'0')}`,
        nationalId: '',
        fatherName: FATHERS[(studentIndex + classIndex) % FATHERS.length],
        birthDate: `139${2 + (studentIndex % 2)}/${String(1 + (studentIndex % 9)).padStart(2,'0')}/${String(3 + (studentIndex % 23)).padStart(2,'0')}`,
        active: true,
        demo: true,
        createdAt: '2026-09-20T08:00:00.000Z',
      });
    });
  });
  return students;
}

function buildAssessments(classes, students) {
  const records = [];
  classes.forEach((cls, classIndex) => {
    const classStudents = students.filter(student => student.classId === cls.id);
    const schoolIndex = ['demo-school-boys-1','demo-school-boys-2','demo-school-girls-1'].indexOf(cls.schoolId);
    MONTHS.forEach((month, monthIndex) => {
      classStudents.forEach((student, studentIndex) => {
        const skipStudent = cls.activityWeight === 1 && studentIndex >= 11 && monthIndex >= 2;
        if (skipStudent) return;
        const recordCount = Math.max(1, cls.activityWeight - (studentIndex % 5 === 0 ? 1 : 0));
        for (let recordIndex = 0; recordIndex < recordCount; recordIndex += 1) {
          const [domain, criterion, evidenceType] = DOMAINS[(recordIndex + monthIndex) % DOMAINS.length];
          const level = deterministicLevel(schoolIndex, classIndex, studentIndex, monthIndex, recordIndex);
          const baseScore = levelScore(level);
          const bonus = (studentIndex + recordIndex + monthIndex) % 13 === 0 ? 1 : 0;
          const score = Math.min(20, baseScore + bonus);
          records.push({
            id: `${cls.id}-${month}-${studentIndex + 1}-${recordIndex + 1}`,
            batchId: `${cls.id}-${month}-${recordIndex + 1}`,
            studentId: student.id,
            classId: cls.id,
            schoolId: cls.schoolId,
            schoolYear: DEMO_YEAR,
            month,
            date: dateFor(month, recordIndex, studentIndex),
            domain,
            criterion,
            evidenceType,
            level,
            baseScore,
            bonus,
            bonusReason: bonus ? 'پیشرفت روشن در اجرای مستقل کار' : '',
            score,
            note: recordIndex === 0 ? 'ثبت آزمایشی نیمسال اول' : '',
            createdAt: `2026-${String(9 + monthIndex).padStart(2,'0')}-${String(5 + recordIndex).padStart(2,'0')}T08:00:00.000Z`,
            updatedAt: `2026-${String(9 + monthIndex).padStart(2,'0')}-${String(5 + recordIndex).padStart(2,'0')}T08:00:00.000Z`,
            createdBy: CURRENT_USER_ID,
            demo: true,
          });
        }
      });
    });
  });
  return records;
}

function buildAttendance(classes, students) {
  const rows = [];
  classes.forEach((cls, classIndex) => {
    const classStudents = students.filter(student => student.classId === cls.id);
    MONTHS.forEach((month, monthIndex) => {
      [4, 11, 18, 25].forEach((day, sessionIndex) => {
        const date = `1405/${String(MONTH_NUMBER[month]).padStart(2,'0')}/${String(day).padStart(2,'0')}`;
        rows.push({
          id: `${cls.id}-${date}`,
          classId: cls.id,
          schoolId: cls.schoolId,
          schoolYear: DEMO_YEAR,
          date,
          absentIds: classStudents.filter((_, i) => (i + classIndex + monthIndex + sessionIndex) % 19 === 0).map(item => item.id),
          lateIds: classStudents.filter((_, i) => (i + monthIndex + sessionIndex) % 23 === 0).map(item => item.id),
          updatedAt: '2027-01-20T08:00:00.000Z',
          demo: true,
        });
      });
    });
  });
  return rows;
}

function demoCommunity() {
  const channels = [
    { id: 'demo-channel-owner', ownerId: CURRENT_USER_ID, title: 'کانال پادکست امیر خالدیان (آزمایشی)', topic: 'آموزش‌های کوتاه و تجربه‌های کلاس', description: 'سه ویدیوی آزمایشی برای بررسی ثبت ویدیو، پخش و گفت‌وگوی معلمان.', createdAt: '2026-10-01T08:00:00.000Z', updatedAt: '2027-01-20T08:00:00.000Z', demo: true },
    { id: 'demo-channel-rana', ownerId: 'teacher-demo-rana', title: 'تجربه‌های کلاس روستایی', topic: 'مدیریت کلاس و پروژه‌های کم‌هزینه', description: 'تجربه‌های کوتاه از اجرای درس کار و فناوری در مدرسه‌های روستایی.', createdAt: '2026-10-04T08:00:00.000Z', updatedAt: '2027-01-14T08:00:00.000Z', demo: true },
    { id: 'demo-channel-soran', ownerId: 'teacher-demo-soran', title: 'ساخت و ایمنی', topic: 'ایمنی و ساخت', description: 'نکته‌های کاربردی برای کارگاه مدرسه.', createdAt: '2026-10-08T08:00:00.000Z', updatedAt: '2027-01-12T08:00:00.000Z', demo: true },
  ];
  const content = [
    { id: 'demo-video-safety', authorId: CURRENT_USER_ID, authorName: 'امیر خالدیان', type: 'podcast', channelId: 'demo-channel-owner', title: 'ایمنی کار با ابزار دستی', summary: 'مرور کوتاه سه نکته پیش از شروع کار عملی.', body: 'این ویدیو برای آزمایش پخش ویدیو، گفت‌وگو و نمایش کانال در نسخه آزمایشی برنامه قرار داده شده است.', mediaUrl: 'assets/demo-videos/safety-tools.mp4', mediaType: 'video', posterUrl: 'assets/demo-posters/safety-tools.png', status: 'published', views: 48, likes: 17, createdAt: '2026-10-06T08:00:00.000Z', updatedAt: '2026-10-06T08:00:00.000Z', demo: true },
    { id: 'demo-video-wood', authorId: CURRENT_USER_ID, authorName: 'امیر خالدیان', type: 'podcast', channelId: 'demo-channel-owner', title: 'ساخت اتصال ساده چوبی', summary: 'نمونه کوتاه برای معرفی یک فعالیت ساختنی پایه هفتم.', body: 'در اجرای واقعی، دبیر می‌تواند ویدیوی آموزشی خود را پس از تأیید مدرسه در کانال منتشر کند.', mediaUrl: 'assets/demo-videos/wood-joint.mp4', mediaType: 'video', posterUrl: 'assets/demo-posters/wood-joint.png', status: 'published', views: 36, likes: 12, createdAt: '2026-11-10T08:00:00.000Z', updatedAt: '2026-11-10T08:00:00.000Z', demo: true },
    { id: 'demo-video-review', authorId: CURRENT_USER_ID, authorName: 'امیر خالدیان', type: 'podcast', channelId: 'demo-channel-owner', title: 'بررسی یک پروژه دانش‌آموزی', summary: 'نمونه ثبت بازخورد بر پایه معیار نمره‌دهی و میزان انجام کار.', body: 'این قسمت نشان می‌دهد چگونه می‌توان بازخورد روشن و قابل ثبت برای دانش‌آموز آماده کرد.', mediaUrl: 'assets/demo-videos/project-review.mp4', mediaType: 'video', posterUrl: 'assets/demo-posters/project-review.png', status: 'published', views: 64, likes: 23, createdAt: '2026-12-14T08:00:00.000Z', updatedAt: '2026-12-14T08:00:00.000Z', demo: true },
    { id: 'demo-experience-rana', authorId: 'teacher-demo-rana', authorName: 'رعنا محمدی', type: 'experience', channelId: 'demo-channel-rana', title: 'تقسیم ابزار در کلاس کم‌امکانات', summary: 'گروه‌ها را بر پایه ایستگاه کاری چرخشی سازمان‌دهی کردم تا زمان انتظار کمتر شود.', body: 'چهار ایستگاه ساختم و برای هر گروه زمان مشخص گذاشتم. گروهی که منتظر ابزار بود، فرم طراحی را کامل می‌کرد.', status: 'published', views: 82, likes: 31, createdAt: '2026-12-20T08:00:00.000Z', updatedAt: '2026-12-20T08:00:00.000Z', demo: true },
    { id: 'demo-question-soran', authorId: 'teacher-demo-soran', authorName: 'سوران احمدی', type: 'question', channelId: 'demo-channel-soran', title: 'برای نمره‌دادن به کار گروهی چه روشی بهتر بوده است؟', summary: 'به‌دنبال یک روش کوتاه برای جداکردن سهم واقعی هر دانش‌آموز از نتیجه گروه هستم.', body: 'در کلاس‌های شلوغ، ثبت سهم فردی دشوار است. تجربه شما چیست؟', status: 'published', views: 55, likes: 14, createdAt: '2027-01-06T08:00:00.000Z', updatedAt: '2027-01-06T08:00:00.000Z', demo: true },
  ];
  const comments = [
    { id: 'demo-comment-1', contentId: 'demo-experience-rana', authorId: CURRENT_USER_ID, authorName: 'امیر خالدیان', body: 'ایده ایستگاه چرخشی برای کلاس‌های کم‌ابزار بسیار کاربردی است.', createdAt: '2026-12-21T08:00:00.000Z', status: 'published', demo: true },
    { id: 'demo-comment-2', contentId: 'demo-question-soran', authorId: 'teacher-demo-rana', authorName: 'رعنا محمدی', body: 'من یک ثبت فردی کوتاه در پایان کار گروهی انجام می‌دهم و از هر دانش‌آموز یک توضیح یک‌دقیقه‌ای می‌خواهم.', createdAt: '2027-01-07T08:00:00.000Z', status: 'published', demo: true },
    { id: 'demo-comment-3', contentId: 'demo-video-review', authorId: 'teacher-demo-soran', authorName: 'سوران احمدی', body: 'نمایش نمره پایه و دلیل تشویقی برای توضیح به دانش‌آموز بسیار روشن است.', createdAt: '2026-12-15T08:00:00.000Z', status: 'published', demo: true },
  ];
  const follows = [
    { id: 'demo-follow-rana', channelId: 'demo-channel-rana', userId: CURRENT_USER_ID, createdAt: '2026-12-01T08:00:00.000Z', demo: true },
  ];
  return { channels, content, comments, follows };
}

export async function ensureDemoData() {
  const seeded = await get('meta', 'demoSeed');
  if (seeded?.value?.version === DEMO_VERSION) return false;
  const existingSchools = await getAll('schools');
  const schools = demoSchools();
  const classes = demoClasses();
  const students = buildStudents(classes);
  const assessments = buildAssessments(classes, students);
  const attendance = buildAttendance(classes, students);
  const community = demoCommunity();

  await bulkPut('schools', schools);
  await bulkPut('classes', classes);
  await bulkPut('students', students);
  await bulkPut('assessments', assessments);
  await bulkPut('attendance', attendance);
  await bulkPut('channels', community.channels);
  await bulkPut('content', community.content);
  await bulkPut('comments', community.comments);
  await bulkPut('follows', community.follows);

  const profileMeta = await get('meta', 'profile');
  if (!profileMeta?.value?.name) await put('meta', { key: 'profile', value: { id: CURRENT_USER_ID, name: 'امیر خالدیان', role: 'teacher', roleLabel: 'دبیر کار و فناوری' } });
  const settingsMeta = await get('meta', 'settings');
  const settings = { ...(settingsMeta?.value || {}), selectedYear: DEMO_YEAR, currentMonth: 'دی', onboardingDone: true, demoMode: true };
  if (!existingSchools.length || !settings.selectedSchoolId) settings.selectedSchoolId = schools[0].id;
  if (!settings.selectedClassId || !classes.some(item => item.id === settings.selectedClassId)) settings.selectedClassId = classes[0].id;
  await put('meta', { key: 'settings', value: settings });
  await put('meta', { key: 'demoSeed', value: { version: DEMO_VERSION, seededAt: new Date().toISOString(), schools: schools.length, classes: classes.length, students: students.length, assessments: assessments.length } });
  return true;
}
