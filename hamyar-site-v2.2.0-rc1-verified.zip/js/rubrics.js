export const RUBRIC_VERSION = '2.2';

export const SCHOOL_MONTHS = ['مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند', 'فروردین', 'اردیبهشت', 'خرداد'];

export const RUBRIC_LEVELS = [
  { level: 1, title: 'نیازمند حمایت', score: 12, range: '۱۰ تا ۱۴', description: 'بدون راهنمایی نمی‌تواند کار را درست و کامل انجام دهد.' },
  { level: 2, title: 'قابل قبول', score: 15, range: '۱۴ تا ۱۶', description: 'بخش اصلی کار را انجام می‌دهد، اما هنوز به اصلاح یا یادآوری نیاز دارد.' },
  { level: 3, title: 'در حد انتظار', score: 17, range: '۱۶ تا ۱۸', description: 'کار را درست، مستقل و متناسب با هدف انجام می‌دهد.' },
  { level: 4, title: 'فراتر از انتظار', score: 19, range: '۱۸ تا ۲۰', description: 'کار را دقیق، مستقل و حرفه‌ای انجام می‌دهد و کیفیت کار را بهتر می‌کند.' },
];

export const EVIDENCE_TYPES = [
  { id: 'direct', title: 'دیدن اجرای دانش‌آموز' },
  { id: 'performance', title: 'انجام کار عملی' },
  { id: 'product', title: 'محصول، فایل یا عکس کار' },
  { id: 'defense', title: 'توضیح دانش‌آموز درباره کار' },
  { id: 'process', title: 'گزارش مراحل انجام کار' },
];

export const RUBRIC_LIBRARY = {
  analysis: {
    title: 'فهم مسئله و پیدا کردن راه‌حل',
    description: 'فهمیدن مسئله، دلیل‌آوردن و انتخاب راه‌حل مناسب',
    criteria: {
      problemAnalysis: { title: 'فهم مسئله', question: 'دانش‌آموز مسئله، هدف و محدودیت‌ها را چقدر درست فهمیده است؟' },
      reasoning: { title: 'دلیل‌آوردن', question: 'برای انتخاب یا پاسخ خود دلیل روشن و مرتبط دارد؟' },
      solution: { title: 'ارائه راه‌حل', question: 'راه‌حل او چقدر عملی، مرتبط و قابل اجراست؟' },
      defense: { title: 'توضیح کار', question: 'می‌تواند مراحل و نتیجه کار را روشن توضیح دهد؟' },
    },
  },
  build: {
    title: 'تولید و ساخت',
    description: 'کیفیت محصول، دقت و استقلال در ساخت',
    criteria: {
      productQuality: { title: 'کیفیت محصول', question: 'محصول یا نتیجه کار چقدر درست، کاربردی و قابل استفاده است؟' },
      precision: { title: 'دقت اجرا', question: 'مراحل، اندازه‌ها، اتصالات یا کد با چه میزان دقت اجرا شده‌اند؟' },
      creativity: { title: 'خلاقیت', question: 'دانش‌آموز چه انتخاب یا ایده هدفمندی به کار افزوده است؟' },
      buildProcess: { title: 'مراحل ساخت', question: 'سهم واقعی و استقلال دانش‌آموز در مراحل ساخت چقدر بوده است؟' },
    },
  },
  operation: {
    title: 'انجام درست کار',
    description: 'انجام مرحله‌ها، رعایت ایمنی و استفاده درست از ابزار',
    criteria: {
      correctExecution: { title: 'انجام درست کار', question: 'مراحل کار را چقدر درست و به ترتیب انجام داده است؟' },
      safety: { title: 'ایمنی', question: 'خطرها را می‌شناسد و اصول ایمنی را در عمل رعایت می‌کند؟' },
      toolUse: { title: 'استفاده از ابزار', question: 'ابزار یا سامانه را چقدر درست و مسئولانه استفاده می‌کند؟' },
      orderPrecision: { title: 'نظم و دقت', question: 'محیط، ابزار و نتیجه کار چقدر منظم و کنترل‌شده است؟' },
    },
  },
  professional: {
    title: 'مسئولیت و همکاری',
    description: 'مسئولیت‌پذیری، همکاری با دیگران و استفاده درست از زمان',
    criteria: {
      responsibility: { title: 'مسئولیت‌پذیری', question: 'وظیفه خود را بدون پیگیری مداوم انجام می‌دهد؟' },
      collaboration: { title: 'همکاری', question: 'در کار گروهی سهم واقعی، محترمانه و مؤثر دارد؟' },
      timeManagement: { title: 'مدیریت زمان', question: 'زمان و مراحل کار را به‌درستی مدیریت می‌کند؟' },
      documentation: { title: 'ثبت مراحل و نتیجه', question: 'مراحل، نتیجه و اصلاح‌های کار را روشن ثبت می‌کند؟' },
    },
  },
};
