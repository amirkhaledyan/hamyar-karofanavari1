const CACHE = 'hamyar-karo-v2.2.0-rc1';
const CORE_ASSETS = [
  './', './index.html', './offline.html',
  './styles.css?v=2.2.0-rc1', './manifest.webmanifest?v=2.2.0-rc1',
  './js/app.js?v=2.2.0-rc1', './js/data.js?v=2.2.0-rc1',
  './js/db.js?v=2.2.0-rc1', './js/rubrics.js?v=2.2.0-rc1',
  './js/calendar.js?v=2.2.0-rc1', './js/demo-data.js?v=2.2.0-rc1',
  './assets/icon-96.png', './assets/icon-192.png', './assets/icon-512.png',
  './assets/icon-maskable-512.png', './assets/apple-touch-icon.png',
  './assets/demo-posters/safety-tools.png', './assets/demo-posters/wood-joint.png',
  './assets/demo-posters/project-review.png',
  './assets/demo-videos/safety-tools.mp4', './assets/demo-videos/wood-joint.mp4',
  './assets/demo-videos/project-review.mp4'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE_ASSETS)));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request, { cache: 'no-store' })
        .then(response => {
          if (response.ok) caches.open(CACHE).then(cache => cache.put('./index.html', response.clone()));
          return response;
        })
        .catch(() => caches.match('./index.html').then(response => response || caches.match('./offline.html')))
    );
    return;
  }

  const isVideo = event.request.destination === 'video' || /\/assets\/demo-videos\//.test(url.pathname);
  if (isVideo) {
    event.respondWith(
      caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
        if (response.ok && response.status === 200) caches.open(CACHE).then(cache => cache.put(event.request, response.clone()));
        return response;
      }))
    );
    return;
  }

  event.respondWith(
    fetch(event.request, { cache: 'no-store' })
      .then(response => {
        if (response.ok) caches.open(CACHE).then(cache => cache.put(event.request, response.clone()));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
