from pathlib import Path
import json, re, subprocess, zipfile, csv

ROOT = Path(__file__).resolve().parents[1]
errors = []
checks = []

def ok(name, condition, detail=''):
    checks.append((name, bool(condition), detail))
    if not condition:
        errors.append(f'{name}: {detail}')

required = [
    'index.html','styles.css','manifest.webmanifest','service-worker.js','offline.html',
    'js/app.js','js/db.js','js/data.js','js/rubrics.js',
    'assets/icon-192.png','assets/icon-512.png','assets/icon-maskable-512.png',
    'templates/student_import_template.csv','templates/الگوی_ورود_دانش_آموزان_کاروفناوری.xlsx'
]
for item in required:
    ok(f'file:{item}', (ROOT/item).exists(), str(ROOT/item))

for js in ['js/app.js','js/db.js','js/data.js','js/rubrics.js','service-worker.js']:
    result = subprocess.run(['node','--check',str(ROOT/js)], capture_output=True, text=True)
    ok(f'js-syntax:{js}', result.returncode == 0, result.stderr.strip())

manifest = json.loads((ROOT/'manifest.webmanifest').read_text(encoding='utf-8'))
ok('manifest-display', manifest.get('display') == 'standalone', str(manifest.get('display')))
ok('manifest-start-url', manifest.get('start_url') == '/hamyar-karofanavari1/?source=pwa', manifest.get('start_url',''))
ok('manifest-icons', len(manifest.get('icons',[])) >= 3, str(len(manifest.get('icons',[]))))

app = (ROOT/'js/app.js').read_text(encoding='utf-8')
for marker in ['score-decision','choose-bonus','edit-assessment','structure-manager','validateRosterRows','channel-editor','toggle-follow-channel']:
    ok(f'feature:{marker}', marker in app, marker)

sw = (ROOT/'service-worker.js').read_text(encoding='utf-8')
ok('sw-version-v1.2', 'v1.2.0' in sw, 'cache version')
ok('sw-template-cache', 'templates/student_import_template.csv' in sw, 'csv cache')

with (ROOT/'templates/student_import_template.csv').open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.reader(f))
expected = {'کد مدرسه','نام مدرسه','سال تحصیلی','پایه','کد کلاس','عنوان کلاس','شناسه دانش‌آموز','نام','نام خانوادگی'}
ok('csv-required-headers', expected.issubset(set(rows[0])), ','.join(rows[0]))
ok('csv-has-samples', len(rows) >= 3, str(len(rows)))

raw_total = sum((ROOT/p).stat().st_size for p in ['index.html','styles.css','js/app.js','js/db.js','js/data.js','js/rubrics.js'])
ok('raw-shell-under-250kb', raw_total < 250_000, str(raw_total))

print(f'checks={len(checks)} passed={sum(v for _,v,_ in checks)} failed={len(errors)}')
for name, passed, detail in checks:
    print(('PASS' if passed else 'FAIL'), name, detail)
if errors:
    raise SystemExit(1)
