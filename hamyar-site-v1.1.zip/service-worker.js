const VERSION = 'hamyar-kf-v1.3.0-rc2';
const CORE = [
  './','./index.html','./offline.html','./styles.css?v=1.3.0','./manifest.webmanifest?v=1.3.0',
  './js/app.js?v=1.3.0','./js/db.js?v=1.3.0','./js/data.js?v=1.3.0','./js/rubrics.js?v=1.3.0',
  './assets/icon-96.png?v=1.3.0','./assets/icon-192.png?v=1.3.0','./assets/icon-512.png?v=1.3.0','./assets/apple-touch-icon.png?v=1.3.0','./assets/icon-maskable-512.png?v=1.3.0',
  './templates/student_import_template.csv'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(VERSION).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== location.origin) return;
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).then(response => {
      const copy = response.clone(); caches.open(VERSION).then(c => c.put('./index.html', copy)); return response;
    }).catch(() => caches.match('./index.html').then(r => r || caches.match('./offline.html'))));
    return;
  }
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (response && response.ok && ['script','style','image','manifest'].includes(event.request.destination)) {
      const copy=response.clone(); caches.open(VERSION).then(c=>c.put(event.request,copy));
    }
    return response;
  }).catch(() => caches.match('./offline.html'))));
});
self.addEventListener('message', event => { if (event.data === 'SKIP_WAITING') self.skipWaiting(); });
