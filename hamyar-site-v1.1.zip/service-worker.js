const VERSION = '2.0.0-rc2';
const STATIC_CACHE = `hamyar-static-${VERSION}`;
const RUNTIME_CACHE = `hamyar-runtime-${VERSION}`;
const APP_SHELL = [
  './',
  './index.html',
  './offline.html',
  './styles.css?v=2.0.0-rc2',
  './js/app.js?v=2.0.0-rc2',
  './js/data.js?v=2.0.0-rc2',
  './js/db.js?v=2.0.0-rc2',
  './js/rubrics.js?v=2.0.0-rc2',
  './manifest.webmanifest?v=2.0.0-rc2',
  './assets/icon-96.png?v=2.0.0-rc2',
  './assets/icon-192.png?v=2.0.0-rc2',
  './assets/icon-512.png?v=2.0.0-rc2',
  './assets/apple-touch-icon.png?v=2.0.0-rc2',
  './templates/student_import_template.csv',
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(STATIC_CACHE).then(cache => cache.addAll(APP_SHELL)));
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('hamyar-') && ![STATIC_CACHE, RUNTIME_CACHE].includes(key)).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        const cache = await caches.open(RUNTIME_CACHE);
        cache.put('./index.html', response.clone());
        return response;
      } catch {
        return await caches.match('./index.html') || await caches.match('./offline.html');
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(request);
    const network = fetch(request).then(async response => {
      if (response.ok) {
        const cache = await caches.open(RUNTIME_CACHE);
        cache.put(request, response.clone());
      }
      return response;
    }).catch(() => null);
    return cached || await network || new Response('', { status: 504, statusText: 'Offline' });
  })());
});
