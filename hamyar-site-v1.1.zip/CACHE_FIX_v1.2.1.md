# اصلاح کش نسخه ۱٫۲٫۱

- افزودن نسخه به نشانی فایل‌های CSS و JavaScript برای دورزدن کش قدیمی.
- ثبت Service Worker با updateViaCache: none.
- تغییر نام کش به v1.2.1.
- بارگذاری خودکار دوباره پس از فعال‌شدن Service Worker جدید.
- حفظ داده‌های IndexedDB و اطلاعات ثبت‌شده.
