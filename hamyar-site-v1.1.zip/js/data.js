import { bulkPut, get, getAll, put } from './db.js';

export const APP_VERSION = '1.2.1-mobile-cache-fix';
export const CURRENT_USER_ID = 'teacher-1';

function uuid() { return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
export { uuid };

function makeStudents(classId, schoolId, schoolYear, count, groupCount = 7) {
  const first = ['آرمان','آوا','امیرعلی','باران','پارسا','ترانه','سارا','سامان','علی','محمد','نگین','هلیا','یاسین','روناک','متین','نیایش','رضا','آیدا','شایان','مریم'];
  const last = ['احمدی','محمدی','مرادی','کریمی','حسینی','صادقی','عباسی','محمودی','کاظمی','رحیمی','قادری','عزیزی'];
  return Array.from({ length: count }, (_, i) => ({
    id: `${classId}-s-${i + 1}`,
    classId,
    schoolId,
    schoolYear,
    studentCode: `${schoolId}-${schoolYear}-${String(i + 1).padStart(3, '0')}`,
    nationalId: '',
    firstName: first[i % first.length],
    lastName: last[(i * 3) % last.length],
    fatherName: '',
    birthDate: '',
    code: String(i + 1).padStart(2, '0'),
    name: `${first[i % first.length]} ${last[(i * 3) % last.length]}`,
    group: `گروه ${Math.floor(i / Math.ceil(count / groupCount)) + 1}`,
    active: true,
  }));
}

export async function ensureSeed() {
  const seeded = await get('meta', 'seeded');
  if (seeded) {
    const settingsMeta = await get('meta', 'settings');
    if (settingsMeta?.value && settingsMeta.value.theme === 'system') {
      await put('meta', { key: 'settings', value: { ...settingsMeta.value, theme: 'light' } });
    }
    if (!await get('meta', 'localAdmin')) {
      await put('meta', { key: 'localAdmin', value: { enabled: false, managerName: '', pinHash: '', createdAt: null } });
    }
    const existingSchools = await getAll('schools');
    const schoolsNeedingUpgrade = existingSchools.filter(item => !item.code || !item.schoolYear);
    if (schoolsNeedingUpgrade.length) {
      await bulkPut('schools', schoolsNeedingUpgrade.map((item, index) => ({
        ...item,
        code: item.code || `SCH-${String(index + 1).padStart(3, '0')}`,
        schoolYear: item.schoolYear || '۱۴۰۵-۱۴۰۶',
        approvedLocally: item.approvedLocally ?? true,
      })));
    }
    const existingClasses = await getAll('classes');
    const classesNeedingUpgrade = existingClasses.filter(item => !item.code || !item.schoolYear);
    if (classesNeedingUpgrade.length) {
      await bulkPut('classes', classesNeedingUpgrade.map(item => ({
        ...item,
        code: item.code || item.title || item.id,
        schoolYear: item.schoolYear || '۱۴۰۵-۱۴۰۶',
        approvedLocally: item.approvedLocally ?? true,
      })));
    }
    const upgradedClasses = await getAll('classes');
    const existingStudents = await getAll('students');
    const classMap = new Map(upgradedClasses.map(item => [item.id, item]));
    const studentsNeedingUpgrade = existingStudents.filter(item => !item.studentCode || !item.schoolId || !item.schoolYear);
    if (studentsNeedingUpgrade.length) {
      await bulkPut('students', studentsNeedingUpgrade.map((item, index) => {
        const cls = classMap.get(item.classId) || {};
        return {
          ...item,
          schoolId: item.schoolId || cls.schoolId || '',
          schoolYear: item.schoolYear || cls.schoolYear || '۱۴۰۵-۱۴۰۶',
          studentCode: item.studentCode || `${cls.schoolId || 'school'}-${cls.schoolYear || '1405'}-${item.code || String(index + 1).padStart(3, '0')}`,
          nationalId: item.nationalId || '',
          firstName: item.firstName || String(item.name || '').split(' ')[0] || '',
          lastName: item.lastName || String(item.name || '').split(' ').slice(1).join(' '),
          fatherName: item.fatherName || '',
          birthDate: item.birthDate || '',
        };
      }));
    }
    const existingChannels = await getAll('channels');
    if (!existingChannels.length) {
      await bulkPut('channels', [
        { id: 'channel-demo-1', ownerId: 'teacher-demo-2', ownerName: 'مریم احمدی', title: 'کلاس‌کار؛ تجربه‌های کم‌هزینه', description: 'پادکست‌های کوتاه درباره اجرای مهارت‌ها در مدارس کم‌برخوردار.', category: 'تجربه اجرایی', status: 'published', approvalLevel: 'province', followerCount: 126, episodeCount: 8, createdAt: '2026-07-01T08:00:00Z' },
        { id: 'channel-demo-2', ownerId: 'teacher-demo-3', ownerName: 'رضا عباسی', title: '۹۰ ثانیه تا ارزشیابی بهتر', description: 'ایده‌های کوتاه برای سنجش سهم فردی، دفاع و بازخورد سریع.', category: 'ارزشیابی', status: 'published', approvalLevel: 'national', followerCount: 274, episodeCount: 12, createdAt: '2026-07-04T08:00:00Z' },
      ]);
      const existingContent = await getAll('content');
      if (!existingContent.some(item => item.type === 'podcast')) {
        await bulkPut('content', [
          { id: 'podcast-1', authorId: 'teacher-demo-2', authorName: 'مریم احمدی', channelId: 'channel-demo-1', title: 'قسمت ۸: وقتی ابزار کم است، فعالیت را چگونه گروهی کنیم؟', summary: 'یک الگوی شش‌دقیقه‌ای برای چرخش نقش‌ها و جلوگیری از بیکارماندن اعضای گروه.', body: 'این قسمت درباره تقسیم نقش در کلاس‌های پرجمعیت و کم‌امکانات است.', grade: 'همه', skill: 'مدیریت کلاس', resources: 'کم‌برخوردار', type: 'podcast', status: 'published', approvalLevel: 'province', mediaIds: [], uses: 62, reports: 14, createdAt: '2026-07-25T08:00:00Z', updatedAt: '2026-07-25T08:00:00Z' },
          { id: 'podcast-2', authorId: 'teacher-demo-3', authorName: 'رضا عباسی', channelId: 'channel-demo-2', title: 'قسمت ۱۲: نمره تشویقی را چطور مستند کنیم؟', summary: 'مرز میان تشویق مستند و نمره‌دادن سلیقه‌ای در کمتر از پنج دقیقه.', body: 'نمونه‌هایی از دلیل‌های قابل دفاع برای افزایش محدود نمره.', grade: 'همه', skill: 'ارزشیابی', resources: 'همه', type: 'podcast', status: 'published', approvalLevel: 'national', mediaIds: [], uses: 91, reports: 26, createdAt: '2026-07-27T08:00:00Z', updatedAt: '2026-07-27T08:00:00Z' },
        ]);
      }
    }
    await put('meta', { key: 'seeded', value: { ...seeded, version: APP_VERSION, migratedAt: new Date().toISOString() } });
    return;
  }
  const schoolYear = '۱۴۰۵-۱۴۰۶';
  const schools = [
    { id: 'school-1', code: 'SCH-001', name: 'دبیرستان دوره اول اندیشه', province: 'کردستان', district: 'دهگلان', resources: 'متوسط', schoolYear, approvedLocally: true },
    { id: 'school-2', code: 'SCH-002', name: 'دبیرستان دوره اول فرهنگ', province: 'کردستان', district: 'دهگلان', resources: 'برخوردار', schoolYear, approvedLocally: true },
    { id: 'school-3', code: 'SCH-003', name: 'مدرسه روستایی امید', province: 'کردستان', district: 'دهگلان', resources: 'کم‌برخوردار', schoolYear, approvedLocally: true },
  ];
  const classes = [
    { id: 'class-701', schoolId: 'school-1', schoolYear, grade: 'هفتم', code: '701', title: '۷۰۱', semester: 'first', approvedLocally: true },
    { id: 'class-802', schoolId: 'school-1', schoolYear, grade: 'هشتم', code: '802', title: '۸۰۲', semester: 'first', approvedLocally: true },
    { id: 'class-801', schoolId: 'school-2', schoolYear, grade: 'هشتم', code: '801', title: '۸۰۱', semester: 'first', approvedLocally: true },
    { id: 'class-903', schoolId: 'school-2', schoolYear, grade: 'نهم', code: '903', title: '۹۰۳', semester: 'first', approvedLocally: true },
    { id: 'class-702', schoolId: 'school-3', schoolYear, grade: 'هفتم', code: '702', title: '۷۰۲', semester: 'first', approvedLocally: true },
  ];
  const counts = [35, 34, 31, 33, 24];
  const students = classes.flatMap((c, i) => makeStudents(c.id, c.schoolId, c.schoolYear, counts[i]));
  const channels = [
    {
      id: 'channel-demo-1', ownerId: 'teacher-demo-2', ownerName: 'مریم احمدی', title: 'کلاس‌کار؛ تجربه‌های کم‌هزینه',
      description: 'پادکست‌های کوتاه درباره اجرای مهارت‌ها در مدارس کم‌برخوردار.', category: 'تجربه اجرایی',
      status: 'published', approvalLevel: 'province', followerCount: 126, episodeCount: 8, createdAt: '2026-07-01T08:00:00Z'
    },
    {
      id: 'channel-demo-2', ownerId: 'teacher-demo-3', ownerName: 'رضا عباسی', title: '۹۰ ثانیه تا ارزشیابی بهتر',
      description: 'ایده‌های کوتاه برای سنجش سهم فردی، دفاع و بازخورد سریع.', category: 'ارزشیابی',
      status: 'published', approvalLevel: 'national', followerCount: 274, episodeCount: 12, createdAt: '2026-07-04T08:00:00Z'
    },
  ];
  const content = [
    {
      id: 'content-1', authorId: 'teacher-demo-2', authorName: 'مریم احمدی', title: 'گلخانه هوشمند کم‌هزینه با بطری بازیافتی',
      summary: 'اجرای مرحله‌ای مفهوم ورودی، پردازش و خروجی در مدرسه کم‌برخوردار.', body: 'گروه‌ها ابتدا مدل دستی آبیاری را ساختند و سپس یک نمونه حسگردار را مشاهده کردند.',
      grade: 'هشتم', skill: 'ریزکنترل‌کننده‌ها', resources: 'کم‌برخوردار', type: 'experience', status: 'published', approvalLevel: 'province',
      tags: ['هوشمندسازی','کم‌هزینه','پروژه'], mediaIds: [], uses: 48, reports: 17, createdAt: '2026-07-12T08:00:00Z', updatedAt: '2026-07-12T08:00:00Z'
    },
    {
      id: 'content-2', authorId: 'teacher-demo-3', authorName: 'رضا عباسی', title: 'دفاع ۹۰ ثانیه‌ای برای سنجش سهم فردی در طراحی وب',
      summary: 'دو سؤال ثابت و یک اصلاح کوچک کد، بدون اتلاف زمان کلاس.', body: 'برای هر عضو گروه یک دفاع کوتاه و اصلاح کوچک در کد تعیین شد تا سهم واقعی مشخص شود.',
      grade: 'نهم', skill: 'طراحی وب', resources: 'متوسط', type: 'learning', status: 'published', approvalLevel: 'national',
      tags: ['طراحی وب','ارزشیابی','کار گروهی'], mediaIds: [], uses: 75, reports: 39, createdAt: '2026-07-20T08:00:00Z', updatedAt: '2026-07-20T08:00:00Z'
    },
    {
      id: 'podcast-1', authorId: 'teacher-demo-2', authorName: 'مریم احمدی', channelId: 'channel-demo-1',
      title: 'قسمت ۸: وقتی ابزار کم است، فعالیت را چگونه گروهی کنیم؟',
      summary: 'یک الگوی شش‌دقیقه‌ای برای چرخش نقش‌ها و جلوگیری از بیکارماندن اعضای گروه.',
      body: 'این قسمت درباره تقسیم نقش در کلاس‌های پرجمعیت و کم‌امکانات است.', grade: 'همه', skill: 'مدیریت کلاس',
      resources: 'کم‌برخوردار', type: 'podcast', status: 'published', approvalLevel: 'province', mediaIds: [], uses: 62, reports: 14,
      createdAt: '2026-07-25T08:00:00Z', updatedAt: '2026-07-25T08:00:00Z'
    },
    {
      id: 'podcast-2', authorId: 'teacher-demo-3', authorName: 'رضا عباسی', channelId: 'channel-demo-2',
      title: 'قسمت ۱۲: نمره تشویقی را چطور مستند کنیم؟',
      summary: 'مرز میان تشویق مستند و نمره‌دادن سلیقه‌ای در کمتر از پنج دقیقه.',
      body: 'نمونه‌هایی از دلیل‌های قابل دفاع برای افزایش محدود نمره.', grade: 'همه', skill: 'ارزشیابی',
      resources: 'همه', type: 'podcast', status: 'published', approvalLevel: 'national', mediaIds: [], uses: 91, reports: 26,
      createdAt: '2026-07-27T08:00:00Z', updatedAt: '2026-07-27T08:00:00Z'
    },
  ];
  await bulkPut('schools', schools);
  await bulkPut('classes', classes);
  await bulkPut('students', students);
  await bulkPut('channels', channels);
  await bulkPut('content', content);
  await put('meta', { key: 'profile', value: { id: CURRENT_USER_ID, name: 'امیر خالدیان', role: 'teacher', roleLabel: 'دبیر کاروفناوری' } });
  await put('meta', { key: 'settings', value: { selectedSchoolId: 'school-1', selectedClassId: 'class-701', semester: 'first', theme: 'light', liteMode: 'auto', onboardingDone: false } });
  await put('meta', { key: 'localAdmin', value: { enabled: false, managerName: '', pinHash: '', createdAt: null } });
  await put('meta', { key: 'seeded', value: true, version: APP_VERSION, createdAt: new Date().toISOString() });
}

export async function readModel() {
  const [schools, classes, students, sessions, attendance, assessments, content, media, approvals, audit, favorites, channels, follows, structureRequests, profileMeta, settingsMeta, adminMeta] = await Promise.all([
    getAll('schools'), getAll('classes'), getAll('students'), getAll('sessions'), getAll('attendance'), getAll('assessments'), getAll('content'), getAll('media'), getAll('approvals'), getAll('audit'), getAll('favorites'), getAll('channels'), getAll('follows'), getAll('structureRequests'), get('meta','profile'), get('meta','settings'), get('meta','localAdmin')
  ]);
  return { schools, classes, students, sessions, attendance, assessments, content, media, approvals, audit, favorites, channels, follows, structureRequests, profile: profileMeta?.value, settings: settingsMeta?.value, localAdmin: adminMeta?.value || { enabled: false } };
}

export async function saveSettings(settings) { await put('meta', { key: 'settings', value: settings }); }
export async function saveProfile(profile) { await put('meta', { key: 'profile', value: profile }); }
export async function saveLocalAdmin(localAdmin) { await put('meta', { key: 'localAdmin', value: localAdmin }); }

export const ROLE_FLOW = [
  { role: 'teacher', status: 'draft', next: 'school_pending', label: 'پیش‌نویس معلم' },
  { role: 'school_reviewer', status: 'school_pending', next: 'district_pending', label: 'بررسی مدرسه' },
  { role: 'district_reviewer', status: 'district_pending', next: 'province_pending', label: 'بررسی منطقه' },
  { role: 'province_reviewer', status: 'province_pending', next: 'national_pending', label: 'بررسی استان' },
  { role: 'national_reviewer', status: 'national_pending', next: 'published', label: 'تأیید کشوری' },
];

export const STATUS_LABELS = {
  draft: 'پیش‌نویس', school_pending: 'در انتظار مدرسه', district_pending: 'در انتظار منطقه', province_pending: 'در انتظار استان',
  national_pending: 'در انتظار کشوری', published: 'منتشرشده', changes_requested: 'نیازمند اصلاح', rejected: 'ردشده'
};

export function roleLabel(role) {
  return ({ teacher: 'دبیر', school_reviewer: 'بررسی‌کننده مدرسه', district_reviewer: 'راهبر منطقه', province_reviewer: 'راهبر استان', national_reviewer: 'راهبر کشوری' })[role] || role;
}
