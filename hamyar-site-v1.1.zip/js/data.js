import { bulkPut, get, getAll, put, remove } from './db.js?v=2.0.0-rc2';

export const APP_VERSION = '2.0.0-rc2';
export const CURRENT_USER_ID = 'teacher-1';

export function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

const defaultSettings = {
  selectedSchoolId: null,
  selectedClassId: null,
  semester: 'first',
  theme: 'light',
  density: 'comfortable',
  onboardingDone: false,
};

export async function ensureSeed() {
  const seeded = await get('meta', 'seeded');
  if (!seeded) {
    await put('meta', { key: 'profile', value: { id: CURRENT_USER_ID, name: 'کاربر', role: 'teacher', roleLabel: 'دبیر کار و فناوری' } });
    await put('meta', { key: 'settings', value: defaultSettings });
    await put('meta', { key: 'localAdmin', value: { enabled: false, managerName: '', pinHash: '', createdAt: null } });
    await put('meta', { key: 'seeded', value: { version: APP_VERSION, createdAt: new Date().toISOString() } });
    return;
  }

  const profileMeta = await get('meta', 'profile');
  if (!profileMeta?.value) {
    await put('meta', { key: 'profile', value: { id: CURRENT_USER_ID, name: 'کاربر', role: 'teacher', roleLabel: 'دبیر کار و فناوری' } });
  }

  const settingsMeta = await get('meta', 'settings');
  const mergedSettings = { ...defaultSettings, ...(settingsMeta?.value || {}) };
  if (mergedSettings.theme === 'system') mergedSettings.theme = 'light';
  await put('meta', { key: 'settings', value: mergedSettings });

  if (!await get('meta', 'localAdmin')) {
    await put('meta', { key: 'localAdmin', value: { enabled: false, managerName: '', pinHash: '', createdAt: null } });
  }

  const existingSchools = await getAll('schools');
  const schoolUpgrades = existingSchools.filter(item => !item.code || !item.schoolYear);
  if (schoolUpgrades.length) {
    await bulkPut('schools', schoolUpgrades.map((item, index) => ({
      ...item,
      code: item.code || `SCH-${String(index + 1).padStart(3, '0')}`,
      schoolYear: item.schoolYear || '۱۴۰۵–۱۴۰۶',
      approvedLocally: item.approvedLocally ?? true,
    })));
  }

  const existingClasses = await getAll('classes');
  const classUpgrades = existingClasses.filter(item => !item.code || !item.schoolYear);
  if (classUpgrades.length) {
    await bulkPut('classes', classUpgrades.map(item => ({
      ...item,
      code: item.code || item.title || item.id,
      schoolYear: item.schoolYear || '۱۴۰۵–۱۴۰۶',
      approvedLocally: item.approvedLocally ?? true,
    })));
  }

  const upgradedClasses = await getAll('classes');
  const classMap = new Map(upgradedClasses.map(item => [item.id, item]));
  const existingStudents = await getAll('students');
  const studentUpgrades = existingStudents.filter(item => !item.studentCode || !item.schoolId || !item.schoolYear);
  if (studentUpgrades.length) {
    await bulkPut('students', studentUpgrades.map((item, index) => {
      const cls = classMap.get(item.classId) || {};
      const parts = String(item.name || '').trim().split(/\s+/);
      return {
        ...item,
        schoolId: item.schoolId || cls.schoolId || '',
        schoolYear: item.schoolYear || cls.schoolYear || '۱۴۰۵–۱۴۰۶',
        studentCode: item.studentCode || `${cls.schoolId || 'school'}-${cls.schoolYear || '1405'}-${item.code || String(index + 1).padStart(3, '0')}`,
        nationalId: item.nationalId || '',
        firstName: item.firstName || parts[0] || '',
        lastName: item.lastName || parts.slice(1).join(' '),
        fatherName: item.fatherName || '',
        birthDate: item.birthDate || '',
        active: item.active !== false,
      };
    }));
  }

  for (const id of ['channel-demo-1', 'channel-demo-2']) await remove('channels', id);
  for (const id of ['content-1', 'content-2', 'podcast-1', 'podcast-2']) await remove('content', id);

  await put('meta', {
    key: 'seeded',
    value: {
      ...(typeof seeded.value === 'object' ? seeded.value : {}),
      version: APP_VERSION,
      migratedAt: new Date().toISOString(),
    },
  });
}

export async function readModel() {
  const [
    schools, classes, students, sessions, attendance, assessments, content, media,
    approvals, audit, favorites, channels, follows, structureRequests,
    profileMeta, settingsMeta, adminMeta,
  ] = await Promise.all([
    getAll('schools'), getAll('classes'), getAll('students'), getAll('sessions'),
    getAll('attendance'), getAll('assessments'), getAll('content'), getAll('media'),
    getAll('approvals'), getAll('audit'), getAll('favorites'), getAll('channels'),
    getAll('follows'), getAll('structureRequests'), get('meta', 'profile'),
    get('meta', 'settings'), get('meta', 'localAdmin'),
  ]);

  return {
    schools, classes, students, sessions, attendance, assessments, content, media,
    approvals, audit, favorites, channels, follows, structureRequests,
    profile: profileMeta?.value || { id: CURRENT_USER_ID, name: 'کاربر', role: 'teacher' },
    settings: { ...defaultSettings, ...(settingsMeta?.value || {}) },
    localAdmin: adminMeta?.value || { enabled: false, managerName: '', pinHash: '' },
  };
}

export async function saveSettings(settings) {
  await put('meta', { key: 'settings', value: settings });
}

export async function saveProfile(profile) {
  await put('meta', { key: 'profile', value: profile });
}

export async function saveLocalAdmin(localAdmin) {
  await put('meta', { key: 'localAdmin', value: localAdmin });
}

export const ROLE_FLOW = [
  { role: 'teacher', status: 'draft', next: 'school_pending', label: 'پیش‌نویس دبیر' },
  { role: 'school_reviewer', status: 'school_pending', next: 'district_pending', label: 'بررسی مدرسه' },
  { role: 'district_reviewer', status: 'district_pending', next: 'province_pending', label: 'بررسی منطقه' },
  { role: 'province_reviewer', status: 'province_pending', next: 'national_pending', label: 'بررسی استان' },
  { role: 'national_reviewer', status: 'national_pending', next: 'published', label: 'تأیید کشوری' },
];

export const STATUS_LABELS = {
  draft: 'پیش‌نویس',
  school_pending: 'در انتظار مدرسه',
  district_pending: 'در انتظار منطقه',
  province_pending: 'در انتظار استان',
  national_pending: 'در انتظار کشوری',
  published: 'منتشرشده',
  changes_requested: 'نیازمند اصلاح',
  rejected: 'ردشده',
};

export function roleLabel(role) {
  return ({
    teacher: 'دبیر',
    school_reviewer: 'بررسی‌کننده مدرسه',
    district_reviewer: 'راهبر منطقه',
    province_reviewer: 'راهبر استان',
    national_reviewer: 'راهبر کشوری',
  })[role] || role;
}
