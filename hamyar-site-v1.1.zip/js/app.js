import { EVIDENCE_TYPES, MONTHS, NOTE_PRESETS, RUBRIC_LEVELS, RUBRIC_LIBRARY, RUBRIC_VERSION } from './rubrics.js';
import { bulkPut, clearAll, exportDatabase, get, importDatabase, put, remove, requestPersistentStorage, storageInfo } from './db.js';
import { APP_VERSION, CURRENT_USER_ID, ensureSeed, readModel, ROLE_FLOW, roleLabel, saveLocalAdmin, saveProfile, saveSettings, STATUS_LABELS, uuid } from './data.js';

const app = document.querySelector('#app');
const toast = document.querySelector('#toast');
const fileImport = document.querySelector('#file-import');
const rosterImport = document.querySelector('#roster-import');
let installPrompt = null;
let model;
let pendingMedia = [];

const state = {
  route: 'home',
  routeStack: [],
  communityTab: 'feed',
  assessment: null,
  modal: null,
  selectedSchoolId: null,
  selectedClassId: null,
  semester: 'first',
  installAvailable: false,
  online: navigator.onLine,
  adminUnlocked: false,
  rosterPreview: null,
  contentPreset: null,
};

const esc = (value = '') => String(value).replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
}[char]));
const fa = value => String(value ?? '').replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[digit]);
const today = () => new Date().toISOString().slice(0, 10);
const fmtBytes = bytes => bytes ? `${(bytes / 1024 / 1024).toFixed(bytes > 10 * 1024 * 1024 ? 0 : 1)} مگابایت` : '۰ مگابایت';
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const classById = id => model.classes.find(item => item.id === id);
const schoolById = id => model.schools.find(item => item.id === id);
const currentClass = () => classById(state.selectedClassId) || model.classes[0];
const currentSchool = () => schoolById(state.selectedSchoolId) || schoolById(currentClass()?.schoolId) || model.schools[0];
const students = () => model.students.filter(student => student.classId === currentClass()?.id && student.active !== false);
const profile = () => model.profile;
const getRubricCriterion = (categoryKey, criterionKey) => RUBRIC_LIBRARY[categoryKey]?.criteria?.[criterionKey];
const levelInfo = level => RUBRIC_LEVELS.find(item => item.level === Number(level));
const channelById = id => model.channels.find(channel => channel.id === id);

function showToast(message, type = 'normal') {
  toast.textContent = message;
  toast.dataset.type = type;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 3000);
}

function applyDeviceMode() {
  const autoLite = (navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2);
  const queryLite = new URLSearchParams(location.search).get('lite') === '1';
  const setting = model?.settings?.liteMode || 'auto';
  const lite = queryLite || setting === 'on' || (setting === 'auto' && autoLite);
  const theme = model?.settings?.theme || 'light';
  document.documentElement.classList.toggle('lite', Boolean(lite));
  document.documentElement.dataset.power = lite ? 'lite' : 'standard';
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme === 'dark' ? 'dark' : theme === 'light' ? 'light' : 'light dark';
}

async function refresh({ renderNow = true } = {}) {
  model = await readModel();
  state.selectedSchoolId ||= model.settings?.selectedSchoolId || model.schools[0]?.id;
  const schoolClasses = model.classes.filter(item => item.schoolId === state.selectedSchoolId);
  state.selectedClassId ||= model.settings?.selectedClassId || schoolClasses[0]?.id;
  if (!schoolClasses.some(item => item.id === state.selectedClassId)) state.selectedClassId = schoolClasses[0]?.id || model.classes[0]?.id;
  state.semester = model.settings?.semester || state.semester;
  applyDeviceMode();
  if (renderNow) render();
}

function icon(name) {
  const icons = {
    home: '<path d="M3 11.5 12 4l9 7.5v8a1.5 1.5 0 0 1-1.5 1.5h-5v-6h-5v6h-5A1.5 1.5 0 0 1 3 19.5z"/>',
    class: '<path d="M4 5.5h16v13H4z"/><path d="M8 9h8M8 13h8"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    users: '<path d="M16 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M9.5 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8M17 11a3 3 0 1 0 0-6M21 20v-2a4 4 0 0 0-3-3.87"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    camera: '<path d="M4 7h3l1.5-2h7L17 7h3v12H4z"/><circle cx="12" cy="13" r="3.5"/>',
    mic: '<path d="M9 5a3 3 0 0 1 6 0v6a3 3 0 0 1-6 0z"/><path d="M5 10v1a7 7 0 0 0 14 0v-1M12 18v3M8 21h8"/>',
    upload: '<path d="M12 16V4m0 0L7 9m5-5 5 5M5 20h14"/>',
    download: '<path d="M12 4v12m0 0 5-5m-5 5-5-5M5 20h14"/>',
    share: '<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="m8.2 10.8 7.5-4.4m-7.5 6.8 7.5 4.4"/>',
    arrow: '<path d="m9 18 6-6-6-6"/>',
    back: '<path d="m15 18-6-6 6-6"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9z"/>',
    shield: '<path d="M12 3 20 6v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6z"/><path d="m8.5 12 2.3 2.3 4.7-5"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3m3 0-1 14H7L6 7m4 4v6m4-6v6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    edit: '<path d="M4 20h4l11-11-4-4L4 16zM13.5 6.5l4 4"/>',
    school: '<path d="M3 10 12 4l9 6M5 10v9h14v-9M9 19v-5h6v5"/>',
    podcast: '<circle cx="12" cy="12" r="2"/><path d="M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5.5 5.5a9 9 0 0 0 0 13M18.5 5.5a9 9 0 0 1 0 13"/>',
    follow: '<path d="M12 21s-7-4.6-7-10a4 4 0 0 1 7-2.7A4 4 0 0 1 19 11c0 5.4-7 10-7 10z"/>',
    file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5"/>',
  };
  return `<svg aria-hidden="true" viewBox="0 0 24 24">${icons[name] || icons.info}</svg>`;
}

function canGoBack() {
  return state.routeStack.length > 0 || state.route !== 'home';
}

function navigate(route, { replace = false } = {}) {
  if (route === state.route) return;
  if (!replace) state.routeStack.push(state.route);
  state.route = route;
  state.modal = null;
  state.assessment = null;
  history.pushState({ route }, '', `?route=${route}`);
  render();
  document.querySelector('#main-content')?.focus();
}

function goBack() {
  if (state.modal) {
    closeModal();
    return;
  }
  const previous = state.routeStack.pop();
  state.route = previous || 'home';
  history.pushState({ route: state.route }, '', `?route=${state.route}`);
  render();
}

function contextBar() {
  const school = currentSchool();
  const cls = currentClass();
  if (!school || !cls) {
    return `<button class="context-pill" data-action="structure-manager"><span><b>هنوز کلاس تعریف نشده است</b><small>مدیر محلی باید مدرسه، کلاس و فهرست دانش‌آموزان را تأیید کند.</small></span>${icon('arrow')}</button>`;
  }
  return `<button class="context-pill" data-action="context" aria-label="تغییر مدرسه و کلاس">
    <span><b>${esc(school.name)}</b><small>پایه ${esc(cls.grade)} · کلاس ${esc(cls.title)} · ${state.semester === 'first' ? 'نیمسال اول' : 'نیمسال دوم'}</small></span>${icon('arrow')}
  </button>`;
}

function render() {
  if (!model) return;
  const backButton = canGoBack() ? `<button class="icon-button" data-action="go-back" aria-label="بازگشت">${icon('back')}</button>` : `<img src="assets/icon-96.png" alt="">`;
  app.innerHTML = `<div class="app-shell">
    <header class="topbar">
      <div class="brand">${backButton}<span><b>همیار کاروفناوری</b><small>${state.online ? 'ثبت محلی آماده است' : 'آفلاین؛ ثبت روی همین گوشی ادامه دارد'}</small></span></div>
      <button class="icon-button" data-action="open-help" aria-label="راهنما">${icon('info')}</button>
    </header>
    <main id="main-content" tabindex="-1">${contextBar()}${routeView()}</main>
    ${bottomNav()}
  </div>${modalView()}`;
  bindDynamicMedia();
}

function bottomNav() {
  const items = [
    ['home', 'home', 'خانه'],
    ['class', 'class', 'کلاس'],
    ['assessment', 'check', 'ثبت'],
    ['community', 'users', 'هم‌افزایی'],
    ['settings', 'more', 'بیشتر'],
  ];
  return `<nav class="bottom-nav" aria-label="ناوبری اصلی">${items.map(([route, iconName, label]) => `
    <button data-action="navigate" data-route="${route}" class="${state.route === route ? 'active' : ''}" aria-current="${state.route === route ? 'page' : 'false'}">${icon(iconName)}<span>${label}</span></button>
  `).join('')}</nav>`;
}

function routeView() {
  if (state.route === 'class') return classView();
  if (state.route === 'assessment') return assessmentView();
  if (state.route === 'community') return communityView();
  if (state.route === 'settings') return settingsView();
  return homeView();
}

function homeView() {
  const cls = currentClass();
  if (!cls) return emptyStructureView();
  const classStudents = students();
  const records = model.assessments.filter(item => item.classId === cls.id && item.semester === state.semester);
  const todayRecords = records.filter(item => item.date === today()).length;
  const lacking = classStudents.filter(student => records.filter(item => item.studentId === student.id).length < 3).length;
  const pending = model.content.filter(item => item.authorId === CURRENT_USER_ID && !['published', 'draft'].includes(item.status)).length;
  return `<section class="hero-card">
    <div><span class="eyebrow">ثبت سریع و قابل دفاع</span><h1>رفتار را لمس کن، نمره را واضح ببین</h1><p>پیش از ذخیره، نمره پایه، تشویقی مستند و نمره نهایی در یک پنل بزرگ نمایش داده می‌شود.</p></div>
    <button class="primary-button" data-action="start-assessment" data-mode="individual">${icon('plus')} ثبت یک مشاهده</button>
  </section>
  <section class="stat-grid">
    <article><b>${fa(classStudents.length)}</b><span>دانش‌آموز</span></article>
    <article><b>${fa(todayRecords)}</b><span>ثبت امروز</span></article>
    <article><b>${fa(lacking)}</b><span>نیازمند شاهد بیشتر</span></article>
    <article><b>${fa(pending)}</b><span>محتوای در بررسی</span></article>
  </section>
  <section class="section"><div class="section-head"><div><span class="eyebrow">میان‌بُرها</span><h2>کار اصلی، بدون گشت‌وگذار اداری</h2></div></div><div class="action-grid">
    <button data-action="attendance"><span class="action-icon">ح</span><b>حضور امروز</b><small>پیش‌فرض همه حاضر</small></button>
    <button data-action="start-assessment" data-mode="group"><span class="action-icon">گ</span><b>ثبت گروهی</b><small>سطح مشترک و استثناها</small></button>
    <button data-action="start-assessment" data-mode="individual"><span class="action-icon">ف</span><b>ثبت فردی</b><small>نمره پایه + تشویقی</small></button>
    <button data-action="new-content" data-type="experience"><span class="action-icon">ت</span><b>اشتراک تجربه</b><small>متن، عکس، ویدیو یا صدا</small></button>
  </div></section>
  ${attentionList(records, classStudents)}
  <section class="section"><div class="section-head"><div><span class="eyebrow">پیشنهاد همکاران</span><h2>برای همین کلاس</h2></div><button class="text-button" data-action="navigate" data-route="community">همه</button></div>${contentCards(model.content.filter(item => item.status === 'published').slice(0, 2))}</section>`;
}

function emptyStructureView() {
  return `<section class="hero-card"><div><span class="eyebrow">شروع پایلوت</span><h1>اول ساختار مدرسه را وارد کن</h1><p>مدرسه، پایه، کلاس و فهرست دانش‌آموزان پس از تأیید مدیر محلی روی این گوشی ثبت می‌شوند.</p></div><button class="primary-button" data-action="structure-manager">${icon('school')} مدیریت ساختار</button></section>`;
}

function attentionList(records, classStudents) {
  const items = classStudents.map(student => ({ student, count: records.filter(item => item.studentId === student.id).length }))
    .sort((a, b) => a.count - b.count).slice(0, 4);
  return `<section class="section"><div class="section-head"><div><span class="eyebrow">پوشش سنجش</span><h2>این دانش‌آموزان را از قلم نینداز</h2></div></div><div class="student-list">${items.map(({ student, count }) => `
    <button class="student-row" data-action="assess-student" data-id="${student.id}"><span class="avatar">${esc(student.name.trim().charAt(0))}</span><span><b>${esc(student.name)}</b><small>${esc(student.group || 'بدون گروه')} · ${fa(count)} شاهد</small></span><span class="status ${count >= 3 ? 'ok' : 'warn'}">${count >= 3 ? 'کافی' : 'نیازمند ثبت'}</span></button>
  `).join('')}</div></section>`;
}

function classView() {
  const cls = currentClass();
  if (!cls) return emptyStructureView();
  const classStudents = students();
  const records = model.assessments.filter(item => item.classId === cls.id && item.semester === state.semester);
  return `<section class="page-head"><span class="eyebrow">کلاس جاری</span><h1>${esc(cls.grade)} · ${esc(cls.title)}</h1><p>${fa(classStudents.length)} دانش‌آموز؛ هر دانش‌آموز با شناسه یکتا از ثبت تکراری محافظت می‌شود.</p></section>
  <div class="segmented"><button class="active">دانش‌آموزان</button><button data-action="attendance">حضور</button><button data-action="class-report">نمرات</button><button data-action="structure-manager">مدیریت</button></div>
  <div class="search-wrap"><input id="student-search" type="search" placeholder="جست‌وجوی نام یا شناسه دانش‌آموز" aria-label="جست‌وجوی دانش‌آموز"><button class="clear-search" data-action="clear-search" aria-label="پاک کردن">×</button></div>
  <div class="student-list" id="student-list">${classStudents.map(student => {
    const own = records.filter(item => item.studentId === student.id);
    const average = own.length ? own.reduce((sum, item) => sum + Number(item.score || 0), 0) / own.length : null;
    return `<button class="student-row" data-action="student-detail" data-id="${student.id}" data-search="${esc(`${student.name} ${student.studentCode || ''}`)}"><span class="avatar">${esc(student.name.charAt(0))}</span><span><b>${esc(student.name)}</b><small>${esc(student.group || 'بدون گروه')} · شناسه ${esc(student.studentCode || student.code || '—')}</small></span><span class="score-badge">${average !== null ? fa(average.toFixed(1)) : '—'}</span></button>`;
  }).join('')}</div>`;
}

function assessmentView() {
  const cls = currentClass();
  if (!cls) return emptyStructureView();
  const recent = model.assessments.filter(item => item.classId === cls.id).sort((a, b) => b.updatedAt?.localeCompare(a.updatedAt || '') || b.createdAt.localeCompare(a.createdAt)).slice(0, 12);
  return `<section class="page-head"><span class="eyebrow">ثبت هدایت‌شده</span><h1>نمره قبل از ثبت روشن است</h1><p>سطح روبریک نمره پایه را می‌سازد؛ در ثبت فردی حداکثر دو نمره تشویقی با دلیل مستند قابل افزودن است.</p></section>
  <div class="assessment-mode-grid">
    <button data-action="start-assessment" data-mode="individual"><span>ف</span><b>دانش‌آموز</b><small>نمره پایه + تشویقی</small></button>
    <button data-action="start-assessment" data-mode="group"><span>گ</span><b>گروه</b><small>سطح مشترک + استثنا</small></button>
    <button data-action="start-assessment" data-mode="class"><span>ک</span><b>کل کلاس</b><small>ثبت سریع یک معیار</small></button>
  </div>
  <section class="section"><div class="section-head"><div><span class="eyebrow">آخرین ثبت‌ها</span><h2>برای مشاهده یا ویرایش لمس کن</h2></div></div><div class="timeline">${recent.length ? recent.map(item => {
    const student = model.students.find(person => person.id === item.studentId);
    return `<button data-action="assessment-detail" data-id="${item.id}"><span>${esc(item.date)}</span><div><b>${esc(student?.name || 'دانش‌آموز')} · ${esc(item.criterion)}</b><small>${esc(item.descriptor)}</small></div><strong>${fa(item.score)}</strong></button>`;
  }).join('') : '<div class="empty">هنوز ثبتی وجود ندارد.</div>'}</div></section>`;
}

function communityView() {
  const tabs = [
    ['feed', 'برای من'],
    ['tools', 'ایده و انگیزه'],
    ['podcasts', 'پادکست‌ها'],
    ['mine', 'محتوای من'],
    ['review', 'صف بررسی'],
  ];
  return `<section class="community-hero"><div><span class="eyebrow">شبکه حرفه‌ای معلمان</span><h1>تجربه‌ای که قابل اجرا و قابل اعتماد است</h1><p>کانال پادکستی، پرسش حرفه‌ای و تجربه آموزشی همگی تابع قوانین و تأیید مرحله‌ای پلتفرم هستند.</p></div><button class="primary-button" data-action="new-content" data-type="experience">${icon('plus')} انتشار محتوا</button></section>
  <div class="tab-strip" role="tablist">${tabs.map(([id, label]) => `<button role="tab" aria-selected="${state.communityTab === id}" class="${state.communityTab === id ? 'active' : ''}" data-action="community-tab" data-tab="${id}">${label}</button>`).join('')}</div>
  ${communityTabView()}`;
}

function communityTabView() {
  if (state.communityTab === 'mine') {
    return `<div class="community-actions"><button class="primary-button" data-action="new-content" data-type="experience">${icon('plus')} محتوای تازه</button><button class="ghost-button" data-action="manage-channel">${icon('podcast')} کانال من</button></div>${contentCards(model.content.filter(item => item.authorId === CURRENT_USER_ID), true)}`;
  }
  if (state.communityTab === 'review') {
    const flow = ROLE_FLOW.find(item => item.role === profile().role);
    const queue = flow ? model.content.filter(item => item.status === flow.status) : [];
    return `<div class="notice"><b>نقش فعلی: ${esc(roleLabel(profile().role))}</b><span>${flow ? `محتوای مرحله «${esc(STATUS_LABELS[flow.status])}» نمایش داده می‌شود.` : 'برای نقش دبیر، صف بررسی رسمی وجود ندارد.'}</span></div>${contentCards(queue, true)}`;
  }
  if (state.communityTab === 'podcasts') {
    const podcasts = model.content.filter(item => item.type === 'podcast' && item.status === 'published');
    return `<div class="community-actions"><button class="primary-button" data-action="new-content" data-type="podcast">${icon('mic')} قسمت تازه</button><button class="ghost-button" data-action="manage-channel">${icon('podcast')} ساخت یا ویرایش کانال</button></div>
      <div class="notice warn"><b>وضعیت نسخه آفلاین</b><span>کانال و دنبال‌کردن روی این گوشی ثبت می‌شود. شمارش و تعامل واقعی میان معلمان پس از راه‌اندازی سرور مرکزی فعال خواهد شد.</span></div>
      <section class="section"><div class="section-head"><div><span class="eyebrow">کانال‌های پیشنهادی</span><h2>انتخاب بر اساس کاربرد، نه سروصدا</h2></div></div>${channelCards(model.channels.filter(channel => channel.status === 'published' || channel.ownerId === CURRENT_USER_ID))}</section>
      <section class="section"><div class="section-head"><div><span class="eyebrow">قسمت‌های تازه</span><h2>کوتاه، روشن و قابل استفاده</h2></div></div>${contentCards(podcasts)}</section>`;
  }
  if (state.communityTab === 'tools') return communityTools();
  const cls = currentClass();
  const school = currentSchool();
  const sorted = model.content.filter(item => item.status === 'published').sort((a, b) => scoreContent(b, cls, school) - scoreContent(a, cls, school));
  return `<section class="mission-card"><span>${icon('star')}</span><div><b>مأموریت حرفه‌ای هفته</b><p>یک تجربه را در کلاس اجرا کن و سه جمله درباره نتیجه واقعی بنویس.</p></div><button data-action="new-content" data-type="experience">شروع</button></section>${contentCards(sorted)}`;
}

function communityTools() {
  const tools = [
    ['پرسش از همکاران', 'مسئله واقعی کلاس را کوتاه مطرح کن و بسته پرسش را برای حلقه حرفه‌ای بفرست.', 'question', 'پ'],
    ['چالش هفت‌روزه', 'هر روز یک مشاهده کوتاه ثبت کن و در پایان الگوی مشترک را منتشر کن.', 'experience', '۷'],
    ['ایده کم‌هزینه', 'راه‌حل‌هایی را منتشر کن که با ابزار محدود قابل اجرا باشند.', 'experience', 'ک'],
    ['پادکست پنج‌دقیقه‌ای', 'یک نکته کاربردی را به‌صورت صوت کوتاه و مرحله‌ای منتشر کن.', 'podcast', 'ص'],
    ['درخواست همکار اجرایی', 'برای طراحی مشترک محتوا یا آزمون یک ایده، همکار پیدا کن.', 'question', 'ه'],
    ['راهنمای انتشار معتبر', 'مسئله، روش، نتیجه و چیزی را که جواب نداد بنویس؛ تبلیغ و کلی‌گویی حذف می‌شود.', 'guide', 'ر'],
  ];
  return `<div class="engagement-grid">${tools.map(([title, text, type, badge]) => `<article><span>${badge}</span><h3>${title}</h3><p>${text}</p>${type === 'guide' ? `<button data-action="open-publishing-guide">راهنما</button>` : `<button data-action="new-content" data-type="${type}">شروع</button>`}</article>`).join('')}</div>`;
}

function scoreContent(content, cls, school) {
  return (content.grade === cls?.grade ? 5 : 0) + (content.resources === school?.resources ? 3 : 0) + (content.approvalLevel === 'national' ? 3 : content.approvalLevel === 'province' ? 2 : 0) + (content.reports || 0) / 20;
}

function contentTypeLabel(type) {
  return ({ experience: 'تجربه اجرایی', learning: 'محتوای آموزشی', podcast: 'پادکست', question: 'پرسش حرفه‌ای' })[type] || 'محتوا';
}

function contentCards(list, showStatus = false) {
  if (!list.length) return '<div class="empty">موردی برای نمایش وجود ندارد.</div>';
  return `<div class="content-feed">${list.map(content => {
    const channel = channelById(content.channelId);
    return `<article class="content-card"><button class="content-main" data-action="content-detail" data-id="${content.id}">
      <div class="content-meta"><span>${esc(contentTypeLabel(content.type))}</span><span>${esc(content.grade || 'همه پایه‌ها')}</span><span>${esc(content.skill || 'عمومی')}</span>${showStatus ? `<span class="workflow ${esc(content.status)}">${esc(STATUS_LABELS[content.status] || content.status)}</span>` : `<span class="verified">${content.approvalLevel === 'national' ? 'تأیید کشوری' : content.approvalLevel === 'province' ? 'بررسی استانی' : 'منتشرشده'}</span>`}</div>
      <h3>${esc(content.title)}</h3><p>${esc(content.summary)}</p>${channel ? `<small class="channel-line">از کانال ${esc(channel.title)}</small>` : ''}
      <div class="content-stats"><span>${fa(content.uses || 0)} بار استفاده</span><span>${fa(content.reports || 0)} گزارش اجرا</span><span>${esc(content.authorName || 'معلم')}</span></div>
    </button><div class="content-actions"><button data-action="favorite-content" data-id="${content.id}">${icon('star')} ذخیره</button><button data-action="use-content" data-id="${content.id}">${icon('plus')} استفاده در کلاس</button></div></article>`;
  }).join('')}</div>`;
}

function channelCards(channels) {
  if (!channels.length) return '<div class="empty">هنوز کانالی ایجاد نشده است.</div>';
  return `<div class="channel-grid">${channels.map(channel => {
    const isFollowing = model.follows.some(item => item.channelId === channel.id && item.userId === CURRENT_USER_ID);
    const localFollowers = model.follows.filter(item => item.channelId === channel.id).length;
    return `<article class="channel-card"><div class="channel-avatar">${icon('podcast')}</div><div><h3>${esc(channel.title)}</h3><p>${esc(channel.description)}</p><small>${esc(channel.ownerName)} · ${fa((channel.followerCount || 0) + localFollowers)} دنبال‌کننده · ${fa(channel.episodeCount || 0)} قسمت</small></div>${channel.ownerId === CURRENT_USER_ID ? `<button data-action="manage-channel" data-id="${channel.id}">ویرایش</button>` : `<button class="${isFollowing ? 'active' : ''}" data-action="toggle-follow-channel" data-id="${channel.id}">${isFollowing ? 'دنبال می‌کنم' : 'دنبال‌کردن'}</button>`}</article>`;
  }).join('')}</div>`;
}

function settingsView() {
  return `<section class="page-head"><span class="eyebrow">تنظیمات و داده</span><h1>کنترل اطلاعات روی گوشی</h1><p>مدیریت مدرسه و فهرست دانش‌آموزان فقط پس از بازکردن دسترسی مدیر محلی اعمال می‌شود.</p></section>
  <section class="settings-list">
    <button data-action="structure-manager"><span>${icon('school')}</span><div><b>مدرسه، کلاس و دانش‌آموزان</b><small>ورود فایل، کنترل تکرار و تأیید مدیر محلی</small></div>${icon('arrow')}</button>
    <button data-action="install"><span>${icon('download')}</span><div><b>نصب روی صفحه اصلی</b><small>${state.installAvailable ? 'آماده نصب است' : 'نسخه نصب‌شده یا گزینه مرورگر'}</small></div>${icon('arrow')}</button>
    <button data-action="export-lite"><span>${icon('share')}</span><div><b>اشتراک پشتیبان سبک</b><small>نمره‌ها و محتوا، بدون رسانه</small></div>${icon('arrow')}</button>
    <button data-action="export-full"><span>${icon('upload')}</span><div><b>پشتیبان کامل</b><small>شامل عکس، صدا و ویدیو</small></div>${icon('arrow')}</button>
    <button data-action="import"><span>${icon('download')}</span><div><b>ورود پشتیبان یا بسته محتوا</b><small>ادغام با اطلاعات فعلی</small></div>${icon('arrow')}</button>
    <button data-action="storage"><span>${icon('shield')}</span><div><b>فضای ذخیره و ماندگاری</b><small>بررسی فضا و درخواست حفاظت از داده</small></div>${icon('arrow')}</button>
    <button data-action="role"><span>${icon('users')}</span><div><b>نقش آزمایشی</b><small>${esc(roleLabel(profile().role))}؛ برای آزمون گردش تأیید</small></div>${icon('arrow')}</button>
    <button data-action="appearance"><span>${icon('star')}</span><div><b>ظاهر و خوانایی</b><small>تم، حالت سبک و اندازه متن در طراحی جدید</small></div>${icon('arrow')}</button>
    <button class="danger-row" data-action="reset"><span>${icon('trash')}</span><div><b>پاک‌کردن داده‌های آزمایشی</b><small>فقط پس از گرفتن پشتیبان</small></div>${icon('arrow')}</button>
  </section><div class="version">نسخه ${APP_VERSION} · موتور روبریک ${RUBRIC_VERSION}</div>`;
}

function modalView() {
  if (!state.modal) return '<div id="modal-root"></div>';
  const { type, payload } = state.modal;
  let title = '';
  let body = '';
  if (type === 'context') { title = 'مدرسه و کلاس'; body = contextModal(); }
  if (type === 'assessment') { title = assessmentTitle(); body = assessmentModal(); }
  if (type === 'attendance') { title = 'حضور و غیاب امروز'; body = attendanceModal(); }
  if (type === 'content-editor') { title = payload?.id ? 'ویرایش محتوا' : 'انتشار محتوا'; body = contentEditor(payload?.id); }
  if (type === 'content-detail') { title = 'جزئیات محتوا'; body = contentDetail(payload.id); }
  if (type === 'assessment-detail') { title = 'نمره و دلیل ثبت'; body = assessmentDetail(payload.id); }
  if (type === 'student-detail') { title = 'پرونده شواهد دانش‌آموز'; body = studentDetail(payload.id); }
  if (type === 'storage') { title = 'فضای ذخیره'; body = '<div id="storage-info" class="loading">در حال محاسبه…</div>'; setTimeout(loadStorageModal, 0); }
  if (type === 'role') { title = 'انتخاب نقش آزمایشی'; body = roleModal(); }
  if (type === 'appearance') { title = 'ظاهر و عملکرد'; body = appearanceModal(); }
  if (type === 'help') { title = 'راهنمای نسخه آزمایشی'; body = helpModal(); }
  if (type === 'class-report') { title = 'گزارش نمرات کلاس'; body = classReportModal(); }
  if (type === 'structure-manager') { title = 'مدیریت مدرسه و کلاس'; body = structureManagerModal(); }
  if (type === 'roster-preview') { title = 'کنترل فایل دانش‌آموزان'; body = rosterPreviewModal(); }
  if (type === 'manual-structure') { title = 'افزودن مدرسه و کلاس'; body = manualStructureModal(); }
  if (type === 'channel-editor') { title = 'کانال پادکستی من'; body = channelEditor(payload?.id); }
  if (type === 'publishing-guide') { title = 'قواعد انتشار حرفه‌ای'; body = publishingGuideModal(); }
  const modalBack = type === 'assessment' && state.assessment?.step > 1 ? `<button class="icon-button" data-action="assessment-back" aria-label="مرحله قبل">${icon('back')}</button>` : `<button class="icon-button" data-action="close-modal" aria-label="بستن">${icon('close')}</button>`;
  return `<div id="modal-root"><div class="modal-backdrop" data-action="close-modal"></div><section class="sheet" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="sheet-handle"></div><header><h2 id="modal-title">${esc(title)}</h2>${modalBack}</header><div class="sheet-body">${body}</div></section></div>`;
}

function openModal(type, payload = {}) {
  state.modal = { type, payload };
  render();
}

function closeModal() {
  state.modal = null;
  state.assessment = null;
  state.rosterPreview = null;
  render();
}

function contextModal() {
  if (!model.schools.length || !model.classes.length) return `<div class="notice warn"><b>ساختار تعریف نشده است</b><span>از بخش مدیریت ساختار، مدرسه و کلاس را وارد کن.</span></div><button class="primary-button wide" data-action="structure-manager">ورود به مدیریت ساختار</button>`;
  const selectedSchool = model.schools.find(item => item.id === state.selectedSchoolId) || model.schools[0];
  const classes = model.classes.filter(item => item.schoolId === selectedSchool.id);
  return `<div class="field"><label for="school-select">مدرسه</label><select id="school-select">${model.schools.map(school => `<option value="${school.id}" ${school.id === selectedSchool.id ? 'selected' : ''}>${esc(school.name)}</option>`).join('')}</select></div>
  <div class="field"><label for="class-select">پایه و کلاس</label><select id="class-select">${classes.map(cls => `<option value="${cls.id}" ${cls.id === state.selectedClassId ? 'selected' : ''}>پایه ${esc(cls.grade)} · ${esc(cls.title)}</option>`).join('')}</select></div>
  <div class="field"><label>نیمسال</label><div class="radio-cards"><label><input type="radio" name="semester" value="first" ${state.semester === 'first' ? 'checked' : ''}><span>نیمسال اول</span></label><label><input type="radio" name="semester" value="second" ${state.semester === 'second' ? 'checked' : ''}><span>نیمسال دوم</span></label></div></div>
  <button class="primary-button wide" data-action="save-context">تأیید کلاس</button>`;
}

function startAssessment(mode, targetId = null, editId = null) {
  const groups = [...new Set(students().map(student => student.group).filter(Boolean))];
  if (editId) {
    const record = model.assessments.find(item => item.id === editId);
    if (!record) return;
    state.assessment = {
      mode: 'individual', step: 1, startedAt: Date.now(), editId: record.id, targetId: record.studentId,
      date: record.date, month: record.month, activity: record.activity, categoryKey: record.categoryKey,
      criterionKey: record.criterionKey, level: record.level, evidenceType: record.evidenceType,
      notePreset: record.notePreset || '', note: record.note || '', bonusScore: Number(record.bonusScore || 0),
      bonusReason: record.bonusReason || '', exceptions: {},
    };
  } else {
    state.assessment = {
      mode, step: 1, startedAt: Date.now(), editId: null,
      targetId: targetId || (mode === 'individual' ? students()[0]?.id : mode === 'group' ? groups[0] : 'all'),
      date: today(), month: MONTHS[state.semester][0], activity: '', categoryKey: 'analysis', criterionKey: 'problemAnalysis',
      level: null, evidenceType: 'direct', notePreset: '', note: '', bonusScore: 0, bonusReason: '', exceptions: {},
    };
  }
  openModal('assessment');
}

function assessmentTitle() {
  if (state.assessment?.editId) return 'ویرایش نمره ثبت‌شده';
  return state.assessment?.mode === 'group' ? 'ثبت گروهی هدایت‌شده' : state.assessment?.mode === 'class' ? 'ثبت سریع کل کلاس' : 'ثبت فردی هدایت‌شده';
}

function assessmentModal() {
  const draft = state.assessment;
  if (!draft) return '';
  return `<div class="stepper"><span class="${draft.step >= 1 ? 'done' : ''}">۱</span><i></i><span class="${draft.step >= 2 ? 'done' : ''}">۲</span><i></i><span class="${draft.step >= 3 ? 'done' : ''}">۳</span></div>${draft.step === 1 ? assessmentStep1() : draft.step === 2 ? assessmentStep2() : assessmentStep3()}`;
}

function assessmentStep1() {
  const draft = state.assessment;
  const groups = [...new Set(students().map(student => student.group).filter(Boolean))];
  let target = '';
  if (draft.mode === 'individual') target = `<div class="field"><label>دانش‌آموز</label><select id="assess-target" aria-label="انتخاب دانش‌آموز">${students().map(student => `<option value="${student.id}" ${student.id === draft.targetId ? 'selected' : ''}>${esc(student.name)} · ${esc(student.studentCode || '')}</option>`).join('')}</select></div>`;
  if (draft.mode === 'group') target = `<div class="field"><label>گروه</label><select id="assess-target" aria-label="انتخاب گروه">${groups.map(group => `<option ${group === draft.targetId ? 'selected' : ''}>${esc(group)}</option>`).join('')}</select></div>`;
  const recent = [...new Set(model.assessments.filter(item => item.classId === currentClass()?.id).map(item => item.activity))].slice(-4);
  const suggested = [...new Set([...recent, ...Object.values(RUBRIC_LIBRARY).flatMap(item => item.activities)])].slice(0, 12);
  return `${target}<div class="two-col"><div class="field"><label>تاریخ</label><input id="assess-date" type="date" value="${draft.date}"></div><div class="field"><label>ماه آموزشی</label><select id="assess-month">${MONTHS[state.semester].map(month => `<option ${month === draft.month ? 'selected' : ''}>${month}</option>`).join('')}</select></div></div>
  <div class="field"><label>چه فعالیتی را مشاهده کردی؟</label><div class="choice-grid">${suggested.map(activity => `<button data-action="choose-activity" data-value="${esc(activity)}" class="${draft.activity === activity ? 'active' : ''}">${esc(activity)}</button>`).join('')}</div><input id="custom-activity" placeholder="یا عنوان کوتاه دیگری بنویس" value="${!suggested.includes(draft.activity) ? esc(draft.activity) : ''}"></div>
  <div class="modal-actions"><button class="ghost-button" data-action="close-modal">انصراف</button><button class="primary-button" data-action="assessment-next">ادامه</button></div>`;
}

function assessmentStep2() {
  const draft = state.assessment;
  const category = RUBRIC_LIBRARY[draft.categoryKey];
  return `<div class="prompt"><small>فعالیت</small><b>${esc(draft.activity)}</b></div><h3 class="question-title">هدف اصلی این مشاهده چیست؟</h3>
  <div class="category-grid">${Object.entries(RUBRIC_LIBRARY).map(([key, item]) => `<button data-action="choose-category" data-value="${key}" class="${key === draft.categoryKey ? 'active' : ''}"><span>${item.icon}</span><b>${esc(item.title)}</b><small>${esc(item.question)}</small></button>`).join('')}</div>
  <h3 class="question-title">دقیقاً چه چیزی را سنجیدی؟</h3><div class="criterion-grid">${Object.entries(category.criteria).map(([key, item]) => `<button data-action="choose-criterion" data-value="${key}" class="${key === draft.criterionKey ? 'active' : ''}"><b>${esc(item.title)}</b><small>${esc(item.question)}</small><em>${esc(item.tips[0])}</em></button>`).join('')}</div>
  <div class="modal-actions"><button class="ghost-button" data-action="assessment-back">بازگشت</button><button class="primary-button" data-action="assessment-next">دیدن رفتار و نمره</button></div>`;
}

function finalScoreFor(draft, level = draft.level) {
  const base = levelInfo(level)?.score || 0;
  const bonus = draft.mode === 'individual' ? Number(draft.bonusScore || 0) : 0;
  return clamp(base + bonus, 0, 20);
}

function assessmentStep3() {
  const draft = state.assessment;
  const criterion = getRubricCriterion(draft.categoryKey, draft.criterionKey);
  const level = Number(draft.level);
  const baseScore = levelInfo(level)?.score || 0;
  const finalScore = finalScoreFor(draft);
  const exceptionStudents = draft.mode === 'group' ? students().filter(student => student.group === draft.targetId) : draft.mode === 'class' ? students() : [];
  const bonusAllowed = draft.mode === 'individual';
  return `<div class="prompt"><small>${esc(criterion.title)}</small><b>${esc(criterion.question)}</b></div>
  <div class="behavior-grid">${RUBRIC_LEVELS.map(item => `<button data-action="choose-level" data-value="${item.level}" class="level-card level-${item.level} ${level === item.level ? 'active' : ''}"><span>${fa(item.level)}</span><div><b>${esc(item.title)}</b><p>${esc(criterion.levels[item.level])}</p><strong class="level-score">نمره پایه ${fa(item.score)} از ۲۰</strong><small>بازه توصیفی ${fa(item.range)}</small></div></button>`).join('')}</div>
  ${level ? `<section class="score-decision"><div><small>نمره پایه روبریک</small><b>${fa(baseScore)}</b></div><span>+</span><div><small>تشویقی مستند</small><b>${fa(bonusAllowed ? draft.bonusScore : 0)}</b></div><span>=</span><div class="final"><small>نمره نهایی ثبت</small><b>${fa(finalScore)}</b><em>از ۲۰</em></div></section>` : ''}
  ${level && bonusAllowed ? `<section class="bonus-panel"><h3>تشویقی مستند، حداکثر ۲ نمره</h3><p>برای تلاش یا رفتاری که در توصیف سطح دیده نشده است. انتخاب باید با دلیل کوتاه همراه باشد.</p><div class="bonus-grid">${[0, 0.5, 1, 1.5, 2].map(value => `<button data-action="choose-bonus" data-value="${value}" class="${Number(draft.bonusScore) === value ? 'active' : ''}">${value === 0 ? 'بدون تشویقی' : `+${fa(value)}`}</button>`).join('')}</div>${Number(draft.bonusScore) > 0 ? `<div class="field"><label>دلیل تشویقی</label><textarea id="bonus-reason" maxlength="180" placeholder="مثلاً: بدون درخواست معلم، خطای گروه را پیدا و روش اصلاح را توضیح داد.">${esc(draft.bonusReason)}</textarea></div>` : ''}</section>` : level ? `<div class="notice"><b>ثبت گروهی یا کلاسی</b><span>تشویقی به‌صورت جمعی اعمال نمی‌شود. پس از ثبت، پرونده هر دانش‌آموز را جداگانه ویرایش کن.</span></div>` : ''}
  <h3 class="question-title">این قضاوت بر چه شاهدی است؟</h3><div class="evidence-grid">${EVIDENCE_TYPES.map(item => `<button data-action="choose-evidence" data-value="${item.id}" class="${draft.evidenceType === item.id ? 'active' : ''}"><span>${item.icon}</span><b>${esc(item.title)}</b><small>${esc(item.hint)}</small></button>`).join('')}</div>
  <div class="field"><label>یادداشت آماده، اختیاری</label><div class="choice-grid compact">${NOTE_PRESETS.map(note => `<button data-action="choose-note" data-value="${esc(note)}" class="${draft.notePreset === note ? 'active' : ''}">${esc(note)}</button>`).join('')}</div></div>
  <div class="field"><label>توضیح تکمیلی، اختیاری</label><textarea id="assess-note" maxlength="240" placeholder="نکته‌ای که در توصیف روبریک نیست">${esc(draft.note)}</textarea></div>
  ${level && draft.mode !== 'individual' ? exceptionsEditor(exceptionStudents, level) : ''}
  <div class="reason-preview"><small>مبنای ثبت</small><p>${level ? esc(buildRationale(draft, criterion, level)) : 'پس از انتخاب رفتار، دلیل و نمره نهایی اینجا ساخته می‌شود.'}</p></div>
  <div class="modal-actions sticky-actions"><button class="ghost-button" data-action="assessment-back">بازگشت</button><button class="primary-button" data-action="save-assessment" ${level ? '' : 'disabled'}>${draft.editId ? `ذخیره ویرایش · ${fa(finalScore)}` : `ثبت نمره ${fa(finalScore)}`}</button></div>`;
}

function exceptionsEditor(classStudents, baseLevel) {
  const draft = state.assessment;
  return `<details class="exceptions"><summary>عملکرد فردی با گروه متفاوت بود؟ <span>${fa(Object.keys(draft.exceptions).length)}</span></summary><p>فقط سطح افراد متفاوت را تغییر بده. بقیه سطح ${fa(baseLevel)} می‌گیرند.</p>${classStudents.map(student => `<div class="exception-row"><span>${esc(student.name)}</span><select data-exception="${student.id}"><option value="">همان گروه</option>${RUBRIC_LEVELS.filter(item => item.level !== baseLevel).map(item => `<option value="${item.level}" ${Number(draft.exceptions[student.id]) === item.level ? 'selected' : ''}>سطح ${fa(item.level)} · نمره پایه ${fa(item.score)}</option>`).join('')}</select></div>`).join('')}</details>`;
}

function buildRationale(draft, criterion, level) {
  const levelData = levelInfo(level);
  const evidence = EVIDENCE_TYPES.find(item => item.id === draft.evidenceType);
  const base = levelData?.score || 0;
  const bonus = draft.mode === 'individual' ? Number(draft.bonusScore || 0) : 0;
  const finalScore = clamp(base + bonus, 0, 20);
  return `${criterion.title}: «${criterion.levels[level]}»؛ بر پایه ${evidence?.title || 'شاهد ثبت‌شده'}${draft.notePreset ? `، ${draft.notePreset}` : ''}. سطح ${level} (${levelData.title}) با نمره پایه ${base}${bonus > 0 ? ` و ${bonus} نمره تشویقی به دلیل «${draft.bonusReason || 'دلیل در حال تکمیل'}»` : ''}؛ نمره نهایی ${finalScore} از ۲۰ طبق ${RUBRIC_VERSION}.`;
}

function assessmentDetail(id) {
  const record = model.assessments.find(item => item.id === id);
  if (!record) return '<div class="empty">ثبت پیدا نشد.</div>';
  const student = model.students.find(item => item.id === record.studentId);
  return `<div class="evidence-detail"><div class="score-circle">${fa(record.score)}</div><h3>${esc(student?.name || 'دانش‌آموز')}</h3><div class="score-breakdown"><span>پایه <b>${fa(record.baseScore ?? levelInfo(record.level)?.score ?? record.score)}</b></span><span>تشویقی <b>${fa(record.bonusScore || 0)}</b></span><span>نهایی <b>${fa(record.score)}</b></span></div><p>${esc(record.rationale)}</p><dl><dt>فعالیت</dt><dd>${esc(record.activity)}</dd><dt>معیار</dt><dd>${esc(record.criterion)}</dd><dt>رفتار مشاهده‌شده</dt><dd>${esc(record.descriptor)}</dd><dt>نوع شاهد</dt><dd>${esc(record.evidenceTitle)}</dd>${record.bonusScore ? `<dt>دلیل تشویقی</dt><dd>${esc(record.bonusReason)}</dd>` : ''}<dt>ثبت‌کننده</dt><dd>${esc(profile().name)} · ${esc(record.date)}</dd><dt>نسخه روبریک</dt><dd>${esc(record.rubricVersion)}</dd></dl><button class="primary-button wide" data-action="edit-assessment" data-id="${record.id}">${icon('edit')} ویرایش نمره و دلیل</button></div>`;
}

function studentDetail(id) {
  const student = model.students.find(item => item.id === id);
  const records = model.assessments.filter(item => item.studentId === id && item.classId === currentClass()?.id).sort((a, b) => (b.updatedAt || b.createdAt).localeCompare(a.updatedAt || a.createdAt));
  return `<div class="student-profile"><span class="avatar big">${esc(student?.name.charAt(0))}</span><h3>${esc(student?.name || '')}</h3><p>${esc(student?.group || 'بدون گروه')} · شناسه ${esc(student?.studentCode || '—')} · ${fa(records.length)} شاهد</p></div><button class="primary-button wide" data-action="assess-student" data-id="${id}">${icon('plus')} ثبت مشاهده جدید</button><div class="timeline">${records.map(record => `<button data-action="assessment-detail" data-id="${record.id}"><span>${esc(record.date)}</span><div><b>${esc(record.criterion)}</b><small>${esc(record.descriptor)}</small></div><strong>${fa(record.score)}</strong></button>`).join('') || '<div class="empty">هنوز شاهدی ثبت نشده است.</div>'}</div>`;
}

function attendanceModal() {
  const prior = model.attendance.find(item => item.classId === currentClass()?.id && item.date === today());
  const absent = new Set(prior?.absentIds || []);
  const late = new Set(prior?.lateIds || []);
  return `<div class="notice"><b>پیش‌فرض همه حاضرند</b><span>فقط غایب‌ها و تأخیرها را مشخص کن.</span></div><div class="attendance-list">${students().map(student => `<div><span>${esc(student.name)}</span><div class="mini-segment"><label><input type="radio" name="att-${student.id}" value="present" ${!absent.has(student.id) && !late.has(student.id) ? 'checked' : ''}><span>حاضر</span></label><label><input type="radio" name="att-${student.id}" value="late" ${late.has(student.id) ? 'checked' : ''}><span>تأخیر</span></label><label><input type="radio" name="att-${student.id}" value="absent" ${absent.has(student.id) ? 'checked' : ''}><span>غایب</span></label></div></div>`).join('')}</div><button class="primary-button wide" data-action="save-attendance">ذخیره حضور امروز</button>`;
}

function classReportModal() {
  const records = model.assessments.filter(item => item.classId === currentClass()?.id && item.semester === state.semester);
  return `<div class="report-table-wrap"><table class="report-table"><thead><tr><th>دانش‌آموز</th><th>شناسه</th><th>تعداد شاهد</th><th>میانگین</th><th>آخرین نمره</th></tr></thead><tbody>${students().map(student => {
    const own = records.filter(item => item.studentId === student.id);
    const average = own.length ? own.reduce((sum, item) => sum + Number(item.score || 0), 0) / own.length : '';
    const latest = own.sort((a, b) => (b.updatedAt || b.createdAt).localeCompare(a.updatedAt || a.createdAt))[0];
    return `<tr><td>${esc(student.name)}</td><td>${esc(student.studentCode || '')}</td><td>${fa(own.length)}</td><td>${average === '' ? '—' : fa(average.toFixed(1))}</td><td>${latest ? fa(latest.score) : '—'}</td></tr>`;
  }).join('')}</tbody></table></div><button class="primary-button wide" data-action="export-class-csv">خروجی CSV نمرات</button>`;
}

function contentEditor(id) {
  const preset = state.contentPreset || 'experience';
  const content = model.content.find(item => item.id === id) || {
    title: '', summary: '', body: '', grade: currentClass()?.grade || 'همه', skill: '', resources: currentSchool()?.resources || 'همه',
    type: preset, status: 'draft', mediaIds: [], channelId: '',
  };
  const myChannels = model.channels.filter(channel => channel.ownerId === CURRENT_USER_ID);
  return `<form id="content-form"><input type="hidden" name="id" value="${esc(content.id || '')}"><div class="field"><label>نوع محتوا</label><div class="radio-cards multi"><label><input type="radio" name="type" value="experience" ${content.type === 'experience' ? 'checked' : ''}><span>تجربه</span></label><label><input type="radio" name="type" value="learning" ${content.type === 'learning' ? 'checked' : ''}><span>آموزشی</span></label><label><input type="radio" name="type" value="podcast" ${content.type === 'podcast' ? 'checked' : ''}><span>پادکست</span></label><label><input type="radio" name="type" value="question" ${content.type === 'question' ? 'checked' : ''}><span>پرسش</span></label></div></div>
  <div class="field"><label>عنوان روشن و کاربردی</label><input id="content-title" name="title" required maxlength="100" value="${esc(content.title)}" placeholder="عنوانی که مسئله و نتیجه را روشن کند"></div>
  <div class="field"><label>خلاصه یک‌خطی</label><textarea id="content-summary" name="summary" required maxlength="220" placeholder="این محتوا دقیقاً چه مشکلی را حل می‌کند؟">${esc(content.summary)}</textarea></div>
  <div class="two-col"><div class="field"><label>پایه</label><select id="content-grade" name="grade">${['هفتم','هشتم','نهم','همه'].map(value => `<option ${value === content.grade ? 'selected' : ''}>${value}</option>`).join('')}</select></div><div class="field"><label>سطح امکانات</label><select id="content-resources" name="resources">${['کم‌برخوردار','متوسط','برخوردار','همه'].map(value => `<option ${value === content.resources ? 'selected' : ''}>${value}</option>`).join('')}</select></div></div>
  <div class="field"><label>مهارت یا موضوع</label><input id="content-skill" name="skill" required maxlength="80" value="${esc(content.skill)}" placeholder="مثلاً ارزشیابی گروهی"></div>
  <div class="field"><label>کانال پادکستی، فقط برای نوع پادکست</label><select name="channelId"><option value="">بدون کانال</option>${myChannels.map(channel => `<option value="${channel.id}" ${channel.id === content.channelId ? 'selected' : ''}>${esc(channel.title)}</option>`).join('')}</select>${!myChannels.length ? `<small>ابتدا از بخش پادکست‌ها یک کانال محلی بساز.</small>` : ''}</div>
  <div class="field"><label>شرح کاربردی</label><textarea id="content-body" name="body" required maxlength="1800" rows="7" placeholder="مسئله، روش اجرا، نتیجه و چیزی که جواب نداد را بنویس.">${esc(content.body)}</textarea></div>
  <div class="media-uploader"><div><b>عکس، صوت یا ویدیو</b><small>رسانه فقط روی گوشی ذخیره می‌شود و هنگام ارسال بسته محتوا منتقل خواهد شد.</small></div><label class="upload-button">${icon('camera')} انتخاب فایل<input id="content-media" type="file" accept="image/*,audio/*,video/mp4,video/webm" multiple></label><div id="pending-media" class="pending-media"></div></div>
  <label class="privacy-check"><input type="checkbox" name="privacy" required><span>تأیید می‌کنم نام، نمره یا تصویر دانش‌آموز بدون رضایت در فایل‌ها وجود ندارد و محتوا با قوانین حرفه‌ای پلتفرم سازگار است.</span></label>
  <div class="workflow-note">پیش‌نویس معلم ← مدرسه ← منطقه ← استان ← کشوری ← انتشار</div><div class="modal-actions"><button type="button" class="ghost-button" data-action="save-content-draft">ذخیره پیش‌نویس</button><button type="button" class="primary-button" data-action="submit-content">ارسال برای تأیید</button></div></form>`;
}

function contentDetail(id) {
  const content = model.content.find(item => item.id === id);
  if (!content) return '<div class="empty">محتوا پیدا نشد.</div>';
  const channel = channelById(content.channelId);
  const approvals = model.approvals.filter(item => item.contentId === id).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  const flow = ROLE_FLOW.find(item => item.role === profile().role);
  const canReview = flow && content.status === flow.status;
  const media = content.mediaIds.map(mediaId => model.media.find(item => item.id === mediaId)).filter(Boolean);
  return `<article class="content-detail"><div class="content-meta"><span>${esc(contentTypeLabel(content.type))}</span><span>${esc(content.grade)}</span><span>${esc(content.skill)}</span><span class="workflow ${esc(content.status)}">${esc(STATUS_LABELS[content.status] || content.status)}</span></div><h2>${esc(content.title)}</h2><p class="lead">${esc(content.summary)}</p>${channel ? `<div class="notice"><b>کانال ${esc(channel.title)}</b><span>${esc(channel.description)}</span></div>` : ''}<div class="rich-text">${esc(content.body).replace(/\n/g, '<br>')}</div>${media.length ? `<div class="media-gallery">${media.map(item => mediaElement(item)).join('')}</div>` : ''}<div class="audit-flow"><h3>سابقه تأیید</h3>${approvals.map(item => `<div><b>${esc(roleLabel(item.role))}</b><span>${item.action === 'approve' ? 'تأیید' : 'اصلاح'}</span><small>${esc(item.comment || 'بدون توضیح')} · ${esc(item.createdAt.slice(0, 10))}</small></div>`).join('') || '<div class="empty">هنوز سابقه بررسی وجود ندارد.</div>'}</div>${canReview ? `<div class="review-box"><textarea id="review-comment" placeholder="توضیح بررسی"></textarea><div><button class="ghost-button" data-action="review-content" data-decision="changes" data-id="${content.id}">بازگشت برای اصلاح</button><button class="primary-button" data-action="review-content" data-decision="approve" data-id="${content.id}">تأیید مرحله</button></div></div>` : ''}${content.authorId === CURRENT_USER_ID ? `<div class="content-actions full"><button data-action="edit-content" data-id="${content.id}">${icon('edit')} ویرایش</button><button data-action="share-content-package" data-id="${content.id}">${icon('share')} بسته بررسی</button></div>` : ''}</article>`;
}

function mediaElement(media) {
  if (media.type?.startsWith('image/')) return `<button data-action="open-media" data-id="${media.id}"><img data-media-id="${media.id}" alt="رسانه آموزشی"></button>`;
  if (media.type?.startsWith('audio/')) return `<audio controls data-media-id="${media.id}"></audio>`;
  return `<video controls preload="metadata" data-media-id="${media.id}"></video>`;
}

function channelEditor(id) {
  const channel = model.channels.find(item => item.id === id) || model.channels.find(item => item.ownerId === CURRENT_USER_ID) || { title: '', description: '', category: 'تجربه اجرایی' };
  return `<div class="notice"><b>قانون کانال</b><span>هر قسمت باید مسئله آموزشی روشن، محتوای غیرتبلیغاتی، رعایت حریم دانش‌آموز و مسیر تأیید مرحله‌ای داشته باشد.</span></div><input type="hidden" id="channel-id" value="${esc(channel.id || '')}"><div class="field"><label>نام کانال</label><input id="channel-title" maxlength="80" value="${esc(channel.title)}" placeholder="مثلاً کلاس‌کار"></div><div class="field"><label>توضیح کوتاه</label><textarea id="channel-description" maxlength="260" placeholder="این کانال درباره چه مسئله‌ای است؟">${esc(channel.description)}</textarea></div><div class="field"><label>موضوع اصلی</label><select id="channel-category">${['تجربه اجرایی','ارزشیابی','فناوری آموزشی','مدیریت کلاس','مهارت‌های کاروفناوری'].map(value => `<option ${value === channel.category ? 'selected' : ''}>${value}</option>`).join('')}</select></div><button class="primary-button wide" data-action="save-channel">ذخیره کانال محلی</button><div class="notice warn"><b>محدودیت پایلوت آفلاین</b><span>کانال روی همین گوشی ساخته می‌شود. انتشار و دنبال‌کننده واقعی بین کاربران به سرور و حساب رسمی نیاز دارد.</span></div>`;
}

function publishingGuideModal() {
  return `<div class="help-steps"><div><span>۱</span><p><b>مسئله مشخص</b>یک مشکل واقعی کلاس را تعریف کن، نه شعار درباره آموزش.</p></div><div><span>۲</span><p><b>روش قابل تکرار</b>زمان، پایه، امکانات و مراحل اجرا را بنویس.</p></div><div><span>۳</span><p><b>نتیجه و شکست</b>چه چیزی جواب داد و چه چیزی جواب نداد؟ این بخش اعتماد می‌سازد.</p></div><div><span>۴</span><p><b>حریم دانش‌آموز</b>نام، نمره و تصویر بدون رضایت منتشر نشود.</p></div><div><span>۵</span><p><b>تأیید مرحله‌ای</b>محتوا پیش از انتشار عمومی از مدرسه تا سطح تعیین‌شده بررسی می‌شود.</p></div></div>`;
}

function roleModal() {
  const roles = ['teacher', 'school_reviewer', 'district_reviewer', 'province_reviewer', 'national_reviewer'];
  return `<div class="radio-list">${roles.map(role => `<label><input type="radio" name="role" value="${role}" ${profile().role === role ? 'checked' : ''}><span><b>${esc(roleLabel(role))}</b><small>${role === 'teacher' ? 'تولید و ارسال محتوا' : 'بررسی مرحله مربوط و ثبت سابقه'}</small></span></label>`).join('')}</div><div class="notice warn"><b>فقط برای پایلوت محلی</b><span>این تغییر نقش احراز هویت سازمانی نیست.</span></div><button class="primary-button wide" data-action="save-role">ذخیره نقش</button>`;
}

function appearanceModal() {
  const settings = model.settings;
  return `<div class="field"><label>حالت نمایش</label><select id="theme-select"><option value="light" ${settings.theme === 'light' ? 'selected' : ''}>روشن</option><option value="system" ${settings.theme === 'system' ? 'selected' : ''}>مطابق گوشی</option><option value="dark" ${settings.theme === 'dark' ? 'selected' : ''}>تیره</option></select></div><div class="field"><label>عملکرد</label><select id="lite-select"><option value="auto" ${settings.liteMode === 'auto' ? 'selected' : ''}>خودکار</option><option value="off" ${settings.liteMode === 'off' ? 'selected' : ''}>استاندارد</option><option value="on" ${settings.liteMode === 'on' ? 'selected' : ''}>سبک برای گوشی ضعیف</option></select></div><button class="primary-button wide" data-action="save-appearance">اعمال تنظیمات</button>`;
}

function helpModal() {
  return `<div class="help-steps"><div><span>۱</span><p><b>کلاس را بررسی کن</b>نام مدرسه و کلاس همیشه بالای صفحه دیده می‌شود.</p></div><div><span>۲</span><p><b>رفتار را لمس کن</b>نمره پایه همان لحظه بزرگ و واضح نمایش داده می‌شود.</p></div><div><span>۳</span><p><b>تشویقی را مستند کن</b>در ثبت فردی، حداکثر دو نمره همراه دلیل قابل افزودن است.</p></div><div><span>۴</span><p><b>پس از ثبت هم ویرایش کن</b>از پرونده دانش‌آموز یا آخرین ثبت‌ها وارد جزئیات و ویرایش شو.</p></div><div><span>۵</span><p><b>پشتیبان بگیر</b>داده هنوز فقط روی همین گوشی است.</p></div></div>`;
}

function structureManagerModal() {
  const admin = model.localAdmin || { enabled: false };
  if (!admin.enabled) {
    return `<div class="notice warn"><b>راه‌اندازی مدیر محلی</b><span>برای پایلوت آفلاین، مدیر مدرسه یا مسئول سامانه یک رمز چهار تا هشت رقمی تعریف می‌کند. این رمز فقط روی همین گوشی نگهداری می‌شود.</span></div><div class="field"><label>نام مدیر یا مسئول تأیید</label><input id="admin-name" maxlength="80" placeholder="نام و نام خانوادگی"></div><div class="field"><label>رمز عددی</label><input id="admin-pin" type="password" inputmode="numeric" minlength="4" maxlength="8" placeholder="۴ تا ۸ رقم"></div><div class="field"><label>تکرار رمز</label><input id="admin-pin-confirm" type="password" inputmode="numeric" minlength="4" maxlength="8"></div><button class="primary-button wide" data-action="setup-local-admin">فعال‌سازی مدیر محلی</button>`;
  }
  if (!state.adminUnlocked) {
    return `<div class="notice"><b>تأیید مدیر محلی</b><span>مدیر تعریف‌شده: ${esc(admin.managerName || 'مدیر سامانه')}</span></div><div class="field"><label>رمز مدیر</label><input id="admin-unlock-pin" type="password" inputmode="numeric" maxlength="8" placeholder="رمز را وارد کنید"></div><button class="primary-button wide" data-action="unlock-local-admin">بازکردن مدیریت ساختار</button>`;
  }
  return `<div class="structure-summary"><article><b>${fa(model.schools.length)}</b><span>مدرسه</span></article><article><b>${fa(model.classes.length)}</b><span>کلاس</span></article><article><b>${fa(model.students.length)}</b><span>دانش‌آموز</span></article></div><div class="notice"><b>کنترل تکرار فعال است</b><span>شناسه دانش‌آموز و کد ملی احتمالی در کل سال تحصیلی کنترل می‌شود؛ هم‌نامی با شناسه متفاوت مجاز است.</span></div><div class="structure-actions"><button data-action="download-roster-template">${icon('file')} الگوی Excel و CSV</button><button data-action="import-roster">${icon('upload')} ورود فهرست دانش‌آموزان</button><button data-action="manual-structure">${icon('school')} افزودن مدرسه و کلاس</button><button data-action="lock-local-admin">${icon('shield')} قفل مدیریت</button></div>`;
}

function manualStructureModal() {
  return `<div class="field"><label>کد یکتای مدرسه</label><input id="manual-school-code" maxlength="30" placeholder="مثلاً DEG-101"></div><div class="field"><label>نام مدرسه</label><input id="manual-school-name" maxlength="120"></div><div class="two-col"><div class="field"><label>استان</label><input id="manual-province" value="کردستان"></div><div class="field"><label>منطقه</label><input id="manual-district" value="دهگلان"></div></div><div class="field"><label>سال تحصیلی</label><input id="manual-school-year" value="۱۴۰۵-۱۴۰۶"></div><hr><div class="two-col"><div class="field"><label>پایه</label><select id="manual-grade"><option>هفتم</option><option>هشتم</option><option>نهم</option></select></div><div class="field"><label>کد کلاس</label><input id="manual-class-code" maxlength="20" placeholder="مثلاً ۷۰۱"></div></div><div class="field"><label>عنوان کلاس</label><input id="manual-class-title" maxlength="40" placeholder="مثلاً ۷۰۱"></div><button class="primary-button wide" data-action="save-manual-structure">ثبت با تأیید مدیر</button>`;
}

function rosterPreviewModal() {
  const preview = state.rosterPreview;
  if (!preview) return '<div class="empty">فایلی انتخاب نشده است.</div>';
  return `<div class="preview-kpis"><article class="${preview.errors.length ? 'bad' : 'good'}"><b>${fa(preview.errors.length)}</b><span>خطای مانع ورود</span></article><article><b>${fa(preview.warnings.length)}</b><span>هشدار قابل بررسی</span></article><article><b>${fa(preview.rows.length)}</b><span>ردیف معتبر</span></article></div>${preview.errors.length ? `<section class="validation-list errors"><h3>خطاها</h3>${preview.errors.slice(0, 20).map(item => `<p>${esc(item)}</p>`).join('')}</section>` : ''}${preview.warnings.length ? `<section class="validation-list warnings"><h3>هشدارها</h3>${preview.warnings.slice(0, 20).map(item => `<p>${esc(item)}</p>`).join('')}</section>` : ''}<div class="report-table-wrap"><table class="report-table"><thead><tr><th>ردیف</th><th>مدرسه</th><th>سال</th><th>پایه</th><th>کلاس</th><th>شناسه</th><th>نام</th></tr></thead><tbody>${preview.rows.slice(0, 50).map((row, index) => `<tr><td>${fa(index + 2)}</td><td>${esc(row.schoolName)}</td><td>${esc(row.schoolYear)}</td><td>${esc(row.grade)}</td><td>${esc(row.classTitle)}</td><td>${esc(row.studentCode)}</td><td>${esc(`${row.firstName} ${row.lastName}`)}</td></tr>`).join('')}</tbody></table></div><div class="modal-actions"><button class="ghost-button" data-action="structure-manager">بازگشت</button><button class="primary-button" data-action="apply-roster-import" ${preview.errors.length ? 'disabled' : ''}>تأیید و ورود ${fa(preview.rows.length)} دانش‌آموز</button></div>`;
}

async function saveContext() {
  const schoolId = document.querySelector('#school-select').value;
  const schoolClasses = model.classes.filter(item => item.schoolId === schoolId);
  const selected = document.querySelector('#class-select').value;
  state.selectedSchoolId = schoolId;
  state.selectedClassId = schoolClasses.some(item => item.id === selected) ? selected : schoolClasses[0]?.id;
  state.semester = document.querySelector('input[name=semester]:checked').value;
  model.settings = { ...model.settings, selectedSchoolId: state.selectedSchoolId, selectedClassId: state.selectedClassId, semester: state.semester };
  await saveSettings(model.settings);
  closeModal();
  showToast('کلاس جاری تغییر کرد.');
}

async function saveAssessment() {
  const draft = state.assessment;
  if (!draft.level) return;
  draft.note = document.querySelector('#assess-note')?.value.trim() || draft.note;
  if (draft.mode === 'individual') {
    draft.bonusReason = document.querySelector('#bonus-reason')?.value.trim() || draft.bonusReason;
    if (Number(draft.bonusScore) > 0 && draft.bonusReason.length < 6) {
      showToast('برای تشویقی، دلیل کوتاه و مشخص بنویس.', 'error');
      return;
    }
  }
  document.querySelectorAll('[data-exception]').forEach(select => {
    if (select.value) draft.exceptions[select.dataset.exception] = Number(select.value);
    else delete draft.exceptions[select.dataset.exception];
  });
  const criterion = getRubricCriterion(draft.categoryKey, draft.criterionKey);
  const targetStudents = draft.mode === 'individual' ? students().filter(item => item.id === draft.targetId) : draft.mode === 'group' ? students().filter(item => item.group === draft.targetId) : students();
  const now = new Date().toISOString();
  const batchId = draft.editId ? model.assessments.find(item => item.id === draft.editId)?.batchId || uuid() : uuid();
  for (const student of targetStudents) {
    const level = Number(draft.exceptions[student.id] || draft.level);
    const levelData = levelInfo(level);
    const bonusScore = draft.mode === 'individual' ? Number(draft.bonusScore || 0) : 0;
    const finalScore = clamp(levelData.score + bonusScore, 0, 20);
    const existing = draft.editId ? model.assessments.find(item => item.id === draft.editId) : null;
    const record = {
      ...existing,
      id: existing?.id || uuid(), batchId, studentId: student.id, classId: currentClass().id, schoolId: currentSchool().id,
      semester: state.semester, date: draft.date, month: draft.month, activity: draft.activity,
      categoryKey: draft.categoryKey, criterionKey: draft.criterionKey, criterion: criterion.title,
      descriptor: criterion.levels[level], level, baseScore: levelData.score, bonusScore, bonusReason: bonusScore > 0 ? draft.bonusReason : '', score: finalScore,
      evidenceType: draft.evidenceType, evidenceTitle: EVIDENCE_TYPES.find(item => item.id === draft.evidenceType)?.title,
      notePreset: draft.notePreset, note: draft.note,
      rationale: buildRationale({ ...draft, level, bonusScore }, criterion, level), rubricVersion: RUBRIC_VERSION,
      createdAt: existing?.createdAt || now, updatedAt: now, entryDurationSec: Math.round((Date.now() - draft.startedAt) / 1000),
    };
    await put('assessments', record);
  }
  await put('audit', { id: uuid(), type: draft.editId ? 'assessment_updated' : 'assessment_saved', actorId: CURRENT_USER_ID, classId: currentClass().id, count: targetStudents.length, createdAt: now });
  state.modal = null;
  state.assessment = null;
  await refresh({ renderNow: false });
  state.route = 'assessment';
  render();
  showToast(draft.editId ? 'نمره و دلیل ویرایش شد.' : `${fa(targetStudents.length)} ثبت مستند ذخیره شد.`, 'success');
}

async function saveAttendance() {
  const absentIds = [];
  const lateIds = [];
  for (const student of students()) {
    const value = document.querySelector(`input[name="att-${student.id}"]:checked`)?.value;
    if (value === 'absent') absentIds.push(student.id);
    if (value === 'late') lateIds.push(student.id);
  }
  const existing = model.attendance.find(item => item.classId === currentClass().id && item.date === today());
  await put('attendance', { id: existing?.id || uuid(), classId: currentClass().id, schoolId: currentSchool().id, date: today(), absentIds, lateIds, createdAt: existing?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() });
  closeModal();
  await refresh();
  showToast('حضور امروز ذخیره شد.', 'success');
}

async function compressImage(file) {
  if (!file.type.startsWith('image/')) return file;
  try {
    const bitmap = await createImageBitmap(file);
    const max = 1600;
    const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext('2d', { alpha: false }).drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    return await new Promise(resolve => canvas.toBlob(blob => resolve(blob || file), 'image/jpeg', 0.78));
  } catch {
    return file;
  }
}

async function mediaSelected(input) {
  pendingMedia = [];
  const holder = document.querySelector('#pending-media');
  holder.innerHTML = '';
  for (const file of [...input.files].slice(0, 4)) {
    const isAV = file.type.startsWith('video/') || file.type.startsWith('audio/');
    if (isAV && file.size > 25 * 1024 * 1024) {
      showToast(`فایل ${file.name} بیشتر از ۲۵ مگابایت است.`, 'error');
      continue;
    }
    if (file.type.startsWith('image/') && file.size > 12 * 1024 * 1024) {
      showToast(`تصویر ${file.name} بیش از حد بزرگ است.`, 'error');
      continue;
    }
    const blob = await compressImage(file);
    pendingMedia.push({ id: uuid(), name: file.name, type: blob.type || file.type, size: blob.size, blob });
    const typeLabel = file.type.startsWith('image/') ? 'تصویر' : file.type.startsWith('audio/') ? 'صوت' : 'ویدیو';
    holder.insertAdjacentHTML('beforeend', `<span>${typeLabel} · ${esc(file.name)} · ${fmtBytes(blob.size)}</span>`);
  }
  input.value = '';
}

async function saveContent(submit) {
  const form = document.querySelector('#content-form');
  if (submit && !form.reportValidity()) return;
  const data = new FormData(form);
  const id = data.get('id') || uuid();
  const old = model.content.find(item => item.id === id);
  const now = new Date().toISOString();
  const type = data.get('type');
  const channelId = String(data.get('channelId') || '');
  if (type === 'podcast' && !channelId) {
    showToast('برای پادکست ابتدا کانال را انتخاب یا ایجاد کن.', 'error');
    return;
  }
  const mediaIds = [...(old?.mediaIds || [])];
  for (const item of pendingMedia) {
    await put('media', { ...item, contentId: id, createdAt: now });
    mediaIds.push(item.id);
  }
  const content = {
    ...old, id, authorId: CURRENT_USER_ID, authorName: profile().name,
    title: String(data.get('title') || '').trim(), summary: String(data.get('summary') || '').trim(), body: String(data.get('body') || '').trim(),
    grade: data.get('grade'), skill: String(data.get('skill') || '').trim(), resources: data.get('resources'), type, channelId,
    status: submit ? 'school_pending' : 'draft', approvalLevel: old?.approvalLevel || 'teacher', mediaIds,
    uses: old?.uses || 0, reports: old?.reports || 0, createdAt: old?.createdAt || now, updatedAt: now,
  };
  if (!content.title) {
    showToast('عنوان را وارد کن.', 'error');
    return;
  }
  await put('content', content);
  if (type === 'podcast' && channelId) {
    const channel = channelById(channelId);
    if (channel) {
      channel.episodeCount = model.content.filter(item => item.channelId === channelId && item.id !== id).length + 1;
      await put('channels', channel);
    }
  }
  await put('audit', { id: uuid(), type: submit ? 'content_submitted' : 'content_draft_saved', contentId: id, actorId: CURRENT_USER_ID, createdAt: now });
  pendingMedia = [];
  state.contentPreset = null;
  state.modal = null;
  await refresh({ renderNow: false });
  state.route = 'community';
  state.communityTab = 'mine';
  render();
  showToast(submit ? 'برای بررسی مدرسه آماده شد.' : 'پیش‌نویس روی گوشی ذخیره شد.', 'success');
}

async function reviewContent(id, decision) {
  const content = model.content.find(item => item.id === id);
  const flow = ROLE_FLOW.find(item => item.role === profile().role);
  if (!flow || content.status !== flow.status) {
    showToast('این محتوا در مرحله مربوط به نقش شما نیست.', 'error');
    return;
  }
  const comment = document.querySelector('#review-comment')?.value.trim() || '';
  content.status = decision === 'approve' ? flow.next : 'changes_requested';
  content.approvalLevel = decision === 'approve' ? profile().role.replace('_reviewer', '') : content.approvalLevel;
  content.updatedAt = new Date().toISOString();
  await put('content', content);
  await put('approvals', { id: uuid(), contentId: id, role: profile().role, reviewerId: CURRENT_USER_ID, reviewerName: profile().name, action: decision === 'approve' ? 'approve' : 'changes', comment, createdAt: new Date().toISOString() });
  closeModal();
  await refresh();
  showToast(decision === 'approve' ? 'مرحله بررسی تأیید شد.' : 'برای اصلاح به معلم برگشت.', 'success');
}

async function favoriteContent(id) {
  const existing = model.favorites.find(item => item.contentId === id && item.userId === CURRENT_USER_ID);
  if (existing) await remove('favorites', existing.id);
  else await put('favorites', { id: uuid(), contentId: id, userId: CURRENT_USER_ID, createdAt: new Date().toISOString() });
  await refresh();
  showToast(existing ? 'از ذخیره‌شده‌ها حذف شد.' : 'برای بعد ذخیره شد.');
}

async function useContent(id) {
  const content = model.content.find(item => item.id === id);
  content.uses = (content.uses || 0) + 1;
  await put('content', content);
  await put('audit', { id: uuid(), type: 'content_used', contentId: id, classId: currentClass()?.id, actorId: CURRENT_USER_ID, createdAt: new Date().toISOString() });
  await refresh();
  showToast('به برنامه کلاس جاری افزوده شد.', 'success');
}

async function toggleFollowChannel(id) {
  const existing = model.follows.find(item => item.channelId === id && item.userId === CURRENT_USER_ID);
  if (existing) await remove('follows', existing.id);
  else await put('follows', { id: uuid(), channelId: id, userId: CURRENT_USER_ID, createdAt: new Date().toISOString() });
  await refresh();
  state.route = 'community';
  state.communityTab = 'podcasts';
  render();
  showToast(existing ? 'دنبال‌کردن متوقف شد.' : 'کانال روی این گوشی دنبال شد.', 'success');
}

async function saveChannel() {
  const id = document.querySelector('#channel-id').value || uuid();
  const title = document.querySelector('#channel-title').value.trim();
  const description = document.querySelector('#channel-description').value.trim();
  if (title.length < 3 || description.length < 10) {
    showToast('نام و توضیح روشن برای کانال وارد کن.', 'error');
    return;
  }
  const old = model.channels.find(item => item.id === id);
  const channel = {
    ...old, id, ownerId: CURRENT_USER_ID, ownerName: profile().name, title, description,
    category: document.querySelector('#channel-category').value, status: 'local', approvalLevel: 'teacher',
    followerCount: old?.followerCount || 0, episodeCount: old?.episodeCount || 0, createdAt: old?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(),
  };
  await put('channels', channel);
  closeModal();
  await refresh();
  state.route = 'community';
  state.communityTab = 'podcasts';
  render();
  showToast('کانال محلی ذخیره شد.', 'success');
}

async function exportFile({ includeMedia = false, contentId = null } = {}) {
  showToast('در حال ساخت فایل…');
  const payload = await exportDatabase({ includeMedia, selectedContentId: contentId });
  const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
  const name = contentId ? `بسته-محتوا-${contentId}.karo.json` : `پشتیبان-همیار-${today()}${includeMedia ? '-کامل' : ''}.karo.json`;
  const file = new File([blob], name, { type: 'application/json' });
  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ title: 'همیار کاروفناوری', text: contentId ? 'بسته محتوا برای بررسی مرحله‌ای' : 'پشتیبان اطلاعات سامانه', files: [file] });
      showToast('فایل به اشتراک گذاشته شد.', 'success');
      return;
    } catch (error) {
      if (error.name === 'AbortError') return;
    }
  }
  downloadBlob(blob, name);
  showToast('فایل ذخیره شد.', 'success');
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

async function importFile(file) {
  try {
    const payload = JSON.parse(await file.text());
    await importDatabase(payload, { mode: 'merge' });
    await refresh();
    showToast('اطلاعات با موفقیت ادغام شد.', 'success');
  } catch (error) {
    console.error(error);
    showToast(error.message || 'ورود فایل ناموفق بود.', 'error');
  }
}

async function exportClassCsv() {
  const rows = [['شناسه دانش‌آموز', 'نام دانش‌آموز', 'کلاس', 'تعداد شاهد', 'میانگین نمره']];
  const records = model.assessments.filter(item => item.classId === currentClass()?.id && item.semester === state.semester);
  for (const student of students()) {
    const own = records.filter(item => item.studentId === student.id);
    const average = own.length ? (own.reduce((sum, item) => sum + Number(item.score || 0), 0) / own.length).toFixed(2) : '';
    rows.push([student.studentCode || student.id, student.name, currentClass().title, own.length, average]);
  }
  const csv = '\ufeff' + rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(',')).join('\n');
  downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8' }), `نمرات-${currentClass().title}-${today()}.csv`);
}

async function loadStorageModal() {
  const info = await storageInfo();
  const percent = info.quota ? Math.min(100, Math.round(info.usage / info.quota * 100)) : 0;
  const element = document.querySelector('#storage-info');
  if (!element) return;
  element.innerHTML = `<div class="storage-meter"><div style="width:${percent}%"></div></div><dl><dt>فضای مصرفی</dt><dd>${fmtBytes(info.usage)}</dd><dt>سقف تقریبی مرورگر</dt><dd>${fmtBytes(info.quota)}</dd><dt>حفاظت از پاک‌سازی خودکار</dt><dd>${info.persisted ? 'فعال' : 'فعال نیست'}</dd></dl><button class="primary-button wide" data-action="persist-storage">درخواست ماندگاری داده</button><div class="notice warn"><b>پشتیبان همچنان ضروری است</b><span>حذف مرورگر یا پاک‌کردن داده سایت می‌تواند اطلاعات محلی را از بین ببرد.</span></div>`;
}

function toEnglishDigits(value = '') {
  return String(value).replace(/[۰-۹]/g, digit => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)).replace(/[٠-٩]/g, digit => '٠١٢٣٤٥٦٧٨٩'.indexOf(digit));
}

function normalizeText(value = '') {
  return toEnglishDigits(String(value)).replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\u200c/g, ' ').replace(/\s+/g, ' ').trim();
}

function normalizeId(value = '') {
  return normalizeText(value).replace(/[\s-]/g, '').toUpperCase();
}

function parseCsv(text) {
  const clean = text.replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < clean.length; i++) {
    const char = clean[i];
    if (quoted) {
      if (char === '"' && clean[i + 1] === '"') { cell += '"'; i++; }
      else if (char === '"') quoted = false;
      else cell += char;
    } else if (char === '"') quoted = true;
    else if (char === ',') { row.push(cell); cell = ''; }
    else if (char === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += char;
  }
  row.push(cell.replace(/\r$/, ''));
  if (row.some(value => value.trim())) rows.push(row);
  return rows;
}

const HEADER_ALIASES = {
  schoolCode: ['کد مدرسه', 'school_code', 'schoolcode'],
  schoolName: ['نام مدرسه', 'school_name', 'schoolname'],
  province: ['استان', 'province'],
  district: ['منطقه', 'ناحیه', 'district'],
  schoolYear: ['سال تحصیلی', 'school_year', 'schoolyear'],
  grade: ['پایه', 'grade'],
  classCode: ['کد کلاس', 'class_code', 'classcode'],
  classTitle: ['عنوان کلاس', 'نام کلاس', 'class_title', 'classtitle'],
  studentCode: ['شناسه دانش‌آموز', 'کد دانش‌آموز', 'student_id', 'student_code', 'studentcode'],
  nationalId: ['کد ملی', 'national_id', 'nationalid'],
  firstName: ['نام', 'first_name', 'firstname'],
  lastName: ['نام خانوادگی', 'last_name', 'lastname'],
  fatherName: ['نام پدر', 'father_name', 'fathername'],
  birthDate: ['تاریخ تولد', 'birth_date', 'birthdate'],
  group: ['گروه', 'group'],
  status: ['وضعیت', 'status'],
};

function mapHeaders(headers) {
  const normalized = headers.map(header => normalizeText(header).toLowerCase());
  const map = {};
  for (const [key, aliases] of Object.entries(HEADER_ALIASES)) {
    map[key] = normalized.findIndex(header => aliases.map(alias => normalizeText(alias).toLowerCase()).includes(header));
  }
  return map;
}

function getCell(row, index) {
  return index >= 0 ? normalizeText(row[index] || '') : '';
}

function validateRosterRows(rawRows) {
  const errors = [];
  const warnings = [];
  if (rawRows.length < 2) return { rows: [], errors: ['فایل خالی است یا فقط عنوان ستون‌ها را دارد.'], warnings };
  const headerMap = mapHeaders(rawRows[0]);
  const required = ['schoolCode', 'schoolName', 'schoolYear', 'grade', 'classCode', 'classTitle', 'studentCode', 'firstName', 'lastName'];
  for (const key of required) if (headerMap[key] < 0) errors.push(`ستون ضروری «${HEADER_ALIASES[key][0]}» پیدا نشد.`);
  if (errors.length) return { rows: [], errors, warnings };
  const rows = [];
  const inFileStudentKeys = new Map();
  const inFileNationalIds = new Map();
  const inFileNames = new Map();
  for (let index = 1; index < rawRows.length; index++) {
    if (!rawRows[index].some(value => String(value).trim())) continue;
    const item = {
      schoolCode: normalizeId(getCell(rawRows[index], headerMap.schoolCode)), schoolName: getCell(rawRows[index], headerMap.schoolName),
      province: getCell(rawRows[index], headerMap.province), district: getCell(rawRows[index], headerMap.district), schoolYear: getCell(rawRows[index], headerMap.schoolYear),
      grade: getCell(rawRows[index], headerMap.grade), classCode: normalizeId(getCell(rawRows[index], headerMap.classCode)), classTitle: getCell(rawRows[index], headerMap.classTitle),
      studentCode: normalizeId(getCell(rawRows[index], headerMap.studentCode)), nationalId: normalizeId(getCell(rawRows[index], headerMap.nationalId)),
      firstName: getCell(rawRows[index], headerMap.firstName), lastName: getCell(rawRows[index], headerMap.lastName), fatherName: getCell(rawRows[index], headerMap.fatherName),
      birthDate: getCell(rawRows[index], headerMap.birthDate), group: getCell(rawRows[index], headerMap.group) || 'بدون گروه', status: getCell(rawRows[index], headerMap.status) || 'فعال', sourceRow: index + 1,
    };
    const missing = required.filter(key => !item[key]);
    if (missing.length) {
      errors.push(`ردیف ${index + 1}: مقدار ضروری ${missing.map(key => HEADER_ALIASES[key][0]).join('، ')} خالی است.`);
      continue;
    }
    if (!['هفتم', 'هشتم', 'نهم', '7', '8', '9'].includes(item.grade)) errors.push(`ردیف ${index + 1}: پایه «${item.grade}» معتبر نیست.`);
    item.grade = ({ '7': 'هفتم', '8': 'هشتم', '9': 'نهم' })[item.grade] || item.grade;
    if (item.nationalId && !/^\d{10}$/.test(item.nationalId)) warnings.push(`ردیف ${index + 1}: کد ملی ده‌رقمی نیست و فقط به‌عنوان هشدار نگهداری شد.`);
    const studentKey = `${item.schoolCode}|${normalizeText(item.schoolYear)}|${item.studentCode}`;
    if (inFileStudentKeys.has(studentKey)) errors.push(`ردیف ${index + 1}: شناسه دانش‌آموز با ردیف ${inFileStudentKeys.get(studentKey)} تکراری است.`);
    else inFileStudentKeys.set(studentKey, index + 1);
    if (item.nationalId) {
      if (inFileNationalIds.has(item.nationalId)) errors.push(`ردیف ${index + 1}: کد ملی با ردیف ${inFileNationalIds.get(item.nationalId)} تکراری است.`);
      else inFileNationalIds.set(item.nationalId, index + 1);
    }
    const nameKey = `${normalizeText(item.firstName)}|${normalizeText(item.lastName)}|${normalizeText(item.fatherName)}|${normalizeText(item.birthDate)}`;
    const previousIdentity = inFileNames.get(nameKey);
    if (previousIdentity && (item.fatherName || item.birthDate)) {
      if (previousIdentity.grade !== item.grade || previousIdentity.classCode !== item.classCode) {
        errors.push(`ردیف ${index + 1}: مشخصات هویتی با ردیف ${previousIdentity.row} یکسان است اما پایه یا کلاس متفاوت ثبت شده؛ احتمال ثبت یک دانش‌آموز در دو کلاس وجود دارد.`);
      } else {
        warnings.push(`ردیف ${index + 1}: مشخصات هویتی مشابه ردیف ${previousIdentity.row} است؛ شناسه‌ها را بررسی کن.`);
      }
    } else inFileNames.set(nameKey, { row: index + 1, grade: item.grade, classCode: item.classCode });
    const expectedSchoolId = schoolKeyToId(item);
    const existingByCode = model.students.find(student => student.schoolId === expectedSchoolId && normalizeId(student.studentCode) === item.studentCode && normalizeText(student.schoolYear) === normalizeText(item.schoolYear));
    if (existingByCode && (existingByCode.classId !== classKeyToId(item) || existingByCode.schoolId !== schoolKeyToId(item))) {
      const existingClass = classById(existingByCode.classId);
      if (existingClass && (existingClass.grade !== item.grade || normalizeId(existingClass.code || existingClass.title) !== item.classCode)) errors.push(`ردیف ${index + 1}: شناسه ${item.studentCode} قبلاً در پایه یا کلاس دیگری ثبت شده است.`);
    }
    const existingNational = item.nationalId ? model.students.find(student => normalizeId(student.nationalId) === item.nationalId) : null;
    if (existingNational) {
      const existingClass = classById(existingNational.classId);
      if (existingClass && (existingClass.grade !== item.grade || normalizeId(existingClass.code || existingClass.title) !== item.classCode)) errors.push(`ردیف ${index + 1}: این کد ملی قبلاً در پایه یا کلاس دیگری ثبت شده است.`);
    }
    rows.push(item);
  }
  return { rows, errors: [...new Set(errors)], warnings: [...new Set(warnings)] };
}

function schoolKeyToId(row) {
  return model.schools.find(school => normalizeId(school.code) === row.schoolCode)?.id || `school-${row.schoolCode.toLowerCase()}`;
}

function classKeyToId(row) {
  const schoolId = schoolKeyToId(row);
  return model.classes.find(cls => cls.schoolId === schoolId && normalizeText(cls.schoolYear) === normalizeText(row.schoolYear) && normalizeId(cls.code || cls.title) === row.classCode)?.id || `class-${row.schoolCode.toLowerCase()}-${row.schoolYear.replace(/\s/g, '')}-${row.classCode.toLowerCase()}`;
}

async function handleRosterFile(file) {
  try {
    const text = await file.text();
    const parsed = parseCsv(text);
    const validation = validateRosterRows(parsed);
    state.rosterPreview = { ...validation, fileName: file.name };
    openModal('roster-preview');
  } catch (error) {
    console.error(error);
    showToast('خواندن فایل CSV ناموفق بود.', 'error');
  }
}

async function applyRosterImport() {
  const preview = state.rosterPreview;
  if (!preview || preview.errors.length) return;
  const now = new Date().toISOString();
  const schools = new Map();
  const classes = new Map();
  const studentsToSave = [];
  for (const row of preview.rows) {
    const schoolId = schoolKeyToId(row);
    if (!schools.has(schoolId)) {
      const existing = model.schools.find(item => item.id === schoolId);
      schools.set(schoolId, { ...existing, id: schoolId, code: row.schoolCode, name: row.schoolName, province: row.province, district: row.district, schoolYear: row.schoolYear, resources: existing?.resources || 'متوسط', approvedLocally: true, approvedBy: model.localAdmin.managerName, updatedAt: now, createdAt: existing?.createdAt || now });
    }
    const classId = classKeyToId(row);
    if (!classes.has(classId)) {
      const existing = model.classes.find(item => item.id === classId);
      classes.set(classId, { ...existing, id: classId, schoolId, schoolYear: row.schoolYear, grade: row.grade, code: row.classCode, title: row.classTitle, semester: 'first', approvedLocally: true, approvedBy: model.localAdmin.managerName, updatedAt: now, createdAt: existing?.createdAt || now });
    }
    const id = `student-${row.schoolCode.toLowerCase()}-${row.schoolYear.replace(/\s/g, '')}-${row.studentCode.toLowerCase()}`;
    const existing = model.students.find(item => item.id === id);
    studentsToSave.push({ ...existing, id, classId, schoolId, schoolYear: row.schoolYear, studentCode: row.studentCode, nationalId: row.nationalId, firstName: row.firstName, lastName: row.lastName, fatherName: row.fatherName, birthDate: row.birthDate, name: `${row.firstName} ${row.lastName}`, group: row.group, active: normalizeText(row.status) !== 'غیرفعال', approvedLocally: true, approvedBy: model.localAdmin.managerName, updatedAt: now, createdAt: existing?.createdAt || now });
  }
  await bulkPut('schools', [...schools.values()]);
  await bulkPut('classes', [...classes.values()]);
  await bulkPut('students', studentsToSave);
  await put('audit', { id: uuid(), type: 'roster_import_approved', actorId: CURRENT_USER_ID, managerName: model.localAdmin.managerName, schools: schools.size, classes: classes.size, students: studentsToSave.length, createdAt: now });
  state.rosterPreview = null;
  state.modal = null;
  await refresh({ renderNow: false });
  const firstClass = [...classes.values()][0];
  if (firstClass) {
    state.selectedSchoolId = firstClass.schoolId;
    state.selectedClassId = firstClass.id;
    model.settings = { ...model.settings, selectedSchoolId: firstClass.schoolId, selectedClassId: firstClass.id };
    await saveSettings(model.settings);
  }
  render();
  showToast(`${fa(studentsToSave.length)} دانش‌آموز با تأیید مدیر وارد شد.`, 'success');
}

async function hashText(text) {
  const data = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

async function setupLocalAdmin() {
  const managerName = document.querySelector('#admin-name').value.trim();
  const pin = toEnglishDigits(document.querySelector('#admin-pin').value.trim());
  const confirmation = toEnglishDigits(document.querySelector('#admin-pin-confirm').value.trim());
  if (managerName.length < 3 || !/^\d{4,8}$/.test(pin) || pin !== confirmation) {
    showToast('نام مدیر و رمز یکسان ۴ تا ۸ رقمی را درست وارد کن.', 'error');
    return;
  }
  const localAdmin = { enabled: true, managerName, pinHash: await hashText(pin), createdAt: new Date().toISOString() };
  await saveLocalAdmin(localAdmin);
  state.adminUnlocked = true;
  await refresh();
  openModal('structure-manager');
  showToast('مدیر محلی فعال شد.', 'success');
}

async function unlockLocalAdmin() {
  const pin = toEnglishDigits(document.querySelector('#admin-unlock-pin').value.trim());
  if (await hashText(pin) !== model.localAdmin.pinHash) {
    showToast('رمز مدیر درست نیست.', 'error');
    return;
  }
  state.adminUnlocked = true;
  openModal('structure-manager');
  showToast('مدیریت ساختار باز شد.', 'success');
}

async function saveManualStructure() {
  if (!state.adminUnlocked) return;
  const schoolCode = normalizeId(document.querySelector('#manual-school-code').value);
  const schoolName = normalizeText(document.querySelector('#manual-school-name').value);
  const schoolYear = normalizeText(document.querySelector('#manual-school-year').value);
  const classCode = normalizeId(document.querySelector('#manual-class-code').value);
  const classTitle = normalizeText(document.querySelector('#manual-class-title').value);
  if (!schoolCode || !schoolName || !schoolYear || !classCode || !classTitle) {
    showToast('همه اطلاعات ضروری مدرسه و کلاس را وارد کن.', 'error');
    return;
  }
  const schoolId = model.schools.find(item => normalizeId(item.code) === schoolCode)?.id || `school-${schoolCode.toLowerCase()}`;
  const school = { ...(model.schools.find(item => item.id === schoolId) || {}), id: schoolId, code: schoolCode, name: schoolName, province: normalizeText(document.querySelector('#manual-province').value), district: normalizeText(document.querySelector('#manual-district').value), schoolYear, resources: 'متوسط', approvedLocally: true, approvedBy: model.localAdmin.managerName, updatedAt: new Date().toISOString() };
  const classId = model.classes.find(item => item.schoolId === schoolId && normalizeText(item.schoolYear) === schoolYear && normalizeId(item.code || item.title) === classCode)?.id || `class-${schoolCode.toLowerCase()}-${schoolYear.replace(/\s/g, '')}-${classCode.toLowerCase()}`;
  const cls = { ...(model.classes.find(item => item.id === classId) || {}), id: classId, schoolId, schoolYear, grade: document.querySelector('#manual-grade').value, code: classCode, title: classTitle, semester: 'first', approvedLocally: true, approvedBy: model.localAdmin.managerName, updatedAt: new Date().toISOString() };
  await put('schools', school);
  await put('classes', cls);
  await put('audit', { id: uuid(), type: 'structure_added_manually', actorId: CURRENT_USER_ID, managerName: model.localAdmin.managerName, schoolId, classId, createdAt: new Date().toISOString() });
  state.selectedSchoolId = schoolId;
  state.selectedClassId = classId;
  model.settings = { ...model.settings, selectedSchoolId: schoolId, selectedClassId: classId };
  await saveSettings(model.settings);
  closeModal();
  await refresh();
  showToast('مدرسه و کلاس ثبت شد.', 'success');
}

function downloadRosterTemplates() {
  const links = [
    ['./templates/الگوی_ورود_دانش_آموزان_کاروفناوری.xlsx', 'الگوی_ورود_دانش_آموزان_کاروفناوری.xlsx'],
    ['./templates/student_import_template.csv', 'student_import_template.csv'],
  ];
  links.forEach(([href, download], index) => setTimeout(() => {
    const link = document.createElement('a');
    link.href = href;
    link.download = download;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }, index * 500));
  showToast('الگوی Excel و فایل CSV دانلود می‌شوند.', 'success');
}

async function bindDynamicMedia() {
  for (const element of document.querySelectorAll('[data-media-id]')) {
    const media = model.media.find(item => item.id === element.dataset.mediaId);
    if (media?.blob && !element.src) {
      const url = URL.createObjectURL(media.blob);
      element.src = url;
      element.addEventListener(element.tagName === 'IMG' ? 'load' : 'loadedmetadata', () => URL.revokeObjectURL(url), { once: true });
    }
  }
}

async function handleAction(element) {
  const action = element.dataset.action;
  if (action === 'navigate') navigate(element.dataset.route);
  else if (action === 'go-back') goBack();
  else if (action === 'context') openModal('context');
  else if (action === 'close-modal') closeModal();
  else if (action === 'open-help') openModal('help');
  else if (action === 'save-context') await saveContext();
  else if (action === 'start-assessment') startAssessment(element.dataset.mode);
  else if (action === 'assess-student') startAssessment('individual', element.dataset.id);
  else if (action === 'edit-assessment') startAssessment('individual', null, element.dataset.id);
  else if (action === 'attendance') openModal('attendance');
  else if (action === 'save-attendance') await saveAttendance();
  else if (action === 'class-report') openModal('class-report');
  else if (action === 'export-class-csv') await exportClassCsv();
  else if (action === 'assessment-next') assessmentNext();
  else if (action === 'assessment-back') { if (state.assessment.step > 1) state.assessment.step--; render(); }
  else if (action === 'choose-activity') { state.assessment.activity = element.dataset.value; render(); }
  else if (action === 'choose-category') { state.assessment.categoryKey = element.dataset.value; state.assessment.criterionKey = Object.keys(RUBRIC_LIBRARY[element.dataset.value].criteria)[0]; state.assessment.level = null; render(); }
  else if (action === 'choose-criterion') { state.assessment.criterionKey = element.dataset.value; state.assessment.level = null; render(); }
  else if (action === 'choose-level') { state.assessment.level = Number(element.dataset.value); render(); }
  else if (action === 'choose-bonus') { state.assessment.bonusScore = Number(element.dataset.value); if (!state.assessment.bonusScore) state.assessment.bonusReason = ''; render(); }
  else if (action === 'choose-evidence') { state.assessment.evidenceType = element.dataset.value; render(); }
  else if (action === 'choose-note') { state.assessment.notePreset = state.assessment.notePreset === element.dataset.value ? '' : element.dataset.value; render(); }
  else if (action === 'save-assessment') await saveAssessment();
  else if (action === 'assessment-detail') openModal('assessment-detail', { id: element.dataset.id });
  else if (action === 'student-detail') openModal('student-detail', { id: element.dataset.id });
  else if (action === 'clear-search') { document.querySelector('#student-search').value = ''; filterStudents(''); }
  else if (action === 'community-tab') { state.communityTab = element.dataset.tab; render(); }
  else if (action === 'new-content') { state.contentPreset = element.dataset.type || 'experience'; pendingMedia = []; openModal('content-editor'); }
  else if (action === 'edit-content') { pendingMedia = []; state.contentPreset = null; openModal('content-editor', { id: element.dataset.id }); }
  else if (action === 'save-content-draft') await saveContent(false);
  else if (action === 'submit-content') await saveContent(true);
  else if (action === 'content-detail') openModal('content-detail', { id: element.dataset.id });
  else if (action === 'review-content') await reviewContent(element.dataset.id, element.dataset.decision);
  else if (action === 'favorite-content') await favoriteContent(element.dataset.id);
  else if (action === 'use-content') await useContent(element.dataset.id);
  else if (action === 'share-content-package') await exportFile({ includeMedia: true, contentId: element.dataset.id });
  else if (action === 'open-media') {
    const media = model.media.find(item => item.id === element.dataset.id);
    if (media?.blob) {
      const url = URL.createObjectURL(media.blob);
      window.open(url, '_blank', 'noopener');
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
  }
  else if (action === 'manage-channel') openModal('channel-editor', { id: element.dataset.id });
  else if (action === 'save-channel') await saveChannel();
  else if (action === 'toggle-follow-channel') await toggleFollowChannel(element.dataset.id);
  else if (action === 'open-publishing-guide') openModal('publishing-guide');
  else if (action === 'export-lite') await exportFile();
  else if (action === 'export-full') { if (confirm('فایل کامل ممکن است حجیم باشد. ادامه می‌دهید؟')) await exportFile({ includeMedia: true }); }
  else if (action === 'import') fileImport.click();
  else if (action === 'storage') openModal('storage');
  else if (action === 'persist-storage') { const ok = await requestPersistentStorage(); showToast(ok ? 'ماندگاری داده فعال شد.' : 'مرورگر این درخواست را نپذیرفت.'); await loadStorageModal(); }
  else if (action === 'role') openModal('role');
  else if (action === 'save-role') { const role = document.querySelector('input[name=role]:checked').value; model.profile = { ...profile(), role, roleLabel: roleLabel(role) }; await saveProfile(model.profile); closeModal(); await refresh(); showToast('نقش آزمایشی تغییر کرد.'); }
  else if (action === 'appearance') openModal('appearance');
  else if (action === 'save-appearance') { model.settings = { ...model.settings, theme: document.querySelector('#theme-select').value, liteMode: document.querySelector('#lite-select').value }; await saveSettings(model.settings); applyDeviceMode(); closeModal(); await refresh(); showToast('ظاهر جدید اعمال شد.', 'success'); }
  else if (action === 'structure-manager') openModal('structure-manager');
  else if (action === 'setup-local-admin') await setupLocalAdmin();
  else if (action === 'unlock-local-admin') await unlockLocalAdmin();
  else if (action === 'lock-local-admin') { state.adminUnlocked = false; openModal('structure-manager'); showToast('مدیریت ساختار قفل شد.'); }
  else if (action === 'download-roster-template') downloadRosterTemplates();
  else if (action === 'import-roster') rosterImport.click();
  else if (action === 'apply-roster-import') await applyRosterImport();
  else if (action === 'manual-structure') openModal('manual-structure');
  else if (action === 'save-manual-structure') await saveManualStructure();
  else if (action === 'install') {
    if (installPrompt) { installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; state.installAvailable = false; render(); }
    else showToast('از منوی Chrome گزینه افزودن به صفحه اصلی یا نصب را بزن.');
  }
  else if (action === 'reset') { if (confirm('همه داده‌های آزمایشی این گوشی پاک شود؟')) { await clearAll(); location.reload(); } }
}

function assessmentNext() {
  const draft = state.assessment;
  if (draft.step === 1) {
    draft.targetId = document.querySelector('#assess-target')?.value || draft.targetId;
    draft.date = document.querySelector('#assess-date').value;
    draft.month = document.querySelector('#assess-month').value;
    const custom = document.querySelector('#custom-activity').value.trim();
    if (custom) draft.activity = custom;
    if (!draft.activity) {
      showToast('فعالیت مشاهده‌شده را انتخاب یا وارد کن.', 'error');
      return;
    }
  }
  if (draft.step < 3) draft.step++;
  render();
}

function filterStudents(query) {
  const normalized = normalizeText(query);
  document.querySelectorAll('#student-list .student-row').forEach(row => {
    row.hidden = normalized && !normalizeText(row.dataset.search).includes(normalized);
  });
}

app.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (element) {
    event.preventDefault();
    handleAction(element);
  }
});

app.addEventListener('input', event => {
  if (event.target.id === 'student-search') filterStudents(event.target.value);
  if (event.target.id === 'bonus-reason' && state.assessment) state.assessment.bonusReason = event.target.value;
});

app.addEventListener('change', async event => {
  if (event.target.id === 'school-select') {
    state.selectedSchoolId = event.target.value;
    state.selectedClassId = model.classes.find(item => item.schoolId === state.selectedSchoolId)?.id;
    render();
    openModal('context');
  }
  if (event.target.id === 'content-media') await mediaSelected(event.target);
});

app.addEventListener('submit', async event => {
  if (event.target.id === 'content-form') {
    event.preventDefault();
    await saveContent(true);
  }
});

fileImport.addEventListener('change', async () => {
  if (fileImport.files[0]) await importFile(fileImport.files[0]);
  fileImport.value = '';
});

rosterImport.addEventListener('change', async () => {
  if (rosterImport.files[0]) await handleRosterFile(rosterImport.files[0]);
  rosterImport.value = '';
});

window.addEventListener('online', () => { state.online = true; render(); showToast('اینترنت برقرار شد؛ داده‌ها همچنان محلی‌اند.'); });
window.addEventListener('offline', () => { state.online = false; render(); showToast('آفلاین هستید؛ ثبت ادامه دارد.'); });
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; state.installAvailable = true; render(); });
window.addEventListener('appinstalled', () => { installPrompt = null; state.installAvailable = false; showToast('سامانه نصب شد.', 'success'); });
window.addEventListener('popstate', event => {
  if (state.modal) { state.modal = null; state.assessment = null; render(); return; }
  const route = event.state?.route;
  if (['home', 'class', 'assessment', 'community', 'settings'].includes(route)) { state.route = route; render(); }
});

async function init() {
  const requestedRoute = new URLSearchParams(location.search).get('route');
  if (['home', 'class', 'assessment', 'community', 'settings'].includes(requestedRoute)) state.route = requestedRoute;
  history.replaceState({ route: state.route }, '', `?route=${state.route}`);
  await ensureSeed();
  await refresh();
  if (!model.settings.onboardingDone) {
    model.settings = { ...model.settings, onboardingDone: true };
    await saveSettings(model.settings);
    state.modal = { type: 'help', payload: {} };
    render();
  }
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('./service-worker.js', { scope: './' });
      registration.addEventListener('updatefound', () => {
        const worker = registration.installing;
        worker?.addEventListener('statechange', () => {
          if (worker.state === 'installed' && navigator.serviceWorker.controller) showToast('نسخه تازه آماده است؛ برنامه را ببند و دوباره باز کن.');
        });
      });
    } catch (error) {
      console.warn('Service worker', error);
    }
  }
}

init();
