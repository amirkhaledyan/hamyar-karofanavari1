import {
  EVIDENCE_TYPES, MONTHS, NOTE_PRESETS, RUBRIC_LEVELS, RUBRIC_LIBRARY, RUBRIC_VERSION,
} from './rubrics.js?v=2.0.0-rc2';
import {
  bulkPut, clearAll, exportDatabase, importDatabase, put, remove,
  requestPersistentStorage, storageInfo,
} from './db.js?v=2.0.0-rc2';
import {
  APP_VERSION, CURRENT_USER_ID, STATUS_LABELS, ensureSeed, readModel,
  saveLocalAdmin, saveProfile, saveSettings, uuid,
} from './data.js?v=2.0.0-rc2';

const app = document.querySelector('#app');
const toast = document.querySelector('#toast');
const dialog = document.querySelector('#app-dialog');
const backupFile = document.querySelector('#backup-file');
const rosterFile = document.querySelector('#roster-file');

let model;
let pendingServiceWorker = null;
let pendingRosterTarget = null;

const state = {
  route: 'home',
  params: {},
  selectedSchoolId: null,
  selectedClassId: null,
  semester: 'first',
  classTab: 'students',
  communityTab: 'published',
  assessment: null,
  setup: null,
  updateReady: false,
};

const ROUTES = new Set(['home', 'classes', 'class-detail', 'class-setup', 'assessment', 'assessment-flow', 'student', 'record', 'community', 'content-editor', 'channel-editor', 'more', 'help']);

const esc = (value = '') => String(value).replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
})[char]);
const fa = value => String(value ?? '').replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[digit]);
const enDigits = value => String(value ?? '').replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)));
const normalize = value => enDigits(String(value ?? '')).replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\s+/g, ' ').trim();
const normalizeId = value => normalize(value).replace(/\s/g, '').toUpperCase();
const today = () => new Date().toISOString().slice(0, 10);
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const formatBytes = bytes => bytes ? `${fa((bytes / 1024 / 1024).toFixed(bytes > 10 * 1024 * 1024 ? 0 : 1))} مگابایت` : '۰ مگابایت';

function icon(name) {
  const paths = {
    home: '<path d="M3 11.5 12 4l9 7.5v8a1.5 1.5 0 0 1-1.5 1.5h-5v-6h-5v6h-5A1.5 1.5 0 0 1 3 19.5z"/>',
    classes: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h10M7 13h7"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    users: '<path d="M16 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M9.5 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8M17 11a3 3 0 1 0 0-6M21 20v-2a4 4 0 0 0-3-3.87"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    arrow: '<path d="m9 18 6-6-6-6"/>',
    back: '<path d="m15 18-6-6 6-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    school: '<path d="M3 10 12 4l9 6M5 10v9h14v-9M9 19v-5h6v5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',
    report: '<path d="M5 3h14v18H5zM8 8h8M8 12h8M8 16h5"/>',
    edit: '<path d="M4 20h4l11-11-4-4L4 16zM13.5 6.5l4 4"/>',
    download: '<path d="M12 4v12m0 0 5-5m-5 5-5-5M5 20h14"/>',
    upload: '<path d="M12 16V4m0 0L7 9m5-5 5 5M5 20h14"/>',
    storage: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18h1.5a2 2 0 0 0 0-4H12a1.5 1.5 0 0 1 0-3h3a6 6 0 0 0 0-12z"/><circle cx="7.5" cy="10" r="1"/><circle cx="9" cy="6.5" r="1"/><circle cx="14" cy="6" r="1"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    install: '<path d="M12 3v12m0 0 5-5m-5 5-5-5M5 21h14"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3m3 0-1 14H7L6 7m4 4v6m4-6v6"/>',
    podcast: '<circle cx="12" cy="12" r="2"/><path d="M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5.5 5.5a9 9 0 0 0 0 13M18.5 5.5a9 9 0 0 1 0 13"/>',
    file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    personAdd: '<path d="M15 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M8 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M19 8v6M16 11h6"/>',
    warning: '<path d="M12 3 2.5 20h19z"/><path d="M12 9v4M12 17h.01"/>',
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.info}</svg>`;
}

function schoolById(id) { return model.schools.find(item => item.id === id); }
function classById(id) { return model.classes.find(item => item.id === id); }
function currentClass() { return classById(state.selectedClassId) || model.classes[0]; }
function currentSchool() { return schoolById(state.selectedSchoolId) || schoolById(currentClass()?.schoolId) || model.schools[0]; }
function classStudents(classId = currentClass()?.id) { return model.students.filter(item => item.classId === classId && item.active !== false); }
function levelInfo(level) { return RUBRIC_LEVELS.find(item => item.level === Number(level)); }
function criterionInfo(categoryKey, criterionKey) { return RUBRIC_LIBRARY[categoryKey]?.criteria?.[criterionKey]; }

function showToast(message, type = 'normal') {
  toast.textContent = message;
  toast.dataset.type = type;
  toast.classList.add('is-visible');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('is-visible'), 3200);
}

function applyTheme() {
  const theme = model?.settings?.theme || 'light';
  const density = model?.settings?.density || 'comfortable';
  document.documentElement.dataset.theme = theme;
  document.documentElement.dataset.density = density;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#182129' : '#0f766e');
}

async function refreshModel() {
  model = await readModel();
  state.selectedSchoolId = state.selectedSchoolId || model.settings.selectedSchoolId || model.schools[0]?.id || null;
  const schoolClasses = model.classes.filter(item => item.schoolId === state.selectedSchoolId);
  state.selectedClassId = state.selectedClassId || model.settings.selectedClassId || schoolClasses[0]?.id || model.classes[0]?.id || null;
  if (state.selectedClassId && !model.classes.some(item => item.id === state.selectedClassId)) {
    state.selectedClassId = schoolClasses[0]?.id || model.classes[0]?.id || null;
  }
  state.semester = model.settings.semester || 'first';
  applyTheme();
}

function parseLocation() {
  const params = new URLSearchParams(location.search);
  const route = params.get('view') || 'home';
  state.route = ROUTES.has(route) ? route : 'home';
  state.params = {};
  for (const [key, value] of params.entries()) if (key !== 'view') state.params[key] = value;
}

function routeUrl(route, params = {}) {
  const search = new URLSearchParams({ view: route });
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') search.set(key, value);
  });
  return `?${search.toString()}`;
}

function navigate(route, params = {}, { replace = false } = {}) {
  if (!ROUTES.has(route)) route = 'home';
  state.route = route;
  state.params = params;
  const url = routeUrl(route, params);
  if (replace) history.replaceState({ route, params }, '', url);
  else history.pushState({ route, params }, '', url);
  renderRoute({ scrollTop: true });
}

function goBack() {
  if (history.length > 1) history.back();
  else navigate('home', {}, { replace: true });
}

function navRoute(route) {
  if (route === 'class-detail' || route === 'class-setup' || route === 'student') return 'classes';
  if (route === 'assessment-flow' || route === 'record') return 'assessment';
  if (route === 'content-editor' || route === 'channel-editor') return 'community';
  if (route === 'help') return 'more';
  return route;
}

function renderShell() {
  app.className = '';
  app.setAttribute('aria-busy', 'false');
  app.innerHTML = `<div class="app-shell">
    <header class="topbar">
      <div class="topbar__brand">
        <img src="assets/icon-96.png?v=2.0.0-rc2" alt="">
        <span class="topbar__title"><b>همیار کار و فناوری</b><small id="topbar-status">${navigator.onLine ? 'آماده ثبت' : 'آفلاین؛ ثبت فعال است'}</small></span>
      </div>
      <div class="topbar__actions">
        ${['class-detail', 'class-setup', 'assessment-flow', 'student', 'record', 'content-editor', 'channel-editor', 'help'].includes(state.route) ? `<button class="icon-btn" data-action="back" aria-label="بازگشت">${icon('back')}</button>` : ''}
        <button class="icon-btn" data-action="open-help" aria-label="راهنما">${icon('info')}</button>
      </div>
    </header>
    <main id="main-view" class="main-view" tabindex="-1"></main>
    ${bottomNav()}
  </div>
  <div id="update-slot"></div>`;
}

function bottomNav() {
  const items = [
    ['home', 'home', 'خانه'],
    ['classes', 'classes', 'کلاس‌ها'],
    ['assessment', 'check', 'ثبت'],
    ['community', 'users', 'هم‌افزایی'],
    ['more', 'more', 'بیشتر'],
  ];
  const active = navRoute(state.route);
  return `<nav class="bottom-nav" aria-label="ناوبری اصلی">${items.map(([route, iconName, label]) => `<button data-action="navigate" data-route="${route}" aria-current="${active === route ? 'page' : 'false'}">${icon(iconName)}<span>${label}</span></button>`).join('')}</nav>`;
}

function contextSwitcher() {
  const school = currentSchool();
  const cls = currentClass();
  if (!school || !cls) {
    return `<button class="context-switcher" data-action="new-class"><span><strong>کلاسی تعریف نشده است</strong><small>تعریف مدرسه و کلاس</small></span>${icon('arrow')}</button>`;
  }
  return `<button class="context-switcher" data-action="open-context"><span><strong>${esc(school.name)}</strong><small>پایه ${esc(cls.grade)} · کلاس ${esc(cls.title)} · ${state.semester === 'first' ? 'نیم‌سال اول' : 'نیم‌سال دوم'}</small></span>${icon('arrow')}</button>`;
}

function routeContent() {
  switch (state.route) {
    case 'classes': return classesView();
    case 'class-detail': return classDetailView(state.params.id);
    case 'class-setup': return classSetupView();
    case 'assessment': return assessmentLandingView();
    case 'assessment-flow': return assessmentFlowView();
    case 'student': return studentView(state.params.id);
    case 'record': return recordView(state.params.id);
    case 'community': return communityView();
    case 'content-editor': return contentEditorView(state.params.id);
    case 'channel-editor': return channelEditorView(state.params.id);
    case 'more': return moreView();
    case 'help': return helpView();
    default: return homeView();
  }
}

function renderRoute({ scrollTop = false } = {}) {
  if (!document.querySelector('#main-view')) renderShell();
  const main = document.querySelector('#main-view');
  const update = () => {
    main.innerHTML = `<div class="page-enter">${routeContent()}</div>`;
    updateNavActive();
    updateTopbarBackButton();
    renderUpdateBanner();
    main.focus({ preventScroll: true });
    if (scrollTop) window.scrollTo({ top: 0, behavior: 'auto' });
  };
  // به‌روزرسانی مسیر باید هم‌زمان انجام شود؛ انیمیشن با CSS کنترل می‌شود.
  // View Transition در برخی WebViewها و حالت‌های پس‌زمینه می‌تواند callback را به تأخیر بیندازد.
  update();
}

function updateNavActive() {
  const active = navRoute(state.route);
  document.querySelectorAll('.bottom-nav [data-route]').forEach(button => button.setAttribute('aria-current', button.dataset.route === active ? 'page' : 'false'));
}

function updateTopbarBackButton() {
  const actions = document.querySelector('.topbar__actions');
  if (!actions) return;
  const shouldShow = ['class-detail', 'class-setup', 'assessment-flow', 'student', 'record', 'content-editor', 'channel-editor', 'help'].includes(state.route);
  const back = actions.querySelector('[data-action="back"]');
  if (shouldShow && !back) actions.insertAdjacentHTML('afterbegin', `<button class="icon-btn" data-action="back" aria-label="بازگشت">${icon('back')}</button>`);
  if (!shouldShow && back) back.remove();
}

function renderUpdateBanner() {
  const slot = document.querySelector('#update-slot');
  if (!slot) return;
  slot.innerHTML = state.updateReady ? `<div class="update-banner"><span>نسخه تازه آماده است.</span><button data-action="apply-update">به‌روزرسانی</button></div>` : '';
}

function homeView() {
  const cls = currentClass();
  if (!cls) return `${contextSwitcher()}${emptyClassState()}`;
  const students = classStudents(cls.id);
  const records = model.assessments.filter(item => item.classId === cls.id && item.semester === state.semester);
  const todayCount = records.filter(item => item.date === today()).length;
  const pending = students.map(student => ({ student, count: records.filter(item => item.studentId === student.id).length }))
    .filter(item => item.count < 3).sort((a, b) => a.count - b.count).slice(0, 6);
  return `${contextSwitcher()}
    <section class="hero-action">
      <div class="hero-action__copy"><h1>ثبت ارزشیابی</h1></div>
      <button class="primary-btn wide" data-action="start-assessment" data-mode="individual">${icon('plus')} شروع ثبت</button>
    </section>
    <section class="section"><div class="stats-grid">
      <article class="stat-card"><b>${fa(students.length)}</b><span>دانش‌آموز فعال</span></article>
      <article class="stat-card"><b>${fa(todayCount)}</b><span>ثبت امروز</span></article>
      <article class="stat-card"><b>${fa(pending.length)}</b><span>نیازمند ثبت بیشتر</span></article>
    </div></section>
    <section class="section"><div class="section-title"><h2>کارهای اصلی</h2></div><div class="quick-grid">
      <button class="quick-card" data-action="attendance">${icon('calendar')}<span><b>حضور و غیاب</b><small>ثبت وضعیت امروز</small></span></button>
      <button class="quick-card" data-action="start-assessment" data-mode="group">${icon('users')}<span><b>ثبت گروهی</b><small>با استثنای فردی</small></span></button>
      <button class="quick-card" data-action="class-report">${icon('report')}<span><b>گزارش نمرات</b><small>میانگین و تعداد ثبت</small></span></button>
      <button class="quick-card" data-action="navigate" data-route="classes">${icon('classes')}<span><b>مدیریت کلاس</b><small>فهرست و دانش‌آموزان</small></span></button>
    </div></section>
    ${pending.length ? `<section class="section"><div class="section-title"><h2>نیازمند ثبت بیشتر</h2><small>کمتر از ۳ شاهد</small></div><div class="list-card">${pending.map(({ student, count }) => `<button class="list-row" data-action="assess-student" data-id="${student.id}"><span class="list-row__avatar">${esc(student.name.trim().charAt(0))}</span><span class="list-row__body"><b>${esc(student.name)}</b><small>${fa(count)} ثبت در این نیم‌سال</small></span><span class="status-chip warning">ثبت</span></button>`).join('')}</div></section>` : ''}`;
}

function emptyClassState() {
  return `<section class="empty-state">${icon('school')}<h2>هنوز کلاسی ثبت نشده است</h2><p>مدرسه، کلاس و فهرست دانش‌آموزان را ثبت کنید.</p><button class="primary-btn" data-action="new-class">تعریف نخستین کلاس</button></section>`;
}

function classesView() {
  const classes = [...model.classes].sort((a, b) => String(a.grade).localeCompare(String(b.grade), 'fa'));
  return `<section class="page-heading page-heading--row"><div><h1>کلاس‌ها</h1></div><button class="primary-btn" data-action="new-class">${icon('plus')} کلاس جدید</button></section>
    ${classes.length ? `<div class="class-grid">${classes.map(cls => {
      const school = schoolById(cls.schoolId);
      const students = classStudents(cls.id);
      const records = model.assessments.filter(item => item.classId === cls.id);
      const active = cls.id === state.selectedClassId;
      return `<article class="class-card ${active ? 'is-active' : ''}"><div class="class-card__head"><div><h3>پایه ${esc(cls.grade)} · ${esc(cls.title)}</h3><p>${esc(school?.name || 'مدرسه')} · ${esc(cls.schoolYear || '')}</p></div>${active ? '<span class="status-chip success">کلاس جاری</span>' : ''}</div><div class="class-card__stats"><span>${fa(students.length)} دانش‌آموز</span><span>${fa(records.length)} ثبت</span><span>کد ${esc(cls.code || '—')}</span></div><div class="class-card__actions"><button data-action="open-class" data-id="${cls.id}">مدیریت</button><button data-action="activate-class" data-id="${cls.id}">${active ? 'فعال است' : 'انتخاب کلاس'}</button></div></article>`;
    }).join('')}</div>` : emptyClassState()}`;
}

function classDetailView(classId) {
  const cls = classById(classId) || currentClass();
  if (!cls) return emptyClassState();
  const school = schoolById(cls.schoolId);
  const students = classStudents(cls.id);
  const records = model.assessments.filter(item => item.classId === cls.id && item.semester === state.semester);
  return `<section class="page-heading page-heading--row"><div><h1>پایه ${esc(cls.grade)} · ${esc(cls.title)}</h1><p>${esc(school?.name || '')} · ${fa(students.length)} دانش‌آموز</p></div><button class="ghost-btn" data-action="edit-class" data-id="${cls.id}">${icon('edit')} ویرایش</button></section>
    <div class="tabs" role="tablist"><button data-action="class-tab" data-tab="students" aria-selected="${state.classTab === 'students'}">دانش‌آموزان</button><button data-action="class-tab" data-tab="attendance" aria-selected="${state.classTab === 'attendance'}">حضور</button><button data-action="class-tab" data-tab="scores" aria-selected="${state.classTab === 'scores'}">نمرات</button></div>
    ${state.classTab === 'students' ? classStudentsPanel(cls, students, records) : state.classTab === 'attendance' ? attendancePanel(cls, students) : classScoresPanel(cls, students, records)}`;
}

function classStudentsPanel(cls, students, records) {
  return `<section class="section"><div class="button-row"><button class="primary-btn" data-action="open-add-student" data-id="${cls.id}">${icon('personAdd')} افزودن دانش‌آموز</button><button class="ghost-btn" data-action="import-roster" data-id="${cls.id}">${icon('upload')} ورود از CSV</button></div></section>
    <section class="section"><div class="search-box">${icon('search')}<input id="student-search" type="search" placeholder="جست‌وجوی نام یا شناسه" autocomplete="off"></div></section>
    <div class="list-card" id="student-list">${students.length ? students.map(student => {
      const own = records.filter(item => item.studentId === student.id);
      const average = own.length ? own.reduce((sum, item) => sum + Number(item.score || 0), 0) / own.length : null;
      return `<button class="list-row" data-action="open-student" data-id="${student.id}" data-search="${esc(`${student.name} ${student.studentCode || ''}`)}"><span class="list-row__avatar">${esc(student.name.charAt(0))}</span><span class="list-row__body"><b>${esc(student.name)}</b><small>${esc(student.studentCode || 'بدون شناسه')} · ${fa(own.length)} ثبت</small></span><span class="score-chip">${average === null ? '—' : fa(average.toFixed(1))}</span></button>`;
    }).join('') : '<div class="empty-state"><h3>دانش‌آموزی ثبت نشده است</h3><p>از افزودن دستی یا فایل CSV استفاده کنید.</p></div>'}</div>`;
}

function attendancePanel(cls, students) {
  const saved = model.attendance.find(item => item.classId === cls.id && item.date === today());
  return `<section class="form-card"><div class="section-title"><h2>حضور و غیاب امروز</h2><small>${esc(today())}</small></div><div class="list-card">${students.map(student => {
    const value = saved?.absentIds?.includes(student.id) ? 'absent' : saved?.lateIds?.includes(student.id) ? 'late' : 'present';
    return `<div class="list-row"><span class="list-row__avatar">${esc(student.name.charAt(0))}</span><span class="list-row__body"><b>${esc(student.name)}</b><small>${esc(student.studentCode || '')}</small></span><select data-attendance="${student.id}" aria-label="وضعیت ${esc(student.name)}"><option value="present" ${value === 'present' ? 'selected' : ''}>حاضر</option><option value="late" ${value === 'late' ? 'selected' : ''}>تأخیر</option><option value="absent" ${value === 'absent' ? 'selected' : ''}>غایب</option></select></div>`;
  }).join('')}</div><div class="section"><button class="primary-btn wide" data-action="save-attendance" data-id="${cls.id}">ذخیره حضور و غیاب</button></div></section>`;
}

function classScoresPanel(cls, students, records) {
  return `<section class="section"><div class="list-card">${students.length ? students.map(student => {
    const own = records.filter(item => item.studentId === student.id);
    const average = own.length ? own.reduce((sum, item) => sum + Number(item.score || 0), 0) / own.length : null;
    return `<button class="list-row" data-action="open-student" data-id="${student.id}"><span class="list-row__avatar">${esc(student.name.charAt(0))}</span><span class="list-row__body"><b>${esc(student.name)}</b><small>${fa(own.length)} ثبت · آخرین ${own[0]?.date ? esc(own[0].date) : '—'}</small></span><span class="score-chip">${average === null ? '—' : fa(average.toFixed(1))}</span></button>`;
  }).join('') : '<div class="empty-state"><h3>دانش‌آموزی ثبت نشده است</h3></div>'}</div></section><section class="section"><button class="ghost-btn wide" data-action="export-class" data-id="${cls.id}">${icon('download')} دریافت CSV نمرات</button></section>`;
}

function newSetupDraft(classId = null) {
  const cls = classById(classId);
  const school = cls ? schoolById(cls.schoolId) : null;
  return {
    step: 1,
    editClassId: classId,
    schoolMode: school ? 'existing' : model.schools.length ? 'existing' : 'new',
    schoolId: school?.id || model.schools[0]?.id || '',
    schoolCode: school?.code || '',
    schoolName: school?.name || '',
    province: school?.province || '',
    district: school?.district || '',
    schoolYear: cls?.schoolYear || school?.schoolYear || '۱۴۰۵–۱۴۰۶',
    grade: cls?.grade || 'هفتم',
    classCode: cls?.code || '',
    classTitle: cls?.title || '',
    studentsText: '',
    importedStudents: [],
    managerName: model.localAdmin?.managerName || '',
    pin: '',
    pinConfirm: '',
  };
}

function classSetupView() {
  if (!state.setup) state.setup = newSetupDraft(state.params.id || null);
  const draft = state.setup;
  const labels = ['مدرسه', 'کلاس', 'دانش‌آموزان', 'تأیید'];
  return `<section class="page-heading"><h1>${draft.editClassId ? 'ویرایش کلاس' : 'تعریف کلاس'}</h1></section>
    <div class="wizard-shell"><div class="wizard-status" aria-live="polite"><span>مرحله ${fa(draft.step)} از ۴</span><strong>${labels[draft.step - 1]}</strong></div><div class="wizard-top"><div class="wizard-progress">${labels.map((label, index) => `<button data-action="setup-jump" data-step="${index + 1}" class="${draft.step === index + 1 ? 'is-current' : draft.step > index + 1 ? 'is-done' : ''}" ${index + 1 > draft.step ? 'disabled' : ''} aria-label="مرحله ${fa(index + 1)}: ${label}"><span>${draft.step > index + 1 ? '✓' : fa(index + 1)}</span>${label}</button>`).join('')}</div></div>
    <div id="setup-stage">${classSetupStage()}</div>
    <div class="wizard-actions"><button class="ghost-btn" data-action="setup-back">${draft.step === 1 ? 'انصراف' : 'مرحله قبل'}</button><button class="primary-btn" data-action="setup-next">${draft.step === 4 ? (draft.editClassId ? 'ذخیره تغییرات' : 'ثبت و فعال‌سازی') : 'ادامه'}</button></div></div>`;
}

function classSetupStage() {
  const draft = state.setup;
  if (draft.step === 1) {
    return `<section class="wizard-card"><h2>مدرسه</h2><p>${model.schools.length ? 'مدرسه را انتخاب یا مدرسه جدید ثبت کنید.' : 'اطلاعات مدرسه را وارد کنید.'}</p>
      ${model.schools.length ? `<div class="option-grid"><button class="option-card ${draft.schoolMode === 'existing' ? 'is-selected' : ''}" data-action="setup-school-mode" data-value="existing"><b>مدرسه موجود</b><small>استفاده از اطلاعات ثبت‌شده</small></button><button class="option-card ${draft.schoolMode === 'new' ? 'is-selected' : ''}" data-action="setup-school-mode" data-value="new"><b>مدرسه جدید</b><small>ثبت اطلاعات مدرسه</small></button></div>` : ''}
      <div class="section">${draft.schoolMode === 'existing' && model.schools.length ? `<div class="field"><label for="setup-school-id">مدرسه</label><select id="setup-school-id">${model.schools.map(school => `<option value="${school.id}" ${school.id === draft.schoolId ? 'selected' : ''}>${esc(school.name)} · ${esc(school.code || '')}</option>`).join('')}</select></div>` : `<div class="field-grid"><div class="field"><label for="setup-school-code">کد مدرسه</label><input id="setup-school-code" value="${esc(draft.schoolCode)}" inputmode="numeric" placeholder="مثال: ۱۲۳۴۵۶۷۸"></div><div class="field"><label for="setup-school-name">نام مدرسه</label><input id="setup-school-name" value="${esc(draft.schoolName)}" placeholder="نام رسمی مدرسه"></div><div class="field"><label for="setup-province">استان</label><input id="setup-province" value="${esc(draft.province)}"></div><div class="field"><label for="setup-district">منطقه یا شهرستان</label><input id="setup-district" value="${esc(draft.district)}"></div></div>`}</div>
    </section>`;
  }
  if (draft.step === 2) {
    return `<section class="wizard-card"><h2>اطلاعات کلاس</h2><p>شناسه کلاس باید در همان مدرسه و سال تحصیلی یکتا باشد.</p><div class="field-grid"><div class="field"><label for="setup-year">سال تحصیلی</label><input id="setup-year" value="${esc(draft.schoolYear)}" placeholder="۱۴۰۵–۱۴۰۶"></div><div class="field"><label for="setup-grade">پایه</label><select id="setup-grade"><option ${draft.grade === 'هفتم' ? 'selected' : ''}>هفتم</option><option ${draft.grade === 'هشتم' ? 'selected' : ''}>هشتم</option><option ${draft.grade === 'نهم' ? 'selected' : ''}>نهم</option></select></div><div class="field"><label for="setup-class-code">کد کلاس</label><input id="setup-class-code" value="${esc(draft.classCode)}" placeholder="مثال: ۷۰۱"></div><div class="field"><label for="setup-class-title">عنوان کلاس</label><input id="setup-class-title" value="${esc(draft.classTitle)}" placeholder="مثال: ۷/۱"></div></div></section>`;
  }
  if (draft.step === 3) {
    const students = draft.importedStudents.length ? draft.importedStudents : parseStudentLines(draft.studentsText).rows;
    return `<section class="wizard-card"><h2>دانش‌آموزان</h2><p>هر سطر: نام و نام خانوادگی | شناسه دانش‌آموز | گروه. ورود دانش‌آموزان در این مرحله اختیاری است.</p><div class="field"><label for="setup-students">ورود سریع</label><textarea id="setup-students" placeholder="آرمان احمدی | ۱۴۰۵۰۰۱ | گروه ۱\nسارا محمدی | ۱۴۰۵۰۰۲ | گروه ۲">${esc(draft.studentsText)}</textarea><small>شناسه دانش‌آموز برای جلوگیری از ثبت تکراری ضروری است.</small></div><div class="button-row"><button class="ghost-btn" data-action="parse-student-lines">بررسی فهرست</button><button class="ghost-btn" data-action="setup-import-csv">${icon('upload')} ورود از CSV</button></div>${students.length ? `<div class="student-preview">${students.slice(0, 12).map(student => `<div class="student-preview__row"><span><b>${esc(student.name)}</b><small>${esc(student.studentCode)}${student.group ? ` · ${esc(student.group)}` : ''}</small></span><span class="status-chip success">آماده</span></div>`).join('')}${students.length > 12 ? `<div class="notice"><span>${fa(students.length - 12)} دانش‌آموز دیگر نیز بررسی شده‌اند.</span></div>` : ''}</div>` : ''}</section>`;
  }
  const schoolName = draft.schoolMode === 'existing' ? schoolById(draft.schoolId)?.name : draft.schoolName;
  const students = draft.importedStudents.length ? draft.importedStudents : parseStudentLines(draft.studentsText).rows;
  return `<section class="wizard-card"><h2>بازبینی و تأیید مدیر</h2><p>پیش از ثبت، اطلاعات نهایی را بررسی کنید.</p><dl class="review-card"><div class="review-row"><dt>مدرسه</dt><dd>${esc(schoolName || '—')}</dd></div><div class="review-row"><dt>کلاس</dt><dd>پایه ${esc(draft.grade)} · ${esc(draft.classTitle)} · کد ${esc(draft.classCode)}</dd></div><div class="review-row"><dt>سال تحصیلی</dt><dd>${esc(draft.schoolYear)}</dd></div><div class="review-row"><dt>دانش‌آموزان</dt><dd>${fa(students.length)} نفر</dd></div></dl><div class="section notice warning"><strong>تأیید محلی</strong><span>این تأیید جایگزین اتصال رسمی به سیدا نیست و فقط ساختار همین دستگاه را فعال می‌کند.</span></div>${model.localAdmin?.enabled ? `<div class="field"><label for="setup-pin">رمز مدیر ${esc(model.localAdmin.managerName)}</label><input id="setup-pin" type="password" inputmode="numeric" maxlength="8" autocomplete="current-password"></div>` : `<div class="field"><label for="setup-manager-name">نام مدیر تأییدکننده</label><input id="setup-manager-name" value="${esc(draft.managerName)}"></div><div class="field-grid"><div class="field"><label for="setup-pin">رمز ۴ تا ۸ رقمی</label><input id="setup-pin" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div><div class="field"><label for="setup-pin-confirm">تکرار رمز</label><input id="setup-pin-confirm" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div></div>`}</section>`;
}

function parseStudentLines(text) {
  const rows = [];
  const errors = [];
  const seen = new Set();
  String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean).forEach((line, index) => {
    const parts = line.split(/[|\t]/).map(item => normalize(item));
    if (parts.length < 2) {
      errors.push(`سطر ${fa(index + 1)}: نام و شناسه را با علامت | جدا کنید.`);
      return;
    }
    const [name, rawCode, group = ''] = parts;
    const studentCode = normalizeId(rawCode);
    if (name.length < 3 || !studentCode) {
      errors.push(`سطر ${fa(index + 1)}: نام یا شناسه کامل نیست.`);
      return;
    }
    if (seen.has(studentCode)) {
      errors.push(`سطر ${fa(index + 1)}: شناسه ${esc(studentCode)} تکراری است.`);
      return;
    }
    seen.add(studentCode);
    const nameParts = name.split(/\s+/);
    rows.push({ name, firstName: nameParts[0] || '', lastName: nameParts.slice(1).join(' '), studentCode, group });
  });
  return { rows, errors };
}

function assessmentLandingView() {
  const cls = currentClass();
  if (!cls) return `${contextSwitcher()}${emptyClassState()}`;
  const recent = model.assessments.filter(item => item.classId === cls.id && item.semester === state.semester)
    .sort((a, b) => String(b.updatedAt || b.createdAt).localeCompare(String(a.updatedAt || a.createdAt))).slice(0, 12);
  return `${contextSwitcher()}<section class="page-heading"><h1>ثبت ارزشیابی</h1></section><div class="option-grid"><button class="option-card" data-action="start-assessment" data-mode="individual"><b>فردی</b><small>یک دانش‌آموز</small></button><button class="option-card" data-action="start-assessment" data-mode="group"><b>گروهی</b><small>یک گروه</small></button><button class="option-card" data-action="start-assessment" data-mode="class"><b>کل کلاس</b><small>همه دانش‌آموزان</small></button></div><section class="section"><div class="section-title"><h2>ثبت‌های اخیر</h2></div>${recent.length ? `<div class="list-card">${recent.map(record => {
    const student = model.students.find(item => item.id === record.studentId);
    return `<button class="list-row" data-action="open-record" data-id="${record.id}"><span class="score-chip">${fa(record.score)}</span><span class="list-row__body"><b>${esc(student?.name || 'دانش‌آموز')}</b><small>${esc(record.criterion || '')} · ${esc(record.date || '')}</small></span><span class="list-row__meta">${icon('arrow')}</span></button>`;
  }).join('')}</div>` : '<div class="empty-state"><h3>هنوز ثبت ارزشیابی ندارید</h3><p>یکی از روش‌های ثبت را انتخاب کنید.</p></div>'}</section>`;
}

function createAssessmentDraft(mode = 'individual', targetId = null, editId = null) {
  if (editId) {
    const record = model.assessments.find(item => item.id === editId);
    if (!record) return null;
    return {
      step: 4, mode: 'individual', editId: record.id, savedId: null, startedAt: Date.now(),
      targetId: record.studentId, date: record.date || today(), month: record.month || MONTHS[state.semester][0],
      activity: record.activity || '', categoryKey: record.categoryKey || 'analysis', criterionKey: record.criterionKey || 'problemAnalysis',
      level: Number(record.level || 0), evidenceType: record.evidenceType || 'direct', notePreset: record.notePreset || '', note: record.note || '',
      bonusScore: Number(record.bonusScore || 0), bonusReason: record.bonusReason || '', exceptions: {},
    };
  }
  const groups = [...new Set(classStudents().map(student => student.group).filter(Boolean))];
  return {
    step: 1, mode, editId: null, savedId: null, startedAt: Date.now(),
    targetId: targetId || (mode === 'individual' ? classStudents()[0]?.id : mode === 'group' ? groups[0] : 'all'),
    date: today(), month: MONTHS[state.semester][0], activity: '', categoryKey: 'analysis', criterionKey: 'problemAnalysis',
    level: 0, evidenceType: 'direct', notePreset: '', note: '', bonusScore: 0, bonusReason: '', exceptions: {},
  };
}

function assessmentFlowView() {
  if (!state.assessment) state.assessment = createAssessmentDraft(state.params.mode || 'individual', state.params.student || null, state.params.edit || null);
  if (!state.assessment) return '<div class="empty-state"><h2>ثبت پیدا نشد</h2></div>';
  if (state.assessment.savedId) return assessmentSuccessView();
  return `<section class="page-heading"><h1>${state.assessment.editId ? 'ویرایش ارزشیابی' : 'ثبت ارزشیابی'}</h1></section><div class="assessment-shell"><div class="wizard-status" aria-live="polite"><span>مرحله ${fa(state.assessment.step)} از ۴</span><strong>${['دانش‌آموز', 'فعالیت', 'معیار', 'نمره و ثبت'][state.assessment.step - 1]}</strong></div><div class="assessment-progress"><div class="assessment-progress__bar"><span style="width:${state.assessment.step * 25}%"></span></div><div class="assessment-progress__labels"><span class="${state.assessment.step === 1 ? 'is-current' : ''}">دانش‌آموز</span><span class="${state.assessment.step === 2 ? 'is-current' : ''}">فعالیت</span><span class="${state.assessment.step === 3 ? 'is-current' : ''}">معیار</span><span class="${state.assessment.step === 4 ? 'is-current' : ''}">نمره و ثبت</span></div></div><div id="assessment-context">${assessmentContext()}</div><div id="assessment-stage" class="assessment-stage">${assessmentStage()}</div><div class="assessment-actions"><button class="ghost-btn" data-action="assessment-back">${state.assessment.step === 1 ? 'انصراف' : 'مرحله قبل'}</button><button class="primary-btn" data-action="assessment-next">${state.assessment.step === 4 ? `ثبت نمره ${state.assessment.level ? fa(finalScore()) : ''}` : 'ادامه'}</button></div></div>`;
}

function assessmentContext() {
  const draft = state.assessment;
  const student = model.students.find(item => item.id === draft.targetId);
  const criterion = criterionInfo(draft.categoryKey, draft.criterionKey);
  const items = [];
  if (draft.mode === 'individual' && student) items.push(student.name);
  if (draft.mode === 'group' && draft.targetId) items.push(`گروه ${draft.targetId}`);
  if (draft.mode === 'class') items.push('کل کلاس');
  if (draft.activity) items.push(draft.activity);
  if (criterion && draft.step > 3) items.push(criterion.title);
  if (draft.level) items.push(`نمره ${fa(finalScore())}`);
  return items.length ? `<div class="assessment-context">${items.map(item => `<span>${esc(item)}</span>`).join('')}</div>` : '';
}

function assessmentStage() {
  const draft = state.assessment;
  if (draft.step === 1) return assessmentTargetStage();
  if (draft.step === 2) return assessmentActivityStage();
  if (draft.step === 3) return assessmentCriterionStage();
  return assessmentScoreStage();
}

function assessmentTargetStage() {
  const draft = state.assessment;
  const groups = [...new Set(classStudents().map(student => student.group).filter(Boolean))];
  return `<h2>چه کسی ارزشیابی می‌شود؟</h2><p>روش ثبت و دانش‌آموز یا گروه را انتخاب کنید.</p><div class="mode-grid"><button class="mode-card ${draft.mode === 'individual' ? 'is-selected' : ''}" data-action="assessment-mode" data-value="individual"><b>فردی</b><small>یک دانش‌آموز</small></button><button class="mode-card ${draft.mode === 'group' ? 'is-selected' : ''}" data-action="assessment-mode" data-value="group" ${groups.length ? '' : 'disabled'}><b>گروهی</b><small>${groups.length ? 'یک گروه' : 'گروه تعریف نشده'}</small></button><button class="mode-card ${draft.mode === 'class' ? 'is-selected' : ''}" data-action="assessment-mode" data-value="class"><b>کل کلاس</b><small>همه دانش‌آموزان</small></button></div><div class="section">${draft.mode === 'individual' ? `<div class="field"><label for="assessment-target">دانش‌آموز</label><select id="assessment-target">${classStudents().map(student => `<option value="${student.id}" ${student.id === draft.targetId ? 'selected' : ''}>${esc(student.name)} · ${esc(student.studentCode || '')}</option>`).join('')}</select></div>` : draft.mode === 'group' ? `<div class="field"><label for="assessment-target">گروه</label><select id="assessment-target">${groups.map(group => `<option value="${esc(group)}" ${group === draft.targetId ? 'selected' : ''}>${esc(group)}</option>`).join('')}</select></div>` : '<div class="notice"><strong>کل کلاس</strong><span>برای همه دانش‌آموزان فعال این کلاس یک ثبت ایجاد می‌شود.</span></div>'}</div>`;
}

function assessmentActivityStage() {
  const draft = state.assessment;
  const recent = [...new Set(model.assessments.filter(item => item.classId === currentClass()?.id).map(item => item.activity).filter(Boolean))].slice(-5).reverse();
  const suggested = [...new Set([...recent, ...Object.values(RUBRIC_LIBRARY).flatMap(item => item.activities)])].slice(0, 14);
  return `<h2>چه فعالیتی مشاهده شد؟</h2><p>عنوان کوتاه و مشخص انتخاب کنید؛ این عنوان در گزارش دانش‌آموز ثبت می‌شود.</p><div class="activity-chips">${suggested.map(activity => `<button data-action="assessment-activity" data-value="${esc(activity)}" class="${draft.activity === activity ? 'is-selected' : ''}">${esc(activity)}</button>`).join('')}</div><div class="section field"><label for="assessment-activity-custom">عنوان دلخواه</label><input id="assessment-activity-custom" value="${suggested.includes(draft.activity) ? '' : esc(draft.activity)}" placeholder="مثال: ساخت اتصال چوبی"></div><div class="field-grid"><div class="field"><label for="assessment-date">تاریخ</label><input id="assessment-date" type="date" value="${esc(draft.date)}"></div><div class="field"><label for="assessment-month">ماه آموزشی</label><select id="assessment-month">${MONTHS[state.semester].map(month => `<option ${month === draft.month ? 'selected' : ''}>${month}</option>`).join('')}</select></div></div>`;
}

function assessmentCriterionStage() {
  const draft = state.assessment;
  const category = RUBRIC_LIBRARY[draft.categoryKey];
  return `<h2>کدام شایستگی بررسی شد؟</h2><p>ابتدا حوزه و سپس معیار دقیق ارزشیابی را انتخاب کنید.</p><div class="category-list">${Object.entries(RUBRIC_LIBRARY).map(([key, item]) => `<button class="category-card ${key === draft.categoryKey ? 'is-selected' : ''}" data-action="assessment-category" data-value="${key}"><span>${item.icon}</span><span><b>${esc(item.title)}</b><small>${esc(item.question)}</small></span></button>`).join('')}</div><section class="section"><div class="section-title"><h2>معیار</h2></div><div class="criterion-list">${Object.entries(category.criteria).map(([key, item]) => `<button class="criterion-card ${key === draft.criterionKey ? 'is-selected' : ''}" data-action="assessment-criterion" data-value="${key}"><span><b>${esc(item.title)}</b><small>${esc(item.question)}</small></span></button>`).join('')}</div></section>`;
}

function finalScore() {
  const base = levelInfo(state.assessment?.level)?.score || 0;
  const bonus = state.assessment?.mode === 'individual' ? Number(state.assessment?.bonusScore || 0) : 0;
  return clamp(base + bonus, 0, 20);
}

function assessmentScoreStage() {
  const draft = state.assessment;
  const criterion = criterionInfo(draft.categoryKey, draft.criterionKey);
  const base = levelInfo(draft.level)?.score || 0;
  return `<h2>سطح عملکرد و نمره</h2><p>توصیف مطابق عملکرد دانش‌آموز را انتخاب کنید.</p><div class="level-list">${RUBRIC_LEVELS.map(item => `<button class="level-card ${Number(draft.level) === item.level ? 'is-selected' : ''}" data-action="assessment-level" data-value="${item.level}"><span class="level-card__number">${fa(item.level)}</span><span class="level-card__body"><b>${esc(item.title)}</b><p>${esc(criterion.levels[item.level])}</p><span class="level-card__score">نمره پایه ${fa(item.score)} از ۲۰</span></span></button>`).join('')}</div><div id="score-panel">${draft.level ? scorePanel(base) : ''}</div>${draft.level && draft.mode === 'individual' ? `<section class="section form-card"><div class="section-title"><h2>نمره تشویقی</h2><small>حداکثر ۲ نمره</small></div><div class="bonus-grid">${[0, .5, 1, 1.5, 2].map(value => `<button data-action="assessment-bonus" data-value="${value}" class="${Number(draft.bonusScore) === value ? 'is-selected' : ''}">${value ? `+${fa(value)}` : '۰'}</button>`).join('')}</div><div id="bonus-reason-slot">${Number(draft.bonusScore) > 0 ? `<div class="field section"><label for="assessment-bonus-reason">دلیل نمره تشویقی</label><textarea id="assessment-bonus-reason" maxlength="180" placeholder="رفتار یا دستاورد مشخص را بنویسید.">${esc(draft.bonusReason)}</textarea></div>` : ''}</div></section>` : ''}${draft.level ? `<section class="section form-card"><div class="field"><label>شاهد ارزشیابی</label><div class="activity-chips evidence-chips">${EVIDENCE_TYPES.map(item => `<button data-action="assessment-evidence" data-value="${item.id}" class="${draft.evidenceType === item.id ? 'is-selected' : ''}">${esc(item.title)}</button>`).join('')}</div></div><details class="optional-details" ${draft.notePreset || draft.note ? 'open' : ''}><summary>یادداشت اختیاری</summary><div class="optional-details__body"><div class="field"><label>عبارت آماده</label><div class="activity-chips">${NOTE_PRESETS.map(note => `<button data-action="assessment-note-preset" data-value="${esc(note)}" class="${draft.notePreset === note ? 'is-selected' : ''}">${esc(note)}</button>`).join('')}</div></div><div class="field"><label for="assessment-note">توضیح تکمیلی</label><textarea id="assessment-note" maxlength="240" placeholder="اختیاری">${esc(draft.note)}</textarea></div></div></details>${assessmentReview()}</section>` : ''}`;
}

function scorePanel(base) {
  const bonus = state.assessment.mode === 'individual' ? Number(state.assessment.bonusScore || 0) : 0;
  return `<div class="score-panel"><div class="score-panel__item"><small>نمره پایه</small><b>${fa(base)}</b></div><span class="score-panel__operator">+</span><div class="score-panel__item"><small>تشویقی</small><b>${fa(bonus)}</b></div><span class="score-panel__operator">=</span><div class="score-panel__final"><small>نمره نهایی</small><b>${fa(finalScore())}</b></div></div>`;
}

function assessmentReview() {
  const draft = state.assessment;
  const criterion = criterionInfo(draft.categoryKey, draft.criterionKey);
  const target = draft.mode === 'individual' ? model.students.find(item => item.id === draft.targetId)?.name : draft.mode === 'group' ? `گروه ${draft.targetId}` : 'کل کلاس';
  return `<div class="section-title"><h2>خلاصه ثبت</h2></div><dl class="review-card"><div class="review-row"><dt>دانش‌آموز</dt><dd>${esc(target || '—')}</dd></div><div class="review-row"><dt>فعالیت</dt><dd>${esc(draft.activity || '—')}</dd></div><div class="review-row"><dt>معیار</dt><dd>${esc(criterion?.title || '—')}</dd></div><div class="review-row"><dt>سطح</dt><dd>${esc(levelInfo(draft.level)?.title || '—')}</dd></div><div class="review-row"><dt>نمره نهایی</dt><dd>${fa(finalScore())} از ۲۰</dd></div></dl>`;
}

function assessmentSuccessView() {
  const draft = state.assessment;
  const saved = model.assessments.find(item => item.id === draft.savedId);
  return `<section class="success-panel"><span class="success-panel__icon">✓</span><h2>${draft.editId ? 'ویرایش ذخیره شد' : 'ارزشیابی ثبت شد'}</h2><p>نمره ${fa(saved?.score ?? finalScore())} از ۲۰ ذخیره شد.</p><div class="button-row wide"><button class="ghost-btn" data-action="open-record" data-id="${saved?.id || ''}">مشاهده جزئیات</button><button class="primary-btn" data-action="assessment-another">ثبت بعدی</button></div></section>`;
}

function studentView(studentId) {
  const student = model.students.find(item => item.id === studentId);
  if (!student) return '<div class="empty-state"><h2>دانش‌آموز پیدا نشد</h2></div>';
  const cls = classById(student.classId);
  const records = model.assessments.filter(item => item.studentId === student.id && item.semester === state.semester)
    .sort((a, b) => String(b.updatedAt || b.createdAt).localeCompare(String(a.updatedAt || a.createdAt)));
  const average = records.length ? records.reduce((sum, item) => sum + Number(item.score || 0), 0) / records.length : null;
  return `<section class="page-heading page-heading--row"><div><h1>${esc(student.name)}</h1><p>${esc(student.studentCode || 'بدون شناسه')} · پایه ${esc(cls?.grade || '')} · ${esc(cls?.title || '')}</p></div><button class="primary-btn" data-action="assess-student" data-id="${student.id}">${icon('plus')} ثبت جدید</button></section><section class="stats-grid"><article class="stat-card"><b>${fa(records.length)}</b><span>تعداد ثبت</span></article><article class="stat-card"><b>${average === null ? '—' : fa(average.toFixed(1))}</b><span>میانگین</span></article><article class="stat-card"><b>${fa(records.filter(item => Number(item.bonusScore || 0) > 0).length)}</b><span>ثبت تشویقی</span></article></section><section class="section"><div class="section-title"><h2>سوابق ارزشیابی</h2></div>${records.length ? `<div class="list-card">${records.map(record => `<button class="list-row" data-action="open-record" data-id="${record.id}"><span class="score-chip">${fa(record.score)}</span><span class="list-row__body"><b>${esc(record.criterion || '')}</b><small>${esc(record.activity || '')} · ${esc(record.date || '')}</small></span><span class="list-row__meta">${icon('arrow')}</span></button>`).join('')}</div>` : '<div class="empty-state"><h3>سابقه‌ای ثبت نشده است</h3></div>'}</section>`;
}

function recordView(recordId) {
  const record = model.assessments.find(item => item.id === recordId);
  if (!record) return '<div class="empty-state"><h2>ثبت پیدا نشد</h2></div>';
  const student = model.students.find(item => item.id === record.studentId);
  return `<section class="page-heading page-heading--row"><div><h1>جزئیات ارزشیابی</h1><p>${esc(student?.name || 'دانش‌آموز')} · ${esc(record.date || '')}</p></div><button class="ghost-btn" data-action="edit-record" data-id="${record.id}">${icon('edit')} ویرایش</button></section><section class="form-card"><div class="success-panel"><span class="success-panel__icon">${fa(record.score)}</span><h2>${esc(record.criterion || '')}</h2><p>${esc(record.activity || '')}</p></div><section class="section"><dl class="review-card"><div class="review-row"><dt>سطح عملکرد</dt><dd>${esc(levelInfo(record.level)?.title || '')}</dd></div><div class="review-row"><dt>نمره پایه</dt><dd>${fa(record.baseScore ?? levelInfo(record.level)?.score ?? '')}</dd></div><div class="review-row"><dt>نمره تشویقی</dt><dd>${fa(record.bonusScore || 0)}</dd></div>${record.bonusReason ? `<div class="review-row"><dt>دلیل تشویقی</dt><dd>${esc(record.bonusReason)}</dd></div>` : ''}<div class="review-row"><dt>نوع شاهد</dt><dd>${esc(record.evidenceTitle || '')}</dd></div><div class="review-row"><dt>یادداشت</dt><dd>${esc([record.notePreset, record.note].filter(Boolean).join(' · ') || '—')}</dd></div><div class="review-row"><dt>نسخه روبریک</dt><dd>${esc(record.rubricVersion || RUBRIC_VERSION)}</dd></div></dl></section></section>`;
}

function communityView() {
  const tabs = [['published', 'منتشرشده'], ['mine', 'محتوای من'], ['podcasts', 'پادکست‌ها']];
  const published = model.content.filter(item => item.status === 'published');
  const mine = model.content.filter(item => item.authorId === CURRENT_USER_ID);
  const podcasts = model.content.filter(item => item.type === 'podcast');
  const list = state.communityTab === 'mine' ? mine : state.communityTab === 'podcasts' ? podcasts : published;
  return `<section class="page-heading page-heading--row"><div><h1>هم‌افزایی دبیران</h1></div><button class="primary-btn" data-action="new-content">${icon('plus')} محتوای جدید</button></section><div class="tabs" role="tablist">${tabs.map(([id, label]) => `<button data-action="community-tab" data-tab="${id}" aria-selected="${state.communityTab === id}">${label}</button>`).join('')}</div>${state.communityTab === 'podcasts' ? `<section class="section"><div class="section-title"><h2>کانال‌های پادکست</h2><button class="text-btn" data-action="new-channel">ساخت کانال</button></div>${channelList()}</section>` : ''}<section class="section">${contentList(list)}</section><section class="notice"><span>هم‌رسانی آنلاین و دنبال‌کردن کانال‌ها پس از اتصال سامانه مرکزی فعال می‌شود.</span></section>`;
}

function contentList(list) {
  if (!list.length) return '<div class="empty-state"><h3>محتوایی وجود ندارد</h3><p>محتوای آموزشی یا قسمت پادکست جدید ثبت کنید.</p></div>';
  return `<div class="content-grid">${list.map(content => `<article class="content-card"><button class="content-card__main" data-action="edit-content" data-id="${content.id}"><div class="content-card__meta"><span>${contentTypeLabel(content.type)}</span><span>${esc(STATUS_LABELS[content.status] || content.status || 'پیش‌نویس')}</span>${content.grade ? `<span>پایه ${esc(content.grade)}</span>` : ''}</div><h3>${esc(content.title)}</h3>${content.summary ? `<p>${esc(content.summary)}</p>` : ''}</button><div class="content-card__footer"><span>${esc(content.authorName || model.profile.name || 'دبیر')}</span><span>${esc(content.updatedAt?.slice(0, 10) || content.createdAt?.slice(0, 10) || '')}</span></div></article>`).join('')}</div>`;
}

function channelList() {
  if (!model.channels.length) return '<div class="empty-state"><h3>کانالی ساخته نشده است</h3><p>هر کانال می‌تواند چند قسمت پادکست داشته باشد.</p></div>';
  return `<div class="content-grid">${model.channels.map(channel => `<article class="channel-card"><span class="channel-card__icon">${icon('podcast')}</span><span><h3>${esc(channel.title)}</h3><p>${esc(channel.description || '')}</p></span><button class="text-btn" data-action="edit-channel" data-id="${channel.id}">ویرایش</button></article>`).join('')}</div>`;
}

function contentTypeLabel(type) {
  return ({ experience: 'تجربه کلاسی', learning: 'محتوای آموزشی', podcast: 'پادکست', question: 'پرسش حرفه‌ای' })[type] || 'محتوا';
}

function contentEditorView(contentId) {
  const content = model.content.find(item => item.id === contentId);
  return `<section class="page-heading"><h1>${content ? 'ویرایش محتوا' : 'محتوای جدید'}</h1></section><form id="content-form" class="form-card" data-id="${content?.id || ''}"><div class="field-grid"><div class="field"><label for="content-type">نوع محتوا</label><select id="content-type"><option value="experience" ${content?.type === 'experience' ? 'selected' : ''}>تجربه کلاسی</option><option value="learning" ${content?.type === 'learning' ? 'selected' : ''}>محتوای آموزشی</option><option value="question" ${content?.type === 'question' ? 'selected' : ''}>پرسش حرفه‌ای</option><option value="podcast" ${content?.type === 'podcast' ? 'selected' : ''}>قسمت پادکست</option></select></div><div class="field"><label for="content-grade">پایه</label><select id="content-grade"><option value="">همه پایه‌ها</option><option ${content?.grade === 'هفتم' ? 'selected' : ''}>هفتم</option><option ${content?.grade === 'هشتم' ? 'selected' : ''}>هشتم</option><option ${content?.grade === 'نهم' ? 'selected' : ''}>نهم</option></select></div></div><div class="field"><label for="content-title">عنوان</label><input id="content-title" value="${esc(content?.title || '')}" maxlength="100" required></div><div class="field"><label for="content-summary">خلاصه</label><textarea id="content-summary" maxlength="280" required>${esc(content?.summary || '')}</textarea></div><div class="field"><label for="content-body">متن یا شرح محتوا</label><textarea id="content-body" maxlength="4000">${esc(content?.body || '')}</textarea></div><div class="field"><label for="content-channel">کانال پادکست</label><select id="content-channel"><option value="">بدون کانال</option>${model.channels.map(channel => `<option value="${channel.id}" ${content?.channelId === channel.id ? 'selected' : ''}>${esc(channel.title)}</option>`).join('')}</select></div><div class="button-row"><button type="button" class="ghost-btn" data-action="save-content-draft">ذخیره پیش‌نویس</button><button type="submit" class="primary-btn">ارسال برای بررسی</button></div></form>`;
}

function channelEditorView(channelId) {
  const channel = model.channels.find(item => item.id === channelId);
  return `<section class="page-heading"><h1>${channel ? 'ویرایش کانال' : 'کانال پادکست جدید'}</h1></section><form id="channel-form" class="form-card" data-id="${channel?.id || ''}"><div class="field"><label for="channel-title">نام کانال</label><input id="channel-title" value="${esc(channel?.title || '')}" maxlength="80" required></div><div class="field"><label for="channel-topic">موضوع</label><input id="channel-topic" value="${esc(channel?.topic || '')}" maxlength="80" placeholder="مثال: تجربه‌های تدریس پایه هفتم"></div><div class="field"><label for="channel-description">توضیح کوتاه</label><textarea id="channel-description" maxlength="300">${esc(channel?.description || '')}</textarea></div><button class="primary-btn wide" type="submit">ذخیره کانال</button></form>`;
}

function moreView() {
  return `<section class="page-heading"><h1>تنظیمات</h1></section>
    <section class="settings-group"><div class="settings-list">
      <button class="settings-row" data-action="profile-settings"><span class="settings-row__icon">${icon('user')}</span><span class="settings-row__body"><b>پروفایل دبیر</b><small>${esc(model.profile.name || 'نام ثبت نشده')}</small></span>${icon('arrow')}</button>
      <button class="settings-row" data-action="appearance-settings"><span class="settings-row__icon">${icon('palette')}</span><span class="settings-row__body"><b>نمایش</b><small>رنگ و تراکم صفحه</small></span>${icon('arrow')}</button>
      <button class="settings-row" data-action="backup-center"><span class="settings-row__icon">${icon('storage')}</span><span class="settings-row__body"><b>پشتیبان و داده‌ها</b><small>دریافت، بازیابی و نگهداری</small></span>${icon('arrow')}</button>
    </div></section><div class="version-line">نسخه ${esc(APP_VERSION)} · روبریک ${esc(RUBRIC_VERSION)}</div>`;
}

function helpView() {
  return `<section class="page-heading"><h1>راهنمای کار</h1></section><section class="form-card"><div class="section-title"><h2>۱. تعریف کلاس</h2></div><p>از تب «کلاس‌ها» روی «کلاس جدید» بزنید. مدرسه، کلاس، دانش‌آموزان و تأیید مدیر در چهار مرحله ثبت می‌شود.</p></section><section class="form-card section"><div class="section-title"><h2>۲. ثبت ارزشیابی</h2></div><p>از تب «ثبت» روش فردی، گروهی یا کل کلاس را انتخاب کنید. در آخرین مرحله نمره پایه، تشویقی و نمره نهایی پیش از ذخیره نمایش داده می‌شود.</p></section><section class="form-card section"><div class="section-title"><h2>۳. ویرایش</h2></div><p>از پرونده دانش‌آموز یا فهرست ثبت‌های اخیر وارد جزئیات شوید و «ویرایش» را انتخاب کنید.</p></section><section class="form-card section"><div class="section-title"><h2>۴. پشتیبان‌گیری</h2></div><p>از منوی «بیشتر» یک فایل پشتیبان دریافت کنید. اطلاعات این نسخه روی دستگاه ذخیره می‌شود.</p></section>`;
}

function openDialog(title, body, footer = '') {
  dialog.innerHTML = `<div class="dialog-shell"><header class="dialog-head"><h2>${esc(title)}</h2><button class="icon-btn" data-action="close-dialog" aria-label="بستن">${icon('close')}</button></header><div class="dialog-body">${body}</div>${footer ? `<footer class="dialog-foot">${footer}</footer>` : ''}</div>`;
  if (!dialog.open) dialog.showModal();
  requestAnimationFrame(() => dialog.querySelector('input, select, textarea, button')?.focus({ preventScroll: true }));
}

function closeDialog() {
  if (dialog.open) dialog.close();
  dialog.innerHTML = '';
}

function contextDialog() {
  if (!model.classes.length) {
    openDialog('کلاس جاری', '<div class="empty-state"><h3>کلاسی تعریف نشده است</h3><p>ابتدا یک کلاس بسازید.</p></div>', '<button class="primary-btn" data-action="new-class">تعریف کلاس</button>');
    return;
  }
  const schoolId = state.selectedSchoolId || model.schools[0]?.id;
  const classes = model.classes.filter(item => item.schoolId === schoolId);
  openDialog('انتخاب کلاس جاری', `<div class="field"><label for="context-school">مدرسه</label><select id="context-school">${model.schools.map(school => `<option value="${school.id}" ${school.id === schoolId ? 'selected' : ''}>${esc(school.name)}</option>`).join('')}</select></div><div class="field"><label for="context-class">کلاس</label><select id="context-class">${classes.map(cls => `<option value="${cls.id}" ${cls.id === state.selectedClassId ? 'selected' : ''}>پایه ${esc(cls.grade)} · ${esc(cls.title)}</option>`).join('')}</select></div><div class="field"><label>نیم‌سال</label><div class="option-grid"><button class="option-card ${state.semester === 'first' ? 'is-selected' : ''}" data-action="context-semester" data-value="first"><b>نیم‌سال اول</b><small>مهر تا دی</small></button><button class="option-card ${state.semester === 'second' ? 'is-selected' : ''}" data-action="context-semester" data-value="second"><b>نیم‌سال دوم</b><small>بهمن تا خرداد</small></button></div></div>`, '<button class="ghost-btn" data-action="close-dialog">انصراف</button><button class="primary-btn" data-action="save-context">تأیید</button>');
}

function profileDialog() {
  openDialog('پروفایل دبیر', `<div class="field"><label for="profile-name">نام و نام خانوادگی</label><input id="profile-name" value="${esc(model.profile.name || '')}" autocomplete="name"></div><div class="field"><label for="profile-role">عنوان</label><input id="profile-role" value="${esc(model.profile.roleLabel || 'دبیر کار و فناوری')}"></div>`, '<button class="ghost-btn" data-action="close-dialog">انصراف</button><button class="primary-btn" data-action="save-profile">ذخیره</button>');
}

function appearanceDialog() {
  openDialog('تنظیم نمایش', `<div class="field"><label for="appearance-theme">حالت رنگ</label><select id="appearance-theme"><option value="light" ${model.settings.theme === 'light' ? 'selected' : ''}>روشن</option><option value="dark" ${model.settings.theme === 'dark' ? 'selected' : ''}>تیره</option></select></div><div class="field"><label for="appearance-density">تراکم صفحه</label><select id="appearance-density"><option value="comfortable" ${model.settings.density !== 'compact' ? 'selected' : ''}>راحت</option><option value="compact" ${model.settings.density === 'compact' ? 'selected' : ''}>فشرده</option></select></div>`, '<button class="ghost-btn" data-action="close-dialog">انصراف</button><button class="primary-btn" data-action="save-appearance">اعمال</button>');
}

async function backupCenterDialog() {
  const info = await storageInfo();
  openDialog('پشتیبان و داده‌ها', `<div class="settings-list compact-settings">
    <button class="settings-row" data-action="export-backup"><span class="settings-row__icon">${icon('download')}</span><span class="settings-row__body"><b>دریافت پشتیبان</b><small>ذخیره همه اطلاعات در یک فایل</small></span>${icon('arrow')}</button>
    <button class="settings-row" data-action="import-backup"><span class="settings-row__icon">${icon('upload')}</span><span class="settings-row__body"><b>بازیابی پشتیبان</b><small>ادغام فایل با اطلاعات فعلی</small></span>${icon('arrow')}</button>
    <button class="settings-row" data-action="storage-settings"><span class="settings-row__icon">${icon('storage')}</span><span class="settings-row__body"><b>فضای ذخیره</b><small>${formatBytes(info.usage)} مصرف شده</small></span>${icon('arrow')}</button>
    <button class="settings-row danger-row" data-action="data-management"><span class="settings-row__icon">${icon('trash')}</span><span class="settings-row__body"><b>پاک‌کردن همه داده‌ها</b><small>غیرقابل بازگشت بدون پشتیبان</small></span>${icon('arrow')}</button>
  </div>`, '<button class="ghost-btn" data-action="close-dialog">بستن</button>');
}

async function storageDialog() {
  const info = await storageInfo();
  const percent = info.quota ? Math.min(100, Math.round((info.usage / info.quota) * 100)) : 0;
  openDialog('فضای ذخیره', `<dl class="review-card"><div class="review-row"><dt>مصرف‌شده</dt><dd>${formatBytes(info.usage)}</dd></div><div class="review-row"><dt>ظرفیت تقریبی</dt><dd>${formatBytes(info.quota)}</dd></div><div class="review-row"><dt>درصد مصرف</dt><dd>${fa(percent)}٪</dd></div><div class="review-row"><dt>ماندگاری</dt><dd>${info.persisted ? 'فعال' : 'فعال نشده'}</dd></div></dl><div class="notice warning section"><strong>حفاظت از داده</strong><span>پاک‌کردن داده‌های مرورگر یا حذف برنامه می‌تواند اطلاعات محلی را از بین ببرد. پشتیبان‌گیری منظم ضروری است.</span></div>`, '<button class="ghost-btn" data-action="close-dialog">بستن</button><button class="primary-btn" data-action="persist-storage">فعال‌سازی ماندگاری</button>');
}

function dataManagementDialog() {
  openDialog('مدیریت داده‌ها', `<div class="notice danger"><strong>پاک‌کردن کامل</strong><span>همه مدرسه‌ها، کلاس‌ها، دانش‌آموزان، نمرات و محتواهای این دستگاه حذف می‌شوند.</span></div><div class="field section"><label for="delete-confirm">برای تأیید، عبارت «حذف کامل» را بنویسید.</label><input id="delete-confirm" autocomplete="off"></div>`, '<button class="ghost-btn" data-action="close-dialog">انصراف</button><button class="danger-btn" data-action="clear-all-data">پاک‌کردن همه داده‌ها</button>');
}

function addStudentDialog(classId) {
  const cls = classById(classId);
  openDialog('افزودن دانش‌آموز', `<div class="field"><label for="student-name">نام و نام خانوادگی</label><input id="student-name" autocomplete="off"></div><div class="field-grid"><div class="field"><label for="student-code">شناسه دانش‌آموز</label><input id="student-code" autocomplete="off"></div><div class="field"><label for="student-group">گروه</label><input id="student-group" placeholder="اختیاری"></div></div><div class="field-grid"><div class="field"><label for="student-father">نام پدر</label><input id="student-father"></div><div class="field"><label for="student-birth">تاریخ تولد</label><input id="student-birth" placeholder="۱۳۹۲/۰۲/۱۵"></div></div><input id="student-class-id" type="hidden" value="${esc(cls?.id || '')}">`, '<button class="ghost-btn" data-action="close-dialog">انصراف</button><button class="primary-btn" data-action="save-student">افزودن</button>');
}

function classReportDialog(classId) {
  const cls = classById(classId || currentClass()?.id);
  if (!cls) return;
  const students = classStudents(cls.id);
  const records = model.assessments.filter(item => item.classId === cls.id && item.semester === state.semester);
  openDialog('گزارش نمرات کلاس', `<div class="list-card">${students.map(student => {
    const own = records.filter(item => item.studentId === student.id);
    const avg = own.length ? own.reduce((sum, item) => sum + Number(item.score || 0), 0) / own.length : null;
    return `<div class="list-row"><span class="list-row__avatar">${esc(student.name.charAt(0))}</span><span class="list-row__body"><b>${esc(student.name)}</b><small>${fa(own.length)} ثبت</small></span><span class="score-chip">${avg === null ? '—' : fa(avg.toFixed(1))}</span></div>`;
  }).join('')}</div>`, '<button class="ghost-btn" data-action="close-dialog">بستن</button><button class="primary-btn" data-action="export-class" data-id="'+esc(cls.id)+'">دریافت CSV</button>');
}

function captureSetupStage() {
  const draft = state.setup;
  if (!draft) return;
  if (draft.step === 1) {
    if (document.querySelector('#setup-school-id')) draft.schoolId = document.querySelector('#setup-school-id').value;
    if (document.querySelector('#setup-school-code')) draft.schoolCode = normalizeId(document.querySelector('#setup-school-code').value);
    if (document.querySelector('#setup-school-name')) draft.schoolName = normalize(document.querySelector('#setup-school-name').value);
    if (document.querySelector('#setup-province')) draft.province = normalize(document.querySelector('#setup-province').value);
    if (document.querySelector('#setup-district')) draft.district = normalize(document.querySelector('#setup-district').value);
  }
  if (draft.step === 2) {
    draft.schoolYear = normalize(document.querySelector('#setup-year')?.value);
    draft.grade = document.querySelector('#setup-grade')?.value || draft.grade;
    draft.classCode = normalizeId(document.querySelector('#setup-class-code')?.value);
    draft.classTitle = normalize(document.querySelector('#setup-class-title')?.value);
  }
  if (draft.step === 3) {
    draft.studentsText = document.querySelector('#setup-students')?.value || draft.studentsText;
  }
  if (draft.step === 4) {
    if (document.querySelector('#setup-manager-name')) draft.managerName = normalize(document.querySelector('#setup-manager-name').value);
    draft.pin = enDigits(document.querySelector('#setup-pin')?.value || '');
    draft.pinConfirm = enDigits(document.querySelector('#setup-pin-confirm')?.value || '');
  }
}

function validateSetupStep(step) {
  captureSetupStage();
  const draft = state.setup;
  if (step === 1) {
    if (draft.schoolMode === 'existing' && !draft.schoolId) return 'مدرسه را انتخاب کنید.';
    if (draft.schoolMode === 'new' && (!draft.schoolCode || draft.schoolName.length < 3)) return 'کد و نام مدرسه را کامل وارد کنید.';
  }
  if (step === 2) {
    if (!draft.schoolYear || !draft.classCode || !draft.classTitle) return 'سال تحصیلی، کد کلاس و عنوان کلاس ضروری است.';
    const schoolId = draft.schoolMode === 'existing' ? draft.schoolId : model.schools.find(item => normalizeId(item.code) === draft.schoolCode)?.id;
    const duplicate = model.classes.find(item => item.id !== draft.editClassId && item.schoolId === schoolId && normalize(item.schoolYear) === draft.schoolYear && normalizeId(item.code) === draft.classCode);
    if (duplicate) return 'این کد کلاس در همان مدرسه و سال تحصیلی قبلاً ثبت شده است.';
  }
  if (step === 3) {
    const parsed = draft.importedStudents.length ? { rows: draft.importedStudents, errors: [] } : parseStudentLines(draft.studentsText);
    if (parsed.errors.length) return parsed.errors[0];
    const resolvedSchoolId = draft.schoolMode === 'existing'
      ? draft.schoolId
      : model.schools.find(item => normalizeId(item.code) === draft.schoolCode)?.id || '';
    const sameYearStudents = model.students.filter(item =>
      normalize(item.schoolYear) === draft.schoolYear &&
      (!resolvedSchoolId || item.schoolId === resolvedSchoolId) &&
      item.classId !== draft.editClassId
    );
    const duplicate = parsed.rows.find(row => sameYearStudents.some(item => normalizeId(item.studentCode) === normalizeId(row.studentCode)));
    if (duplicate) return `شناسه ${duplicate.studentCode} در همین سال تحصیلی و کلاس دیگری ثبت شده است.`;
    const duplicateNationalId = parsed.rows.find(row => row.nationalId && sameYearStudents.some(item => normalizeId(item.nationalId) === normalizeId(row.nationalId)));
    if (duplicateNationalId) return `کد ملی ${duplicateNationalId.nationalId} در همین سال تحصیلی ثبت شده است.`;
  }
  return '';
}

async function hashText(text) {
  const data = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

async function saveClassSetup() {
  captureSetupStage();
  const draft = state.setup;
  for (const step of [1, 2, 3]) {
    const error = validateSetupStep(step);
    if (error) { showToast(error, 'error'); draft.step = step; renderRoute({ scrollTop: true }); return; }
  }
  if (model.localAdmin?.enabled) {
    if (!draft.pin || await hashText(draft.pin) !== model.localAdmin.pinHash) {
      showToast('رمز مدیر درست نیست.', 'error');
      return;
    }
  } else {
    if (draft.managerName.length < 3 || !/^\d{4,8}$/.test(draft.pin) || draft.pin !== draft.pinConfirm) {
      showToast('نام مدیر و رمز یکسان ۴ تا ۸ رقمی را کامل وارد کنید.', 'error');
      return;
    }
    await saveLocalAdmin({ enabled: true, managerName: draft.managerName, pinHash: await hashText(draft.pin), createdAt: new Date().toISOString() });
  }

  const now = new Date().toISOString();
  let schoolId = draft.schoolId;
  if (draft.schoolMode === 'new') {
    const existing = model.schools.find(item => normalizeId(item.code) === draft.schoolCode);
    schoolId = existing?.id || `school-${draft.schoolCode.toLowerCase()}`;
    await put('schools', {
      ...existing, id: schoolId, code: draft.schoolCode, name: draft.schoolName,
      province: draft.province, district: draft.district, schoolYear: draft.schoolYear,
      approvedLocally: true, approvedBy: draft.managerName || model.localAdmin.managerName,
      createdAt: existing?.createdAt || now, updatedAt: now,
    });
  }

  const classId = draft.editClassId || `class-${schoolId}-${draft.schoolYear.replace(/\s/g, '')}-${draft.classCode.toLowerCase()}`;
  const existingClass = classById(classId);
  await put('classes', {
    ...existingClass, id: classId, schoolId, schoolYear: draft.schoolYear, grade: draft.grade,
    code: draft.classCode, title: draft.classTitle, semester: 'first', approvedLocally: true,
    approvedBy: draft.managerName || model.localAdmin.managerName,
    createdAt: existingClass?.createdAt || now, updatedAt: now,
  });

  const students = draft.importedStudents.length ? draft.importedStudents : parseStudentLines(draft.studentsText).rows;
  const records = students.map(student => {
    const id = `student-${schoolId}-${draft.schoolYear.replace(/\s/g, '')}-${normalizeId(student.studentCode).toLowerCase()}`;
    const existing = model.students.find(item => item.id === id || (
      item.schoolId === schoolId && normalize(item.schoolYear) === draft.schoolYear && normalizeId(item.studentCode) === normalizeId(student.studentCode)
    ));
    const parts = student.name.split(/\s+/);
    return {
      ...existing, id: existing?.id || id, classId, schoolId, schoolYear: draft.schoolYear,
      studentCode: normalizeId(student.studentCode), nationalId: student.nationalId || existing?.nationalId || '',
      firstName: student.firstName || parts[0] || '', lastName: student.lastName || parts.slice(1).join(' '),
      fatherName: student.fatherName || existing?.fatherName || '', birthDate: student.birthDate || existing?.birthDate || '',
      name: student.name, group: student.group || '', active: true, approvedLocally: true,
      approvedBy: draft.managerName || model.localAdmin.managerName,
      createdAt: existing?.createdAt || now, updatedAt: now,
    };
  });
  if (records.length) await bulkPut('students', records);
  await put('audit', { id: uuid(), type: draft.editClassId ? 'class_updated' : 'class_created', actorId: CURRENT_USER_ID, schoolId, classId, count: records.length, createdAt: now });

  state.selectedSchoolId = schoolId;
  state.selectedClassId = classId;
  state.setup = null;
  model.settings = { ...model.settings, selectedSchoolId: schoolId, selectedClassId: classId };
  await saveSettings(model.settings);
  await refreshModel();
  navigate('class-detail', { id: classId }, { replace: true });
  showToast(draft.editClassId ? 'تغییرات کلاس ذخیره شد.' : 'کلاس ثبت و فعال شد.', 'success');
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char === '"') {
      if (quoted && text[i + 1] === '"') { cell += '"'; i++; }
      else quoted = !quoted;
    } else if (char === ',' && !quoted) {
      row.push(cell); cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && text[i + 1] === '\n') i++;
      row.push(cell); cell = '';
      if (row.some(value => value.trim())) rows.push(row);
      row = [];
    } else cell += char;
  }
  row.push(cell);
  if (row.some(value => value.trim())) rows.push(row);
  return rows;
}

function mapRosterCsv(text) {
  const table = parseCsv(text.replace(/^\uFEFF/, ''));
  if (table.length < 2) return { rows: [], errors: ['فایل CSV خالی است.'] };
  const headers = table[0].map(normalize);
  const index = label => headers.indexOf(normalize(label));
  const required = ['شناسه دانش‌آموز', 'نام', 'نام خانوادگی'];
  const missing = required.filter(label => index(label) < 0);
  if (missing.length) return { rows: [], errors: [`ستون‌های ضروری موجود نیست: ${missing.join('، ')}`] };
  const rows = [];
  const errors = [];
  const seen = new Set();
  const nationalSeen = new Set();
  table.slice(1).forEach((cols, rowIndex) => {
    const studentCode = normalizeId(cols[index('شناسه دانش‌آموز')] || '');
    const firstName = normalize(cols[index('نام')] || '');
    const lastName = normalize(cols[index('نام خانوادگی')] || '');
    if (!studentCode || !firstName || !lastName) {
      errors.push(`ردیف ${fa(rowIndex + 2)}: نام، نام خانوادگی یا شناسه ناقص است.`);
      return;
    }
    if (seen.has(studentCode)) {
      errors.push(`ردیف ${fa(rowIndex + 2)}: شناسه ${studentCode} تکراری است.`);
      return;
    }
    seen.add(studentCode);
    const nationalId = index('کد ملی') >= 0 ? normalizeId(cols[index('کد ملی')] || '') : '';
    if (nationalId && nationalSeen.has(nationalId)) {
      errors.push(`ردیف ${fa(rowIndex + 2)}: کد ملی ${nationalId} تکراری است.`);
      return;
    }
    if (nationalId) nationalSeen.add(nationalId);
    rows.push({
      name: `${firstName} ${lastName}`, firstName, lastName, studentCode,
      nationalId,
      fatherName: index('نام پدر') >= 0 ? normalize(cols[index('نام پدر')] || '') : '',
      birthDate: index('تاریخ تولد') >= 0 ? normalize(cols[index('تاریخ تولد')] || '') : '',
      group: index('گروه') >= 0 ? normalize(cols[index('گروه')] || '') : '',
      schoolCode: index('کد مدرسه') >= 0 ? normalizeId(cols[index('کد مدرسه')] || '') : '',
      schoolName: index('نام مدرسه') >= 0 ? normalize(cols[index('نام مدرسه')] || '') : '',
      province: index('استان') >= 0 ? normalize(cols[index('استان')] || '') : '',
      district: index('منطقه') >= 0 ? normalize(cols[index('منطقه')] || '') : '',
      schoolYear: index('سال تحصیلی') >= 0 ? normalize(cols[index('سال تحصیلی')] || '') : '',
      grade: index('پایه') >= 0 ? normalize(cols[index('پایه')] || '') : '',
      classCode: index('کد کلاس') >= 0 ? normalizeId(cols[index('کد کلاس')] || '') : '',
      classTitle: index('عنوان کلاس') >= 0 ? normalize(cols[index('عنوان کلاس')] || '') : '',
    });
  });
  return { rows, errors };
}

function captureAssessmentStage() {
  const draft = state.assessment;
  if (!draft) return;
  if (draft.step === 1) {
    const target = document.querySelector('#assessment-target');
    if (target) draft.targetId = target.value;
  }
  if (draft.step === 2) {
    const custom = normalize(document.querySelector('#assessment-activity-custom')?.value || '');
    if (custom) draft.activity = custom;
    draft.date = document.querySelector('#assessment-date')?.value || draft.date;
    draft.month = document.querySelector('#assessment-month')?.value || draft.month;
  }
  if (draft.step === 4) {
    draft.bonusReason = normalize(document.querySelector('#assessment-bonus-reason')?.value || draft.bonusReason);
    draft.note = normalize(document.querySelector('#assessment-note')?.value || draft.note);
  }
}

function validateAssessmentStep(step) {
  captureAssessmentStage();
  const draft = state.assessment;
  if (step === 1) {
    if (draft.mode === 'individual' && !draft.targetId) return 'دانش‌آموز را انتخاب کنید.';
    if (draft.mode === 'group' && !draft.targetId) return 'گروه را انتخاب کنید.';
  }
  if (step === 2 && !draft.activity) return 'عنوان فعالیت را انتخاب یا وارد کنید.';
  if (step === 3 && (!draft.categoryKey || !draft.criterionKey)) return 'حوزه و معیار ارزشیابی را انتخاب کنید.';
  if (step === 4) {
    if (!draft.level) return 'سطح عملکرد را انتخاب کنید.';
    if (draft.mode === 'individual' && Number(draft.bonusScore) > 0 && draft.bonusReason.length < 6) return 'برای نمره تشویقی، دلیل کوتاه و مشخص بنویسید.';
  }
  return '';
}

function buildRationale(draft, criterion, level) {
  const levelData = levelInfo(level);
  const evidence = EVIDENCE_TYPES.find(item => item.id === draft.evidenceType);
  const base = levelData?.score || 0;
  const bonus = draft.mode === 'individual' ? Number(draft.bonusScore || 0) : 0;
  const score = clamp(base + bonus, 0, 20);
  return `${criterion.title}: ${criterion.levels[level]}. شاهد: ${evidence?.title || 'مشاهده ثبت‌شده'}. سطح ${levelData?.title || level} با نمره پایه ${base}${bonus ? ` و ${bonus} نمره تشویقی به دلیل ${draft.bonusReason}` : ''}. نمره نهایی ${score} از ۲۰.`;
}

async function saveAssessment() {
  captureAssessmentStage();
  const error = validateAssessmentStep(4);
  if (error) { showToast(error, 'error'); return; }
  const draft = state.assessment;
  const criterion = criterionInfo(draft.categoryKey, draft.criterionKey);
  const targets = draft.mode === 'individual'
    ? classStudents().filter(item => item.id === draft.targetId)
    : draft.mode === 'group'
      ? classStudents().filter(item => item.group === draft.targetId)
      : classStudents();
  if (!targets.length) { showToast('دانش‌آموزی برای این ثبت پیدا نشد.', 'error'); return; }

  const now = new Date().toISOString();
  const existing = draft.editId ? model.assessments.find(item => item.id === draft.editId) : null;
  const batchId = existing?.batchId || uuid();
  let firstSavedId = existing?.id || null;

  for (const student of targets) {
    const level = Number(draft.level);
    const levelData = levelInfo(level);
    const bonus = draft.mode === 'individual' ? Number(draft.bonusScore || 0) : 0;
    const score = clamp(levelData.score + bonus, 0, 20);
    const id = existing?.id || uuid();
    if (!firstSavedId) firstSavedId = id;
    await put('assessments', {
      ...existing,
      id,
      batchId,
      studentId: student.id,
      classId: currentClass().id,
      schoolId: currentSchool().id,
      semester: state.semester,
      date: draft.date,
      month: draft.month,
      activity: draft.activity,
      categoryKey: draft.categoryKey,
      criterionKey: draft.criterionKey,
      criterion: criterion.title,
      descriptor: criterion.levels[level],
      level,
      baseScore: levelData.score,
      bonusScore: bonus,
      bonusReason: bonus > 0 ? draft.bonusReason : '',
      score,
      evidenceType: draft.evidenceType,
      evidenceTitle: EVIDENCE_TYPES.find(item => item.id === draft.evidenceType)?.title || '',
      notePreset: draft.notePreset,
      note: draft.note,
      rationale: buildRationale(draft, criterion, level),
      rubricVersion: RUBRIC_VERSION,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
      entryDurationSec: Math.round((Date.now() - draft.startedAt) / 1000),
    });
  }

  await put('audit', {
    id: uuid(), type: draft.editId ? 'assessment_updated' : 'assessment_saved', actorId: CURRENT_USER_ID,
    classId: currentClass().id, count: targets.length, createdAt: now,
  });
  draft.savedId = firstSavedId;
  await refreshModel();
  renderRoute({ scrollTop: true });
  showToast(draft.editId ? 'ویرایش نمره ذخیره شد.' : `${fa(targets.length)} ارزشیابی ذخیره شد.`, 'success');
}

async function saveAttendance(classId) {
  const cls = classById(classId);
  if (!cls) return;
  const absentIds = [];
  const lateIds = [];
  document.querySelectorAll('[data-attendance]').forEach(select => {
    if (select.value === 'absent') absentIds.push(select.dataset.attendance);
    if (select.value === 'late') lateIds.push(select.dataset.attendance);
  });
  const existing = model.attendance.find(item => item.classId === cls.id && item.date === today());
  const now = new Date().toISOString();
  await put('attendance', {
    id: existing?.id || uuid(), classId: cls.id, schoolId: cls.schoolId, date: today(),
    absentIds, lateIds, createdAt: existing?.createdAt || now, updatedAt: now,
  });
  await refreshModel();
  renderRoute();
  showToast('حضور و غیاب ذخیره شد.', 'success');
}

async function saveStudent() {
  const classId = document.querySelector('#student-class-id')?.value;
  const cls = classById(classId);
  const name = normalize(document.querySelector('#student-name')?.value);
  const studentCode = normalizeId(document.querySelector('#student-code')?.value);
  const group = normalize(document.querySelector('#student-group')?.value);
  const fatherName = normalize(document.querySelector('#student-father')?.value);
  const birthDate = normalize(document.querySelector('#student-birth')?.value);
  if (!cls || name.length < 3 || !studentCode) {
    showToast('نام و شناسه دانش‌آموز را کامل وارد کنید.', 'error');
    return;
  }
  const duplicate = model.students.find(item =>
    item.schoolId === cls.schoolId && normalize(item.schoolYear) === normalize(cls.schoolYear) && normalizeId(item.studentCode) === studentCode
  );
  if (duplicate) {
    const duplicateClass = classById(duplicate.classId);
    showToast(`این شناسه در سال تحصیلی جاری برای ${duplicate.name} در پایه ${duplicateClass?.grade || ''} ثبت شده است.`, 'error');
    return;
  }
  const suspicious = model.students.find(item => normalize(item.name) === name && normalize(item.fatherName) === fatherName && normalize(item.birthDate) === birthDate && (fatherName || birthDate));
  if (suspicious) {
    showToast('دانش‌آموزی با نام و مشخصات مشابه وجود دارد؛ شناسه را بررسی کنید.', 'error');
    return;
  }
  const now = new Date().toISOString();
  const parts = name.split(/\s+/);
  const id = `student-${cls.schoolId}-${cls.schoolYear.replace(/\s/g, '')}-${studentCode.toLowerCase()}`;
  await put('students', {
    id, classId: cls.id, schoolId: cls.schoolId, schoolYear: cls.schoolYear,
    studentCode, nationalId: '', firstName: parts[0], lastName: parts.slice(1).join(' '),
    fatherName, birthDate, name, group, active: true, createdAt: now, updatedAt: now,
  });
  closeDialog();
  await refreshModel();
  renderRoute();
  showToast('دانش‌آموز افزوده شد.', 'success');
}

async function saveContent(submit = true) {
  const form = document.querySelector('#content-form');
  const id = form?.dataset.id || uuid();
  const existing = model.content.find(item => item.id === id);
  const title = normalize(document.querySelector('#content-title')?.value);
  const summary = normalize(document.querySelector('#content-summary')?.value);
  if (title.length < 4 || summary.length < 8) {
    showToast('عنوان و خلاصه محتوا را کامل کنید.', 'error');
    return;
  }
  const now = new Date().toISOString();
  await put('content', {
    ...existing,
    id,
    type: document.querySelector('#content-type')?.value || 'experience',
    grade: document.querySelector('#content-grade')?.value || '',
    title,
    summary,
    body: normalize(document.querySelector('#content-body')?.value),
    channelId: document.querySelector('#content-channel')?.value || '',
    authorId: CURRENT_USER_ID,
    authorName: model.profile.name || 'دبیر',
    status: submit ? 'school_pending' : 'draft',
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  });
  await refreshModel();
  navigate('community', {}, { replace: true });
  state.communityTab = 'mine';
  renderRoute();
  showToast(submit ? 'محتوا برای بررسی ثبت شد.' : 'پیش‌نویس ذخیره شد.', 'success');
}

async function saveChannel() {
  const form = document.querySelector('#channel-form');
  const id = form?.dataset.id || uuid();
  const existing = model.channels.find(item => item.id === id);
  const title = normalize(document.querySelector('#channel-title')?.value);
  if (title.length < 3) { showToast('نام کانال را کامل کنید.', 'error'); return; }
  const now = new Date().toISOString();
  await put('channels', {
    ...existing,
    id,
    title,
    topic: normalize(document.querySelector('#channel-topic')?.value),
    description: normalize(document.querySelector('#channel-description')?.value),
    ownerId: CURRENT_USER_ID,
    ownerName: model.profile.name || 'دبیر',
    status: existing?.status || 'draft',
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  });
  await refreshModel();
  state.communityTab = 'podcasts';
  navigate('community', {}, { replace: true });
  showToast('کانال ذخیره شد.', 'success');
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function exportBackup() {
  const payload = await exportDatabase({ includeMedia: true });
  const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
  downloadBlob(blob, `hamyar-backup-${today()}.karo.json`);
  showToast('فایل پشتیبان آماده شد.', 'success');
}

async function importBackup(file) {
  try {
    const payload = JSON.parse(await file.text());
    await importDatabase(payload, { mode: 'merge' });
    await refreshModel();
    renderRoute();
    showToast('پشتیبان بازیابی شد.', 'success');
  } catch (error) {
    console.error(error);
    showToast(error.message || 'فایل پشتیبان معتبر نیست.', 'error');
  }
}

async function exportClassCsv(classId) {
  const cls = classById(classId || currentClass()?.id);
  if (!cls) return;
  const students = classStudents(cls.id);
  const records = model.assessments.filter(item => item.classId === cls.id && item.semester === state.semester);
  const lines = [['نام دانش‌آموز', 'شناسه', 'تعداد ثبت', 'میانگین', 'آخرین نمره']];
  students.forEach(student => {
    const own = records.filter(item => item.studentId === student.id).sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')));
    const avg = own.length ? own.reduce((sum, item) => sum + Number(item.score || 0), 0) / own.length : '';
    lines.push([student.name, student.studentCode || '', own.length, avg === '' ? '' : avg.toFixed(1), own[0]?.score ?? '']);
  });
  const csv = '\uFEFF' + lines.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(',')).join('\r\n');
  downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8' }), `نمرات-${cls.grade}-${cls.title}-${state.semester}.csv`);
  showToast('گزارش CSV آماده شد.', 'success');
}

async function handleRosterFile(file) {
  try {
    const result = mapRosterCsv(await file.text());
    if (result.errors.length) {
      showToast(result.errors[0], 'error');
      return;
    }
    if (state.route === 'class-setup' && state.setup) {
      state.setup.importedStudents = result.rows;
      const first = result.rows[0];
      if (first?.schoolCode) {
        state.setup.schoolMode = 'new';
        state.setup.schoolCode = first.schoolCode;
        state.setup.schoolName = first.schoolName;
        state.setup.province = first.province;
        state.setup.district = first.district;
        state.setup.schoolYear = first.schoolYear || state.setup.schoolYear;
        state.setup.grade = first.grade || state.setup.grade;
        state.setup.classCode = first.classCode || state.setup.classCode;
        state.setup.classTitle = first.classTitle || state.setup.classTitle;
      }
      renderRoute();
      showToast(`${fa(result.rows.length)} دانش‌آموز از CSV خوانده شد.`, 'success');
      return;
    }
    const classId = pendingRosterTarget || currentClass()?.id;
    const cls = classById(classId);
    if (!cls) return;
    const existingCodes = new Set(model.students.map(item => normalizeId(item.studentCode)));
    const duplicate = result.rows.find(item => existingCodes.has(item.studentCode));
    if (duplicate) {
      showToast(`شناسه ${duplicate.studentCode} قبلاً ثبت شده است.`, 'error');
      return;
    }
    const now = new Date().toISOString();
    const records = result.rows.map(student => ({
      id: `student-${cls.schoolId}-${cls.schoolYear.replace(/\s/g, '')}-${student.studentCode.toLowerCase()}`,
      classId: cls.id, schoolId: cls.schoolId, schoolYear: cls.schoolYear,
      ...student, active: true, createdAt: now, updatedAt: now,
    }));
    await bulkPut('students', records);
    await refreshModel();
    renderRoute();
    showToast(`${fa(records.length)} دانش‌آموز وارد شد.`, 'success');
  } catch (error) {
    console.error(error);
    showToast('خواندن فایل CSV ناموفق بود.', 'error');
  } finally {
    pendingRosterTarget = null;
  }
}

function renderAssessmentStageOnly() {
  const stage = document.querySelector('#assessment-stage');
  const context = document.querySelector('#assessment-context');
  const next = document.querySelector('.assessment-actions [data-action="assessment-next"]');
  if (!stage || !context) { renderRoute(); return; }
  const y = window.scrollY;
  captureAssessmentStage();
  stage.innerHTML = assessmentStage();
  context.innerHTML = assessmentContext();
  if (next) next.textContent = state.assessment.step === 4 ? `ثبت نمره ${state.assessment.level ? fa(finalScore()) : ''}` : 'ادامه';
  requestAnimationFrame(() => window.scrollTo({ top: y, behavior: 'auto' }));
}

function renderSetupStageOnly() {
  const stage = document.querySelector('#setup-stage');
  if (!stage) { renderRoute(); return; }
  captureSetupStage();
  stage.innerHTML = classSetupStage();
}

function openRosterDialog(classId = null, forSetup = false) {
  pendingRosterTarget = classId;
  openDialog('ورود فهرست دانش‌آموزان', `<div class="notice"><strong>فایل CSV</strong><span>فایل باید دارای ستون‌های «شناسه دانش‌آموز»، «نام» و «نام خانوادگی» باشد. شناسه‌های تکراری پذیرفته نمی‌شوند.</span></div><div class="section button-row"><button class="ghost-btn" data-action="download-roster-template">${icon('download')} دریافت الگو</button><button class="primary-btn" data-action="choose-roster-file" data-setup="${forSetup ? '1' : '0'}">${icon('upload')} انتخاب فایل CSV</button></div>`);
}

async function handleAction(element) {
  const action = element.dataset.action;
  if (!action) return;

  if (action === 'navigate') {
    if (state.route === 'assessment-flow') state.assessment = null;
    if (state.route === 'class-setup') state.setup = null;
    navigate(element.dataset.route);
  }
  else if (action === 'back') goBack();
  else if (action === 'open-help') navigate('help');
  else if (action === 'open-context') contextDialog();
  else if (action === 'close-dialog') closeDialog();
  else if (action === 'context-semester') {
    state.semester = element.dataset.value;
    dialog.querySelectorAll('[data-action="context-semester"]').forEach(button => button.classList.toggle('is-selected', button === element));
  }
  else if (action === 'save-context') {
    const schoolId = dialog.querySelector('#context-school')?.value;
    const classId = dialog.querySelector('#context-class')?.value;
    state.selectedSchoolId = schoolId;
    state.selectedClassId = classId || model.classes.find(item => item.schoolId === schoolId)?.id || null;
    model.settings = { ...model.settings, selectedSchoolId: state.selectedSchoolId, selectedClassId: state.selectedClassId, semester: state.semester };
    await saveSettings(model.settings);
    closeDialog();
    await refreshModel();
    renderRoute();
    showToast('کلاس جاری تغییر کرد.', 'success');
  }
  else if (action === 'new-class') {
    closeDialog();
    state.setup = newSetupDraft();
    navigate('class-setup');
  }
  else if (action === 'edit-class') {
    state.setup = newSetupDraft(element.dataset.id);
    navigate('class-setup', { id: element.dataset.id });
  }
  else if (action === 'open-class') navigate('class-detail', { id: element.dataset.id });
  else if (action === 'activate-class') {
    const cls = classById(element.dataset.id);
    if (!cls) return;
    state.selectedClassId = cls.id;
    state.selectedSchoolId = cls.schoolId;
    model.settings = { ...model.settings, selectedClassId: cls.id, selectedSchoolId: cls.schoolId };
    await saveSettings(model.settings);
    await refreshModel();
    renderRoute();
    showToast('کلاس جاری انتخاب شد.', 'success');
  }
  else if (action === 'class-tab') {
    state.classTab = element.dataset.tab;
    renderRoute();
  }
  else if (action === 'open-add-student') addStudentDialog(element.dataset.id);
  else if (action === 'save-student') await saveStudent();
  else if (action === 'import-roster') openRosterDialog(element.dataset.id, false);
  else if (action === 'setup-import-csv') openRosterDialog(null, true);
  else if (action === 'choose-roster-file') {
    closeDialog();
    rosterFile.dataset.setup = element.dataset.setup || '0';
    rosterFile.click();
  }
  else if (action === 'download-roster-template') {
    const link = document.createElement('a');
    link.href = './templates/student_import_template.csv';
    link.download = 'student_import_template.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast('الگوی CSV دانلود شد.', 'success');
  }
  else if (action === 'parse-student-lines') {
    captureSetupStage();
    const parsed = parseStudentLines(state.setup.studentsText);
    if (parsed.errors.length) showToast(parsed.errors[0], 'error');
    else {
      state.setup.importedStudents = parsed.rows;
      renderSetupStageOnly();
      showToast(`${fa(parsed.rows.length)} دانش‌آموز بررسی شد.`, 'success');
    }
  }
  else if (action === 'setup-school-mode') {
    captureSetupStage();
    state.setup.schoolMode = element.dataset.value;
    renderSetupStageOnly();
  }
  else if (action === 'setup-jump') {
    captureSetupStage();
    const target = Number(element.dataset.step);
    if (target <= state.setup.step) {
      state.setup.step = target;
      renderRoute({ scrollTop: true });
    }
  }
  else if (action === 'setup-back') {
    if (state.setup.step === 1) {
      state.setup = null;
      goBack();
    } else {
      captureSetupStage();
      state.setup.step--;
      renderRoute({ scrollTop: true });
    }
  }
  else if (action === 'setup-next') {
    if (state.setup.step === 4) await saveClassSetup();
    else {
      const error = validateSetupStep(state.setup.step);
      if (error) { showToast(error, 'error'); return; }
      state.setup.step++;
      renderRoute({ scrollTop: true });
    }
  }
  else if (action === 'start-assessment') {
    if (!currentClass() || !classStudents().length) {
      showToast('ابتدا کلاس و دانش‌آموزان را تعریف کنید.', 'error');
      return;
    }
    state.assessment = createAssessmentDraft(element.dataset.mode || 'individual');
    navigate('assessment-flow', { mode: element.dataset.mode || 'individual' });
  }
  else if (action === 'assess-student') {
    state.assessment = createAssessmentDraft('individual', element.dataset.id);
    navigate('assessment-flow', { mode: 'individual', student: element.dataset.id });
  }
  else if (action === 'assessment-mode') {
    const mode = element.dataset.value;
    const groups = [...new Set(classStudents().map(student => student.group).filter(Boolean))];
    state.assessment.mode = mode;
    state.assessment.targetId = mode === 'individual' ? classStudents()[0]?.id : mode === 'group' ? groups[0] : 'all';
    renderAssessmentStageOnly();
  }
  else if (action === 'assessment-activity') {
    state.assessment.activity = element.dataset.value;
    document.querySelectorAll('[data-action="assessment-activity"]').forEach(button => button.classList.toggle('is-selected', button === element));
    const custom = document.querySelector('#assessment-activity-custom');
    if (custom) custom.value = '';
    document.querySelector('#assessment-context').innerHTML = assessmentContext();
  }
  else if (action === 'assessment-category') {
    state.assessment.categoryKey = element.dataset.value;
    state.assessment.criterionKey = Object.keys(RUBRIC_LIBRARY[element.dataset.value].criteria)[0];
    renderAssessmentStageOnly();
  }
  else if (action === 'assessment-criterion') {
    state.assessment.criterionKey = element.dataset.value;
    document.querySelectorAll('[data-action="assessment-criterion"]').forEach(button => button.classList.toggle('is-selected', button === element));
  }
  else if (action === 'assessment-level') {
    state.assessment.level = Number(element.dataset.value);
    renderAssessmentStageOnly();
  }
  else if (action === 'assessment-bonus') {
    state.assessment.bonusScore = Number(element.dataset.value);
    if (!state.assessment.bonusScore) state.assessment.bonusReason = '';
    renderAssessmentStageOnly();
  }
  else if (action === 'assessment-evidence') {
    state.assessment.evidenceType = element.dataset.value;
    document.querySelectorAll('[data-action="assessment-evidence"]').forEach(button => button.classList.toggle('is-selected', button === element));
  }
  else if (action === 'assessment-note-preset') {
    state.assessment.notePreset = state.assessment.notePreset === element.dataset.value ? '' : element.dataset.value;
    document.querySelectorAll('[data-action="assessment-note-preset"]').forEach(button => button.classList.toggle('is-selected', button.dataset.value === state.assessment.notePreset));
  }
  else if (action === 'assessment-back') {
    if (state.assessment.step === 1) {
      state.assessment = null;
      navigate('assessment', {}, { replace: true });
    } else {
      captureAssessmentStage();
      state.assessment.step--;
      renderRoute({ scrollTop: true });
    }
  }
  else if (action === 'assessment-next') {
    if (state.assessment.step === 4) await saveAssessment();
    else {
      const error = validateAssessmentStep(state.assessment.step);
      if (error) { showToast(error, 'error'); return; }
      state.assessment.step++;
      renderRoute({ scrollTop: true });
    }
  }
  else if (action === 'assessment-another') {
    const mode = state.assessment.mode;
    state.assessment = createAssessmentDraft(mode);
    renderRoute({ scrollTop: true });
  }
  else if (action === 'open-student') navigate('student', { id: element.dataset.id });
  else if (action === 'open-record') navigate('record', { id: element.dataset.id });
  else if (action === 'edit-record') {
    state.assessment = createAssessmentDraft('individual', null, element.dataset.id);
    navigate('assessment-flow', { edit: element.dataset.id });
  }
  else if (action === 'attendance') {
    if (!currentClass()) return;
    state.classTab = 'attendance';
    navigate('class-detail', { id: currentClass().id });
  }
  else if (action === 'save-attendance') await saveAttendance(element.dataset.id);
  else if (action === 'class-report') classReportDialog(currentClass()?.id);
  else if (action === 'export-class') {
    closeDialog();
    await exportClassCsv(element.dataset.id);
  }
  else if (action === 'community-tab') {
    state.communityTab = element.dataset.tab;
    renderRoute();
  }
  else if (action === 'new-content') navigate('content-editor');
  else if (action === 'edit-content') navigate('content-editor', { id: element.dataset.id });
  else if (action === 'save-content-draft') await saveContent(false);
  else if (action === 'new-channel') navigate('channel-editor');
  else if (action === 'edit-channel') navigate('channel-editor', { id: element.dataset.id });
  else if (action === 'profile-settings') profileDialog();
  else if (action === 'save-profile') {
    const name = normalize(dialog.querySelector('#profile-name')?.value);
    const roleLabel = normalize(dialog.querySelector('#profile-role')?.value);
    if (name.length < 3) { showToast('نام را کامل وارد کنید.', 'error'); return; }
    model.profile = { ...model.profile, name, roleLabel };
    await saveProfile(model.profile);
    closeDialog();
    await refreshModel();
    renderRoute();
    showToast('پروفایل ذخیره شد.', 'success');
  }
  else if (action === 'appearance-settings') appearanceDialog();
  else if (action === 'backup-center') await backupCenterDialog();
  else if (action === 'save-appearance') {
    model.settings = { ...model.settings, theme: dialog.querySelector('#appearance-theme')?.value || 'light', density: dialog.querySelector('#appearance-density')?.value || 'comfortable' };
    await saveSettings(model.settings);
    closeDialog();
    await refreshModel();
    renderRoute();
    showToast('نمایش برنامه به‌روز شد.', 'success');
  }
  else if (action === 'export-backup') await exportBackup();
  else if (action === 'import-backup') backupFile.click();
  else if (action === 'storage-settings') await storageDialog();
  else if (action === 'persist-storage') {
    const ok = await requestPersistentStorage();
    showToast(ok ? 'ماندگاری داده فعال شد.' : 'مرورگر این درخواست را نپذیرفت.', ok ? 'success' : 'normal');
    await storageDialog();
  }
  else if (action === 'data-management') dataManagementDialog();
  else if (action === 'clear-all-data') {
    if (normalize(dialog.querySelector('#delete-confirm')?.value) !== 'حذف کامل') {
      showToast('عبارت «حذف کامل» را درست وارد کنید.', 'error');
      return;
    }
    await clearAll();
    closeDialog();
    location.reload();
  }
  else if (action === 'apply-update') {
    if (pendingServiceWorker) pendingServiceWorker.postMessage({ type: 'SKIP_WAITING' });
  }
}

app.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (!element || element.disabled) return;
  event.preventDefault();
  handleAction(element).catch(error => {
    console.error(error);
    showToast('عملیات انجام نشد. دوباره تلاش کنید.', 'error');
  });
});

dialog.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (!element || element.disabled) return;
  event.preventDefault();
  handleAction(element).catch(error => {
    console.error(error);
    showToast('عملیات انجام نشد.', 'error');
  });
});

dialog.addEventListener('cancel', event => {
  event.preventDefault();
  closeDialog();
});

app.addEventListener('input', event => {
  if (event.target.id === 'student-search') {
    const query = normalize(event.target.value);
    document.querySelectorAll('#student-list [data-search]').forEach(row => {
      row.hidden = query && !normalize(row.dataset.search).includes(query);
    });
  }
  if (event.target.id === 'assessment-activity-custom' && state.assessment) {
    state.assessment.activity = normalize(event.target.value);
    document.querySelectorAll('[data-action="assessment-activity"]').forEach(button => button.classList.remove('is-selected'));
    document.querySelector('#assessment-context').innerHTML = assessmentContext();
  }
  if (event.target.id === 'assessment-bonus-reason' && state.assessment) state.assessment.bonusReason = event.target.value;
  if (event.target.id === 'assessment-note' && state.assessment) state.assessment.note = event.target.value;
  if (event.target.id === 'setup-students' && state.setup) {
    state.setup.studentsText = event.target.value;
    state.setup.importedStudents = [];
  }
});

app.addEventListener('change', event => {
  if (event.target.id === 'assessment-target' && state.assessment) {
    state.assessment.targetId = event.target.value;
    document.querySelector('#assessment-context').innerHTML = assessmentContext();
  }
  if (event.target.id === 'assessment-date' && state.assessment) state.assessment.date = event.target.value;
  if (event.target.id === 'assessment-month' && state.assessment) state.assessment.month = event.target.value;
});

dialog.addEventListener('change', event => {
  if (event.target.id === 'context-school') {
    const schoolId = event.target.value;
    const classSelect = dialog.querySelector('#context-class');
    const classes = model.classes.filter(item => item.schoolId === schoolId);
    classSelect.innerHTML = classes.map(cls => `<option value="${cls.id}">پایه ${esc(cls.grade)} · ${esc(cls.title)}</option>`).join('');
  }
});

app.addEventListener('submit', event => {
  event.preventDefault();
  if (event.target.id === 'content-form') saveContent(true).catch(console.error);
  if (event.target.id === 'channel-form') saveChannel().catch(console.error);
});

backupFile.addEventListener('change', async () => {
  if (backupFile.files[0]) await importBackup(backupFile.files[0]);
  backupFile.value = '';
});

rosterFile.addEventListener('change', async () => {
  if (rosterFile.files[0]) await handleRosterFile(rosterFile.files[0]);
  rosterFile.value = '';
});

window.addEventListener('popstate', event => {
  const route = event.state?.route;
  if (route && ROUTES.has(route)) {
    state.route = route;
    state.params = event.state?.params || {};
  } else parseLocation();
  if (state.route !== 'assessment-flow') state.assessment = null;
  if (state.route !== 'class-setup') state.setup = null;
  renderRoute({ scrollTop: true });
});

window.addEventListener('online', () => {
  const status = document.querySelector('#topbar-status');
  if (status) status.textContent = 'آماده ثبت';
  showToast('اتصال اینترنت برقرار شد.');
});

window.addEventListener('offline', () => {
  const status = document.querySelector('#topbar-status');
  if (status) status.textContent = 'آفلاین؛ ثبت فعال است';
  showToast('برنامه آفلاین است؛ ثبت ادامه دارد.');
});

async function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  try {
    const registration = await navigator.serviceWorker.register('./service-worker.js?v=2.0.0-rc2', { scope: './', updateViaCache: 'none' });
    if (registration.waiting) {
      pendingServiceWorker = registration.waiting;
      state.updateReady = true;
      renderUpdateBanner();
    }
    registration.addEventListener('updatefound', () => {
      const worker = registration.installing;
      worker?.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) {
          pendingServiceWorker = registration.waiting || worker;
          state.updateReady = true;
          renderUpdateBanner();
        }
      });
    });
    let reloading = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (reloading) return;
      reloading = true;
      location.reload();
    });
  } catch (error) {
    console.warn('Service worker registration failed', error);
  }
}

async function init() {
  await ensureSeed();
  await refreshModel();
  parseLocation();
  history.replaceState({ route: state.route, params: state.params }, '', routeUrl(state.route, state.params));
  renderShell();
  renderRoute();
  await registerServiceWorker();
}

init().catch(error => {
  console.error(error);
  app.innerHTML = `<div class="empty-state"><h2>راه‌اندازی برنامه ناموفق بود</h2><p>${esc(error.message || 'خطای ناشناخته')}</p><button class="primary-btn" onclick="location.reload()">تلاش دوباره</button></div>`;
});
