const CACHE = 'hamyar-karo-v2.1.0-rc1';
const ASSETS = [
  './', './index.html', './offline.html', './styles.css?v=2.1.0-rc1',
  './manifest.webmanifest?v=2.1.0-rc1', './js/app.js?v=2.1.0-rc1',
  './js/data.js?v=2.1.0-rc1', './js/db.js?v=2.1.0-rc1', './js/rubrics.js?v=2.1.0-rc1',
  './assets/icon-96.png', './assets/icon-192.png', './assets/icon-512.png',
  './assets/icon-maskable-512.png', './assets/apple-touch-icon.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).then(response => {
      const clone = response.clone();
      caches.open(CACHE).then(cache => cache.put('./index.html', clone));
      return response;
    }).catch(() => caches.match('./index.html').then(response => response || caches.match('./offline.html'))));
    return;
  }
  if (url.origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (response.ok) caches.open(CACHE).then(cache => cache.put(event.request, response.clone()));
    return response;
  })));
});
