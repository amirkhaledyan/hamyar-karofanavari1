import {
  EVIDENCE_TYPES, RUBRIC_LEVELS, RUBRIC_LIBRARY, RUBRIC_VERSION, SCHOOL_MONTHS,
} from './rubrics.js?v=2.1.0-rc1';
import {
  bulkPut, clearAll, exportDatabase, importDatabase, put, requestPersistentStorage, storageInfo,
} from './db.js?v=2.1.0-rc1';
import {
  APP_VERSION, CURRENT_USER_ID, DEFAULT_YEAR, ensureSeed, readModel, saveLocalAdmin, saveProfile, saveSettings, uuid,
} from './data.js?v=2.1.0-rc1';

const app = document.querySelector('#app');
const toast = document.querySelector('#toast');
const dialog = document.querySelector('#app-dialog');
const backupFile = document.querySelector('#backup-file');
const rosterFile = document.querySelector('#roster-file');

let model;
let pendingServiceWorker = null;
let pendingRosterClassId = null;

const state = {
  route: 'home',
  params: {},
  drawerOpen: false,
  setup: null,
  assessment: null,
  monthlyMonth: null,
  communityTab: 'feed',
  updateReady: false,
};

const ROUTES = new Set([
  'home', 'onboarding', 'structure', 'class', 'students', 'attendance', 'assessment',
  'monthly', 'student', 'community', 'channel-editor', 'post-editor', 'post', 'settings', 'help',
]);

const fa = value => String(value ?? '').replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[digit]);
const en = value => String(value ?? '').replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)));
const esc = (value = '') => String(value).replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
})[char]);
const normalize = value => en(String(value ?? '')).replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\s+/g, ' ').trim();
const normalizeKey = value => normalize(value).replace(/\s/g, '').toLowerCase();
const today = () => new Date().toISOString().slice(0, 10);
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const average = values => values.length ? values.reduce((sum, value) => sum + Number(value || 0), 0) / values.length : null;
const displayScore = value => value === null || Number.isNaN(Number(value)) ? '—' : fa(Number(value).toFixed(1).replace('.0', ''));
const formatYear = value => fa(value || DEFAULT_YEAR);

function icon(name) {
  const paths = {
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    home: '<path d="M3 11.5 12 4l9 7.5v8a1.5 1.5 0 0 1-1.5 1.5h-5v-6h-5v6h-5A1.5 1.5 0 0 1 3 19.5z"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',
    users: '<path d="M16 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M9.5 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8M17 11a3 3 0 1 0 0-6M21 20v-2a4 4 0 0 0-3-3.87"/>',
    school: '<path d="M3 10 12 4l9 6M5 10v9h14v-9M9 19v-5h6v5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    arrow: '<path d="m9 18 6-6-6-6"/>',
    back: '<path d="m15 18-6-6 6-6"/>',
    report: '<path d="M5 3h14v18H5zM8 8h8M8 12h8M8 16h5"/>',
    podcast: '<circle cx="12" cy="12" r="2"/><path d="M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5.5 5.5a9 9 0 0 0 0 13M18.5 5.5a9 9 0 0 1 0 13"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1A1.7 1.7 0 0 0 4.6 15 1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    download: '<path d="M12 4v12m0 0 5-5m-5 5-5-5M5 20h14"/>',
    upload: '<path d="M12 16V4m0 0L7 9m5-5 5 5M5 20h14"/>',
    edit: '<path d="M4 20h4l11-11-4-4L4 16zM13.5 6.5l4 4"/>',
    personAdd: '<path d="M15 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M8 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M19 8v6M16 11h6"/>',
    cloud: '<path d="M7 18h10a4 4 0 0 0 .5-8 6 6 0 0 0-11.4-1.8A5 5 0 0 0 7 18z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3m3 0-1 14H7L6 7m4 4v6m4-6v6"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    message: '<path d="M4 5h16v11H8l-4 4z"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/>',
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.info}</svg>`;
}

function showToast(message, type = 'normal') {
  toast.textContent = message;
  toast.dataset.type = type;
  toast.classList.add('is-visible');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('is-visible'), 3200);
}

function applyTheme() {
  document.documentElement.dataset.theme = model.settings.theme === 'dark' ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', model.settings.theme === 'dark' ? '#17211f' : '#0b7a70');
}

function selectedYear() { return model.settings.selectedYear || DEFAULT_YEAR; }
function schoolById(id) { return model.schools.find(item => item.id === id); }
function classById(id) { return model.classes.find(item => item.id === id); }
function studentById(id) { return model.students.find(item => item.id === id); }
function currentSchool() { return schoolById(model.settings.selectedSchoolId) || model.schools.find(item => item.schoolYear === selectedYear()) || null; }
function currentClass() {
  const selected = classById(model.settings.selectedClassId);
  if (selected?.schoolYear === selectedYear()) return selected;
  return model.classes.find(item => item.schoolYear === selectedYear() && item.schoolId === currentSchool()?.id) || null;
}
function studentsForClass(classId) { return model.students.filter(item => item.classId === classId && item.active !== false); }
function recordsForClass(classId, month = null) {
  return model.assessments.filter(item => item.classId === classId && item.schoolYear === selectedYear() && (!month || item.month === month));
}
function recordsForStudent(studentId, month = null) {
  return model.assessments.filter(item => item.studentId === studentId && item.schoolYear === selectedYear() && (!month || item.month === month));
}
function currentMonth() { return state.monthlyMonth || model.settings.currentMonth || SCHOOL_MONTHS[0]; }

async function refreshModel() {
  model = await readModel();
  const yearSchools = model.schools.filter(item => item.schoolYear === selectedYear());
  if (!yearSchools.some(item => item.id === model.settings.selectedSchoolId)) model.settings.selectedSchoolId = yearSchools[0]?.id || null;
  const schoolClasses = model.classes.filter(item => item.schoolYear === selectedYear() && item.schoolId === model.settings.selectedSchoolId);
  if (!schoolClasses.some(item => item.id === model.settings.selectedClassId)) model.settings.selectedClassId = schoolClasses[0]?.id || null;
  if (!SCHOOL_MONTHS.includes(model.settings.currentMonth)) model.settings.currentMonth = SCHOOL_MONTHS[0];
  applyTheme();
}

function routeUrl(route, params = {}) {
  const search = new URLSearchParams({ view: route });
  Object.entries(params).forEach(([key, value]) => value !== undefined && value !== null && value !== '' && search.set(key, value));
  return `?${search.toString()}`;
}

function parseLocation() {
  const params = new URLSearchParams(location.search);
  const route = params.get('view') || 'home';
  state.route = ROUTES.has(route) ? route : 'home';
  state.params = Object.fromEntries([...params.entries()].filter(([key]) => key !== 'view'));
}

function navigate(route, params = {}, { replace = false } = {}) {
  if (!ROUTES.has(route)) route = 'home';
  state.route = route;
  state.params = params;
  state.drawerOpen = false;
  const url = routeUrl(route, params);
  if (replace) history.replaceState({ route, params }, '', url);
  else history.pushState({ route, params }, '', url);
  renderRoute(true);
}

function goBack() {
  if (history.length > 1) history.back();
  else navigate('home', {}, { replace: true });
}

function activeBottomRoute() {
  if (['assessment'].includes(state.route)) return 'assessment';
  if (['monthly', 'student'].includes(state.route)) return 'monthly';
  if (['community', 'channel-editor', 'post-editor', 'post'].includes(state.route)) return 'community';
  return 'home';
}

function renderShell() {
  app.className = '';
  app.setAttribute('aria-busy', 'false');
  app.innerHTML = `<div class="app-shell">
    <header class="topbar">
      <button class="icon-button" data-action="toggle-drawer" aria-label="بازکردن منو">${icon('menu')}</button>
      <div class="topbar-title"><strong>همیار کار و فناوری</strong><span>${navigator.onLine ? 'آنلاین' : 'آفلاین'}</span></div>
      ${['onboarding', 'class', 'students', 'attendance', 'student', 'channel-editor', 'post-editor', 'post', 'settings', 'help'].includes(state.route) ? `<button class="icon-button" data-action="back" aria-label="بازگشت">${icon('back')}</button>` : '<span class="topbar-spacer"></span>'}
    </header>
    <main id="main-view" class="main-view" tabindex="-1"></main>
    ${bottomNav()}
  </div>
  <div id="drawer-layer" class="drawer-layer" aria-hidden="true">
    <button class="drawer-backdrop" data-action="close-drawer" aria-label="بستن منو"></button>
    <aside class="drawer" aria-label="منوی اصلی"></aside>
  </div>
  <div id="update-slot"></div>`;
  renderDrawer();
}

function bottomNav() {
  const items = [
    ['home', 'home', 'خانه'],
    ['assessment', 'check', 'ثبت'],
    ['monthly', 'report', 'ماهانه'],
    ['community', 'users', 'هم‌افزایی'],
  ];
  const active = activeBottomRoute();
  return `<nav class="bottom-nav" aria-label="دسترسی اصلی">${items.map(([route, iconName, label]) => `<button data-action="navigate" data-route="${route}" aria-current="${active === route ? 'page' : 'false'}">${icon(iconName)}<span>${label}</span></button>`).join('')}</nav>`;
}

function renderDrawer() {
  const layer = document.querySelector('#drawer-layer');
  const drawer = layer?.querySelector('.drawer');
  if (!layer || !drawer) return;
  const school = currentSchool();
  const cls = currentClass();
  layer.classList.toggle('is-open', state.drawerOpen);
  layer.setAttribute('aria-hidden', state.drawerOpen ? 'false' : 'true');
  drawer.innerHTML = `<div class="drawer-head"><div><strong>مدیریت سریع</strong><span>سال ${formatYear(selectedYear())}</span></div><button class="icon-button" data-action="close-drawer" aria-label="بستن">${icon('close')}</button></div>
    <button class="drawer-context" data-action="open-context"><span><b>${esc(school?.name || 'مدرسه انتخاب نشده')}</b><small>${cls ? `پایه ${esc(cls.grade)} · ${esc(cls.title)}` : 'کلاس انتخاب نشده'}</small></span>${icon('chevron')}</button>
    <nav class="drawer-nav">
      ${drawerLink('home', 'home', 'خانه')}
      ${drawerLink('assessment', 'check', 'ثبت ارزشیابی')}
      ${drawerLink('monthly', 'report', 'نمرات و آرشیو ماهانه')}
      ${drawerLink('structure', 'school', 'مدیریت مدارس و کلاس‌ها')}
      ${drawerLink('students', 'users', 'دانش‌آموزان کلاس جاری')}
      ${drawerLink('attendance', 'calendar', 'حضور و غیاب')}
      ${drawerLink('community', 'podcast', 'هم‌افزایی و پادکست')}
    </nav>
    <div class="drawer-nav drawer-nav--secondary">
      ${drawerLink('settings', 'settings', 'تنظیمات و پشتیبان')}
      ${drawerLink('help', 'info', 'راهنما')}
    </div>
    <div class="drawer-version">نسخه ${esc(APP_VERSION)}</div>`;
}

function drawerLink(route, iconName, label) {
  return `<button data-action="navigate" data-route="${route}" class="${state.route === route ? 'is-active' : ''}">${icon(iconName)}<span>${label}</span></button>`;
}

function renderUpdateBanner() {
  const slot = document.querySelector('#update-slot');
  if (!slot) return;
  slot.innerHTML = state.updateReady ? '<div class="update-banner"><span>نسخه تازه آماده است.</span><button data-action="apply-update">به‌روزرسانی</button></div>' : '';
}

function routeContent() {
  switch (state.route) {
    case 'onboarding': return onboardingView();
    case 'structure': return structureView();
    case 'class': return classView(state.params.id);
    case 'students': return studentsView();
    case 'attendance': return attendanceView();
    case 'assessment': return assessmentView();
    case 'monthly': return monthlyView();
    case 'student': return studentView(state.params.id);
    case 'community': return communityView();
    case 'channel-editor': return channelEditorView(state.params.id);
    case 'post-editor': return postEditorView(state.params.id);
    case 'post': return postView(state.params.id);
    case 'settings': return settingsView();
    case 'help': return helpView();
    default: return homeView();
  }
}

function renderRoute(scrollTop = false) {
  if (!document.querySelector('#main-view')) renderShell();
  const main = document.querySelector('#main-view');
  main.innerHTML = `<div class="page">${routeContent()}</div>`;
  renderDrawer();
  const bottom = document.querySelector('.bottom-nav');
  if (bottom) bottom.hidden = state.route === 'onboarding';
  const menuButton = document.querySelector('[data-action="toggle-drawer"]');
  if (menuButton) menuButton.hidden = state.route === 'onboarding' && !model.settings.onboardingDone;
  main.classList.toggle('main-view--onboarding', state.route === 'onboarding');
  document.querySelectorAll('.bottom-nav [data-route]').forEach(button => button.setAttribute('aria-current', button.dataset.route === activeBottomRoute() ? 'page' : 'false'));
  renderUpdateBanner();
  main.focus({ preventScroll: true });
  if (scrollTop) window.scrollTo({ top: 0, behavior: 'auto' });
}

function pageHeading(title, subtitle = '', action = '') {
  return `<section class="page-heading"><div><h1>${esc(title)}</h1>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div>${action}</section>`;
}

function contextCard() {
  const school = currentSchool();
  const cls = currentClass();
  return `<button class="context-card" data-action="open-context"><span><b>${esc(school?.name || 'مدرسه انتخاب نشده')}</b><small>سال ${formatYear(selectedYear())}${cls ? ` · پایه ${esc(cls.grade)} · ${esc(cls.title)}` : ' · کلاس انتخاب نشده'}</small></span>${icon('chevron')}</button>`;
}

function emptyStructure() {
  return `<section class="empty-state">${icon('school')}<h2>ساختار آموزشی تعریف نشده است</h2><p>سال تحصیلی، مدرسه، کلاس و دانش‌آموزان را یک‌بار ثبت کنید.</p><button class="primary-button" data-action="start-onboarding">شروع راه‌اندازی</button></section>`;
}

function homeView() {
  const cls = currentClass();
  if (!cls) return `${pageHeading('خانه', 'آماده‌سازی اولیه سامانه')}${emptyStructure()}`;
  const month = currentMonth();
  const students = studentsForClass(cls.id);
  const records = recordsForClass(cls.id, month);
  const monthAverage = average(records.map(item => item.score));
  const covered = new Set(records.map(item => item.studentId)).size;
  return `${contextCard()}
    <section class="primary-action-card"><div><span class="eyebrow">ثبت برای ماه ${esc(month)}</span><h1>ارزشیابی شایستگی</h1><p>دانش‌آموز، معیار و سطح عملکرد را انتخاب کنید.</p></div><button class="primary-button" data-action="start-assessment">${icon('plus')} ثبت جدید</button></section>
    <section class="metric-grid">
      <article><span>مستمر ${esc(month)}</span><b>${displayScore(monthAverage)}</b><small>میانگین نمرات ثبت‌شده</small></article>
      <article><span>پوشش کلاس</span><b>${fa(covered)} از ${fa(students.length)}</b><small>دانش‌آموز دارای ثبت</small></article>
      <article><span>تعداد ثبت</span><b>${fa(records.length)}</b><small>در ماه جاری</small></article>
    </section>
    <section class="section"><div class="section-heading"><h2>دسترسی سریع</h2></div><div class="action-list">
      <button data-action="start-assessment">${icon('check')}<span><b>ثبت ارزشیابی</b><small>ثبت فردی، گروهی یا کل کلاس</small></span>${icon('chevron')}</button>
      <button data-action="navigate" data-route="monthly">${icon('report')}<span><b>نمرات ماهانه</b><small>مستمر ماه و آرشیو دانش‌آموزان</small></span>${icon('chevron')}</button>
      <button data-action="navigate" data-route="attendance">${icon('calendar')}<span><b>حضور و غیاب</b><small>ثبت وضعیت امروز</small></span>${icon('chevron')}</button>
      <button data-action="navigate" data-route="students">${icon('users')}<span><b>دانش‌آموزان</b><small>فهرست و پرونده‌ها</small></span>${icon('chevron')}</button>
    </div></section>`;
}

function yearOptions(selected) {
  const start = Number((selected || DEFAULT_YEAR).split('/')[0]) || 405;
  const years = new Set([...Array.from({ length: 16 }, (_, index) => 403 + index), start]);
  return [...years].sort().map(year => {
    const value = `${year}/${year + 1}`;
    return `<option value="${value}" ${value === selected ? 'selected' : ''}>${formatYear(value)}</option>`;
  }).join('');
}

function newSetupDraft(mode = 'onboarding', schoolId = null) {
  const school = schoolById(schoolId);
  return {
    mode,
    step: mode === 'onboarding' ? 1 : school ? 3 : 2,
    year: selectedYear(),
    teacherName: model.profile.name || '',
    schoolId: school?.id || '',
    schoolName: school?.name || '',
    schoolCode: school?.code || '',
    province: school?.province || '',
    district: school?.district || '',
    grade: 'هفتم',
    classTitle: '',
    classCode: '',
    studentsText: '',
    savedSchoolId: school?.id || null,
    savedClassId: null,
    managerName: model.localAdmin?.managerName || '',
    pin: '',
    pinConfirm: '',
  };
}

function setupSteps(draft) {
  return draft.mode === 'onboarding'
    ? [{ n: 1, label: 'سال و دبیر' }, { n: 2, label: 'مدرسه' }, { n: 3, label: 'کلاس' }, { n: 4, label: 'دانش‌آموزان' }, { n: 5, label: 'تأیید' }]
    : draft.schoolId
      ? [{ n: 3, label: 'کلاس' }, { n: 4, label: 'دانش‌آموزان' }, { n: 5, label: 'تأیید' }]
      : [{ n: 2, label: 'مدرسه' }, { n: 3, label: 'کلاس' }, { n: 4, label: 'دانش‌آموزان' }, { n: 5, label: 'تأیید' }];
}

function onboardingView() {
  if (!state.setup) state.setup = newSetupDraft(state.params.mode || 'onboarding', state.params.schoolId || null);
  const draft = state.setup;
  const steps = setupSteps(draft);
  return `${pageHeading(draft.mode === 'onboarding' ? 'راه‌اندازی اولیه' : 'افزودن ساختار آموزشی', `مرحله ${fa(steps.findIndex(item => item.n === draft.step) + 1)} از ${fa(steps.length)}`)}
    <section class="stepper" aria-label="مراحل">${steps.map(item => `<span class="${item.n === draft.step ? 'is-current' : item.n < draft.step ? 'is-done' : ''}"><b>${fa(steps.indexOf(item) + 1)}</b><small>${esc(item.label)}</small></span>`).join('')}</section>
    <section class="form-card">${setupStage(draft)}</section>
    <div class="form-actions"><button class="secondary-button" data-action="setup-back" ${draft.step === steps[0].n ? 'disabled' : ''}>مرحله قبل</button><button class="primary-button" data-action="setup-next">${draft.step === 5 ? 'ثبت و ادامه' : 'ادامه'}</button></div>`;
}

function setupStage(draft) {
  if (draft.step === 1) return `<div class="stage-heading"><span>مرحله ۱</span><h2>سال تحصیلی و مشخصات دبیر</h2></div>
    <div class="field"><label for="setup-year">سال تحصیلی</label><select id="setup-year">${yearOptions(draft.year)}</select><small>فرمت ثابت: ${formatYear('405/406')}</small></div>
    <div class="field"><label for="setup-teacher">نام و نام خانوادگی دبیر</label><input id="setup-teacher" value="${esc(draft.teacherName)}" autocomplete="name" placeholder="مثال: امیر خالدیان"></div>`;
  if (draft.step === 2) return `<div class="stage-heading"><span>مرحله ۲</span><h2>مشخصات مدرسه</h2></div>
    <div class="field"><label for="setup-school-name">نام مدرسه</label><input id="setup-school-name" value="${esc(draft.schoolName)}" placeholder="نام رسمی مدرسه"></div>
    <div class="two-fields"><div class="field"><label for="setup-school-code">کد مدرسه</label><input id="setup-school-code" value="${esc(draft.schoolCode)}" inputmode="numeric" placeholder="اختیاری"></div><div class="field"><label for="setup-district">منطقه یا شهرستان</label><input id="setup-district" value="${esc(draft.district)}"></div></div>
    <div class="field"><label for="setup-province">استان</label><input id="setup-province" value="${esc(draft.province)}"></div>`;
  if (draft.step === 3) return `<div class="stage-heading"><span>مرحله ۳</span><h2>پایه و کلاس</h2></div>
    ${draft.schoolId ? `<div class="inline-notice">مدرسه: <b>${esc(schoolById(draft.schoolId)?.name || draft.schoolName)}</b></div>` : ''}
    <div class="two-fields"><div class="field"><label for="setup-grade">پایه</label><select id="setup-grade"><option ${draft.grade === 'هفتم' ? 'selected' : ''}>هفتم</option><option ${draft.grade === 'هشتم' ? 'selected' : ''}>هشتم</option><option ${draft.grade === 'نهم' ? 'selected' : ''}>نهم</option></select></div><div class="field"><label for="setup-class-title">نام کلاس</label><input id="setup-class-title" value="${esc(draft.classTitle)}" placeholder="مثال: ۷۰۱"></div></div>
    <div class="field"><label for="setup-class-code">کد کلاس</label><input id="setup-class-code" value="${esc(draft.classCode)}" placeholder="در صورت خالی‌بودن خودکار ساخته می‌شود"></div>`;
  if (draft.step === 4) return `<div class="stage-heading"><span>مرحله ۴</span><h2>ورود دانش‌آموزان</h2></div>
    <div class="field"><label for="setup-students">هر دانش‌آموز در یک سطر</label><textarea id="setup-students" rows="10" placeholder="علی محمدی، ۷۰۱۰۱، رضا، ۱۳۹۲/۰۲/۱۲، ۱۲۳۴۵۶۷۸۹۰">${esc(draft.studentsText)}</textarea><small>ترتیب اختیاری: نام و نام خانوادگی، شناسه، نام پدر، تاریخ تولد، کد ملی. فقط نام نیز پذیرفته می‌شود.</small></div>
    <button class="secondary-button wide" data-action="import-setup-roster">${icon('upload')} ورود از فایل CSV</button>`;
  const parsed = parseStudentLines(draft.studentsText);
  return `<div class="stage-heading"><span>مرحله نهایی</span><h2>بررسی و تأیید مدیر</h2></div>
    <div class="review-list"><div><span>سال تحصیلی</span><b>${formatYear(draft.year)}</b></div><div><span>مدرسه</span><b>${esc(draft.schoolName || schoolById(draft.schoolId)?.name || '—')}</b></div><div><span>کلاس</span><b>پایه ${esc(draft.grade)} · ${esc(draft.classTitle)}</b></div><div><span>دانش‌آموزان</span><b>${fa(parsed.length)} نفر</b></div></div>
    ${parsed.length ? `<div class="preview-list">${parsed.slice(0, 6).map(item => `<span>${esc(item.name)}</span>`).join('')}${parsed.length > 6 ? `<small>و ${fa(parsed.length - 6)} نفر دیگر</small>` : ''}</div>` : '<div class="inline-notice warning">دانش‌آموزی وارد نشده است؛ کلاس بدون دانش‌آموز ساخته می‌شود.</div>'}
    <div class="inline-notice">در حالت بدون اتصال به سیدا، ثبت یا تغییر ساختار با تأیید مدیر مدرسه انجام می‌شود.</div>
    <div class="field"><label for="setup-manager">نام مدیر یا تأییدکننده</label><input id="setup-manager" value="${esc(draft.managerName)}"></div>
    <div class="two-fields"><div class="field"><label for="setup-pin">رمز تأیید ۴ تا ۸ رقم</label><input id="setup-pin" inputmode="numeric" type="password" value="${esc(draft.pin)}"></div>${model.localAdmin?.enabled ? '' : `<div class="field"><label for="setup-pin-confirm">تکرار رمز</label><input id="setup-pin-confirm" inputmode="numeric" type="password" value="${esc(draft.pinConfirm)}"></div>`}</div>`;
}

function captureSetup() {
  const draft = state.setup;
  if (!draft) return;
  const value = id => document.querySelector(`#${id}`)?.value;
  if (draft.step === 1) {
    draft.year = value('setup-year') || draft.year;
    draft.teacherName = normalize(value('setup-teacher'));
  }
  if (draft.step === 2) {
    draft.schoolName = normalize(value('setup-school-name'));
    draft.schoolCode = normalize(value('setup-school-code'));
    draft.district = normalize(value('setup-district'));
    draft.province = normalize(value('setup-province'));
  }
  if (draft.step === 3) {
    draft.grade = value('setup-grade') || draft.grade;
    draft.classTitle = normalize(value('setup-class-title'));
    draft.classCode = normalize(value('setup-class-code'));
  }
  if (draft.step === 4) draft.studentsText = document.querySelector('#setup-students')?.value || '';
  if (draft.step === 5) { draft.managerName = normalize(document.querySelector('#setup-manager')?.value); draft.pin = en(document.querySelector('#setup-pin')?.value || ''); draft.pinConfirm = en(document.querySelector('#setup-pin-confirm')?.value || ''); }
}

function validateSetupStep(step, draft) {
  if (step === 1 && draft.teacherName.length < 3) return 'نام دبیر را کامل وارد کنید.';
  if (step === 1 && !/^\d{3}\/\d{3}$/.test(draft.year)) return 'سال تحصیلی باید مانند ۴۰۵/۴۰۶ باشد.';
  if (step === 2 && draft.schoolName.length < 3) return 'نام مدرسه را کامل وارد کنید.';
  if (step === 3 && draft.classTitle.length < 1) return 'نام کلاس را وارد کنید.';
  if (step === 5 && draft.managerName.length < 3) return 'نام مدیر یا تأییدکننده را کامل وارد کنید.';
  if (step === 5 && !/^\d{4,8}$/.test(draft.pin)) return 'رمز تأیید باید ۴ تا ۸ رقم باشد.';
  if (step === 5 && !model.localAdmin?.enabled && draft.pin !== draft.pinConfirm) return 'تکرار رمز تأیید یکسان نیست.';
  return '';
}

function parseStudentLines(text) {
  return String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean).map((line, index) => {
    const parts = line.split(/[،,;]/).map(normalize);
    const name = parts[0] || '';
    return {
      name,
      studentCode: parts[1] || '',
      fatherName: parts[2] || '',
      birthDate: parts[3] || '',
      nationalId: parts[4] || '',
      row: index + 1,
    };
  }).filter(item => item.name.length >= 2);
}


async function hashText(text) {
  const value = String(text);
  if (globalThis.crypto?.subtle) {
    const bytes = new TextEncoder().encode(value);
    const hash = await crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(hash)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  }
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return `local-${(hash >>> 0).toString(16)}`;
}

async function saveSetup() {
  const draft = state.setup;
  const pinHash = await hashText(draft.pin);
  if (model.localAdmin?.enabled && pinHash !== model.localAdmin.pinHash) throw new Error('رمز تأیید مدیر درست نیست.');
  if (!model.localAdmin?.enabled) {
    model.localAdmin = { enabled: true, managerName: draft.managerName, pinHash, createdAt: new Date().toISOString() };
    await saveLocalAdmin(model.localAdmin);
  }
  let schoolId = draft.schoolId || draft.savedSchoolId;
  if (!schoolId) {
    const duplicateSchool = model.schools.find(item => item.schoolYear === draft.year && (item.code && draft.schoolCode && normalizeKey(item.code) === normalizeKey(draft.schoolCode) || normalizeKey(item.name) === normalizeKey(draft.schoolName)));
    if (duplicateSchool) schoolId = duplicateSchool.id;
    else {
      schoolId = uuid();
      await put('schools', {
        id: schoolId, name: draft.schoolName, code: draft.schoolCode || `SCH-${Date.now().toString().slice(-5)}`,
        province: draft.province, district: draft.district, schoolYear: draft.year, active: true,
        createdAt: new Date().toISOString(),
      });
    }
  }

  const classId = uuid();
  const classCode = draft.classCode || `${draft.year.replace('/', '')}-${draft.grade.charAt(0)}-${draft.classTitle}`;
  const duplicateClass = model.classes.find(item => item.schoolId === schoolId && item.schoolYear === draft.year && (normalizeKey(item.code) === normalizeKey(classCode) || (item.grade === draft.grade && normalizeKey(item.title) === normalizeKey(draft.classTitle))));
  if (duplicateClass) throw new Error('این کلاس برای مدرسه و سال تحصیلی انتخاب‌شده قبلاً ثبت شده است.');
  await put('classes', {
    id: classId, schoolId, schoolYear: draft.year, grade: draft.grade, title: draft.classTitle,
    code: classCode, active: true, createdAt: new Date().toISOString(),
  });

  const existingStudents = model.students.filter(item => item.schoolId === schoolId && item.schoolYear === draft.year);
  const parsed = parseStudentLines(draft.studentsText);
  const accepted = [];
  const skipped = [];
  for (const [index, item] of parsed.entries()) {
    const generatedCode = item.studentCode || `${classCode}-${String(index + 1).padStart(2, '0')}`;
    const exactDuplicate = existingStudents.find(student =>
      (item.nationalId && student.nationalId && normalizeKey(student.nationalId) === normalizeKey(item.nationalId)) ||
      normalizeKey(student.studentCode) === normalizeKey(generatedCode) ||
      (normalizeKey(student.name) === normalizeKey(item.name) && item.fatherName && normalizeKey(student.fatherName) === normalizeKey(item.fatherName) && item.birthDate && student.birthDate === item.birthDate)
    );
    if (exactDuplicate) { skipped.push(item.name); continue; }
    accepted.push({
      id: uuid(), classId, schoolId, schoolYear: draft.year, name: item.name, studentCode: generatedCode,
      fatherName: item.fatherName, birthDate: item.birthDate, nationalId: item.nationalId, active: true,
      createdAt: new Date().toISOString(),
    });
  }
  await bulkPut('students', accepted);

  model.profile = { ...model.profile, name: draft.teacherName || model.profile.name };
  await saveProfile(model.profile);
  model.settings = {
    ...model.settings, onboardingDone: true, selectedYear: draft.year, selectedSchoolId: schoolId,
    selectedClassId: classId, currentMonth: model.settings.currentMonth || 'مهر',
  };
  await saveSettings(model.settings);
  await refreshModel();
  state.setup = null;
  showToast(`${fa(accepted.length)} دانش‌آموز ثبت شد${skipped.length ? `؛ ${fa(skipped.length)} مورد تکراری نادیده گرفته شد` : ''}.`, 'success');
  openDialog('ساختار ثبت شد', `<div class="success-panel">${icon('check')}<h3>${esc(draft.schoolName || schoolById(schoolId)?.name)}</h3><p>کلاس ${esc(draft.classTitle)} برای سال ${formatYear(draft.year)} آماده است.</p></div>`, `<button class="secondary-button" data-action="add-another-school">افزودن مدرسه دیگر</button><button class="primary-button" data-action="finish-setup">ورود به برنامه</button>`);
}

function structureView() {
  const schools = model.schools.filter(item => item.schoolYear === selectedYear());
  return `${pageHeading('مدارس و کلاس‌ها', `سال تحصیلی ${formatYear(selectedYear())}`, `<button class="primary-button small" data-action="new-school">${icon('plus')} مدرسه</button>`)}
    <section class="filter-bar"><label for="structure-year">سال تحصیلی</label><select id="structure-year">${yearOptions(selectedYear())}</select></section>
    ${schools.length ? `<div class="school-list">${schools.map(school => schoolCard(school)).join('')}</div>` : emptyStructure()}`;
}

function schoolCard(school) {
  const classes = model.classes.filter(item => item.schoolId === school.id && item.schoolYear === selectedYear());
  return `<article class="school-card"><header><div><h2>${esc(school.name)}</h2><p>${esc([school.district, school.province].filter(Boolean).join(' · ') || `کد ${school.code || '—'}`)}</p></div><button class="secondary-button small" data-action="new-class" data-school-id="${school.id}">${icon('plus')} کلاس</button></header>
    <div class="school-classes">${classes.length ? classes.map(cls => `<button data-action="open-class" data-id="${cls.id}"><span><b>پایه ${esc(cls.grade)} · ${esc(cls.title)}</b><small>${fa(studentsForClass(cls.id).length)} دانش‌آموز · کد ${esc(cls.code)}</small></span>${icon('chevron')}</button>`).join('') : '<div class="empty-inline">کلاسی برای این مدرسه ثبت نشده است.</div>'}</div></article>`;
}

function classView(classId) {
  const cls = classById(classId) || currentClass();
  if (!cls) return emptyStructure();
  const school = schoolById(cls.schoolId);
  const students = studentsForClass(cls.id);
  const month = currentMonth();
  const records = recordsForClass(cls.id, month);
  return `${pageHeading(`پایه ${cls.grade} · ${cls.title}`, `${school?.name || ''} · سال ${formatYear(cls.schoolYear)}`, `<button class="secondary-button small" data-action="activate-class" data-id="${cls.id}">${cls.id === model.settings.selectedClassId ? 'کلاس جاری' : 'انتخاب کلاس'}</button>`)}
    <section class="metric-grid compact"><article><span>دانش‌آموز</span><b>${fa(students.length)}</b></article><article><span>ثبت ${month}</span><b>${fa(records.length)}</b></article><article><span>مستمر ${month}</span><b>${displayScore(average(records.map(item => item.score)))}</b></article></section>
    <section class="section"><div class="action-list">
      <button data-action="class-students" data-id="${cls.id}">${icon('users')}<span><b>فهرست دانش‌آموزان</b><small>افزودن، جست‌وجو و پرونده</small></span>${icon('chevron')}</button>
      <button data-action="class-monthly" data-id="${cls.id}">${icon('report')}<span><b>نمرات ماهانه</b><small>میانگین و آرشیو ماه‌ها</small></span>${icon('chevron')}</button>
      <button data-action="class-attendance" data-id="${cls.id}">${icon('calendar')}<span><b>حضور و غیاب</b><small>ثبت وضعیت امروز</small></span>${icon('chevron')}</button>
    </div></section>`;
}

function studentsView() {
  const cls = currentClass();
  if (!cls) return emptyStructure();
  const students = studentsForClass(cls.id);
  return `${pageHeading('دانش‌آموزان', `پایه ${cls.grade} · ${cls.title}`, `<button class="primary-button small" data-action="add-student">${icon('personAdd')} افزودن</button>`)}
    <div class="search-field">${icon('users')}<input id="student-search" type="search" placeholder="جست‌وجوی نام یا شناسه"></div>
    <div id="student-list" class="student-list">${students.length ? students.map(student => studentRow(student)).join('') : '<div class="empty-state"><h2>دانش‌آموزی ثبت نشده است</h2><p>دانش‌آموزان را دستی یا با فایل CSV اضافه کنید.</p></div>'}</div>
    <button class="secondary-button wide section" data-action="import-roster" data-id="${cls.id}">${icon('upload')} ورود از CSV</button>`;
}

function studentRow(student) {
  const monthRecords = recordsForStudent(student.id, currentMonth());
  return `<button class="student-row" data-action="open-student" data-id="${student.id}" data-search="${esc(`${student.name} ${student.studentCode || ''}`)}"><span class="avatar">${esc(student.name.charAt(0))}</span><span><b>${esc(student.name)}</b><small>${esc(student.studentCode || 'بدون شناسه')} · ${fa(monthRecords.length)} ثبت در ${esc(currentMonth())}</small></span><strong>${displayScore(average(monthRecords.map(item => item.score)))}</strong>${icon('chevron')}</button>`;
}

function attendanceView() {
  const cls = currentClass();
  if (!cls) return emptyStructure();
  const students = studentsForClass(cls.id);
  const saved = model.attendance.find(item => item.classId === cls.id && item.date === today());
  return `${pageHeading('حضور و غیاب', `${fa(today())} · ${fa(students.length)} دانش‌آموز`)}
    <section class="attendance-list">${students.map(student => {
      const value = saved?.absentIds?.includes(student.id) ? 'absent' : saved?.lateIds?.includes(student.id) ? 'late' : 'present';
      return `<div class="attendance-row"><span><b>${esc(student.name)}</b><small>${esc(student.studentCode || '')}</small></span><select data-attendance="${student.id}" aria-label="وضعیت ${esc(student.name)}"><option value="present" ${value === 'present' ? 'selected' : ''}>حاضر</option><option value="late" ${value === 'late' ? 'selected' : ''}>تأخیر</option><option value="absent" ${value === 'absent' ? 'selected' : ''}>غایب</option></select></div>`;
    }).join('')}</section><div class="form-actions single"><button class="primary-button" data-action="save-attendance">ذخیره حضور و غیاب</button></div>`;
}

function createAssessmentDraft(editId = null) {
  const cls = currentClass();
  const record = editId ? model.assessments.find(item => item.id === editId) : null;
  return {
    step: record ? 4 : 1,
    editId: record?.id || null,
    classId: record?.classId || cls?.id || '',
    schoolId: record?.schoolId || cls?.schoolId || '',
    schoolYear: record?.schoolYear || selectedYear(),
    month: record?.month || currentMonth(),
    date: record?.date || today(),
    mode: record ? 'individual' : 'individual',
    targetIds: record ? [record.studentId] : [],
    domain: record?.domain || 'analysis',
    criterion: record?.criterion || Object.keys(RUBRIC_LIBRARY.analysis.criteria)[0],
    evidenceType: record?.evidenceType || 'direct',
    level: Number(record?.level || 3),
    bonus: Number(record?.bonus || 0),
    bonusReason: record?.bonusReason || '',
    note: record?.note || '',
    saved: false,
  };
}

function assessmentView() {
  const cls = currentClass();
  if (!cls) return `${pageHeading('ثبت ارزشیابی')}${emptyStructure()}`;
  if (!state.assessment) state.assessment = createAssessmentDraft(state.params.edit || null);
  const draft = state.assessment;
  if (draft.saved) return assessmentSuccess(draft);
  const labels = ['دانش‌آموز و ماه', 'معیار', 'سطح عملکرد', 'نمره نهایی'];
  return `${pageHeading('ثبت ارزشیابی', `مرحله ${fa(draft.step)} از ۴ · ${labels[draft.step - 1]}`)}
    <section class="assessment-progress"><div><span style="width:${draft.step * 25}%"></span></div><ol>${labels.map((label, index) => `<li class="${index + 1 === draft.step ? 'is-current' : index + 1 < draft.step ? 'is-done' : ''}"><b>${fa(index + 1)}</b><span>${esc(label)}</span></li>`).join('')}</ol></section>
    <section class="assessment-context">${assessmentContext(draft)}</section>
    <section class="assessment-card">${assessmentStage(draft)}</section>
    <div class="form-actions"><button class="secondary-button" data-action="assessment-back">${draft.step === 1 ? 'انصراف' : 'مرحله قبل'}</button><button class="primary-button" data-action="assessment-next">${draft.step === 4 ? (draft.editId ? 'ذخیره ویرایش' : 'ثبت نهایی') : 'ادامه'}</button></div>`;
}

function assessmentContext(draft) {
  const cls = classById(draft.classId);
  const targets = draft.targetIds.map(studentById).filter(Boolean);
  const criterion = RUBRIC_LIBRARY[draft.domain]?.criteria?.[draft.criterion];
  return `<span><b>کلاس:</b> ${esc(cls ? `${cls.grade} · ${cls.title}` : '—')}</span><span><b>ماه:</b> ${esc(draft.month)}</span><span><b>دانش‌آموز:</b> ${esc(draft.mode === 'class' ? 'کل کلاس' : targets.length ? targets.map(item => item.name).join('، ') : 'انتخاب نشده')}</span>${draft.step > 2 ? `<span><b>معیار:</b> ${esc(criterion?.title || '—')}</span>` : ''}`;
}

function assessmentStage(draft) {
  if (draft.step === 1) return assessmentStepOne(draft);
  if (draft.step === 2) return assessmentStepTwo(draft);
  if (draft.step === 3) return assessmentStepThree(draft);
  return assessmentStepFour(draft);
}

function assessmentStepOne(draft) {
  const students = studentsForClass(draft.classId);
  return `<div class="stage-heading"><span>مرحله ۱</span><h2>این نمره برای چه کسی و کدام ماه است؟</h2></div>
    <div class="two-fields"><div class="field"><label for="assessment-month">ماه ثبت</label><select id="assessment-month">${SCHOOL_MONTHS.map(month => `<option ${month === draft.month ? 'selected' : ''}>${month}</option>`).join('')}</select></div><div class="field"><label for="assessment-date">تاریخ ثبت</label><input id="assessment-date" type="date" value="${esc(draft.date)}"></div></div>
    <div class="field"><label>نوع ثبت</label><div class="segmented-control"><button data-action="assessment-mode" data-value="individual" class="${draft.mode === 'individual' ? 'is-selected' : ''}">فردی</button><button data-action="assessment-mode" data-value="group" class="${draft.mode === 'group' ? 'is-selected' : ''}">گروهی</button><button data-action="assessment-mode" data-value="class" class="${draft.mode === 'class' ? 'is-selected' : ''}">کل کلاس</button></div></div>
    ${draft.mode === 'individual' ? `<div class="field"><label for="assessment-student">دانش‌آموز</label><select id="assessment-student"><option value="">انتخاب کنید</option>${students.map(student => `<option value="${student.id}" ${draft.targetIds[0] === student.id ? 'selected' : ''}>${esc(student.name)} · ${esc(student.studentCode || '')}</option>`).join('')}</select></div>` : draft.mode === 'group' ? `<div class="field"><label>اعضای گروه</label><div class="check-list">${students.map(student => `<label><input type="checkbox" data-assessment-target value="${student.id}" ${draft.targetIds.includes(student.id) ? 'checked' : ''}><span>${esc(student.name)}</span></label>`).join('')}</div></div>` : `<div class="inline-notice">این ثبت برای همه ${fa(students.length)} دانش‌آموز فعال کلاس ذخیره می‌شود.</div>`}`;
}

function assessmentStepTwo(draft) {
  const domain = RUBRIC_LIBRARY[draft.domain] || RUBRIC_LIBRARY.analysis;
  return `<div class="stage-heading"><span>مرحله ۲</span><h2>حوزه و معیار ارزشیابی را انتخاب کنید</h2></div>
    <div class="field"><label>حوزه شایستگی</label><div class="domain-grid">${Object.entries(RUBRIC_LIBRARY).map(([key, item]) => `<button data-action="assessment-domain" data-value="${key}" class="${draft.domain === key ? 'is-selected' : ''}"><b>${esc(item.title)}</b><small>${esc(item.description)}</small></button>`).join('')}</div></div>
    <div class="field"><label>معیار دقیق</label><div class="criterion-list">${Object.entries(domain.criteria).map(([key, item]) => `<button data-action="assessment-criterion" data-value="${key}" class="${draft.criterion === key ? 'is-selected' : ''}"><span class="radio-mark"></span><span><b>${esc(item.title)}</b><small>${esc(item.question)}</small></span></button>`).join('')}</div></div>`;
}

function assessmentStepThree(draft) {
  const criterion = RUBRIC_LIBRARY[draft.domain]?.criteria?.[draft.criterion];
  return `<div class="stage-heading"><span>مرحله ۳</span><h2>سطح عملکرد مشاهده‌شده را مشخص کنید</h2><p>${esc(criterion?.question || '')}</p></div>
    <div class="field"><label>نوع شاهد</label><div class="chip-list">${EVIDENCE_TYPES.map(item => `<button data-action="assessment-evidence" data-value="${item.id}" class="${draft.evidenceType === item.id ? 'is-selected' : ''}">${esc(item.title)}</button>`).join('')}</div></div>
    <div class="level-list">${RUBRIC_LEVELS.map(level => `<button data-action="assessment-level" data-value="${level.level}" class="${draft.level === level.level ? 'is-selected' : ''}"><span class="level-score">${fa(level.score)}</span><span><b>${esc(level.title)}</b><small>${esc(level.description)}</small><em>بازه ${esc(level.range)}</em></span></button>`).join('')}</div>`;
}

function assessmentStepFour(draft) {
  const level = RUBRIC_LEVELS.find(item => item.level === draft.level) || RUBRIC_LEVELS[2];
  const bonus = draft.mode === 'individual' ? draft.bonus : 0;
  const finalScore = clamp(level.score + bonus, 0, 20);
  const targetNames = draft.mode === 'class' ? 'کل کلاس' : draft.targetIds.map(studentById).filter(Boolean).map(item => item.name).join('، ');
  return `<div class="stage-heading"><span>مرحله ۴</span><h2>نمره را بررسی و ثبت کنید</h2></div>
    <section class="score-summary"><div><span>نمره پایه</span><b>${fa(level.score)}</b></div><i>+</i><div><span>تشویقی</span><b>${fa(bonus)}</b></div><i>=</i><div class="final"><span>نمره نهایی</span><b>${fa(finalScore)}</b><small>از ۲۰</small></div></section>
    <div class="review-list"><div><span>ماه</span><b>${esc(draft.month)}</b></div><div><span>دانش‌آموز</span><b>${esc(targetNames || '—')}</b></div><div><span>معیار</span><b>${esc(RUBRIC_LIBRARY[draft.domain]?.criteria?.[draft.criterion]?.title || '—')}</b></div><div><span>سطح</span><b>${esc(level.title)}</b></div></div>
    ${draft.mode === 'individual' ? `<div class="field"><label>نمره تشویقی</label><div class="segmented-control bonus"><button data-action="assessment-bonus" data-value="0" class="${bonus === 0 ? 'is-selected' : ''}">۰</button><button data-action="assessment-bonus" data-value="0.5" class="${bonus === .5 ? 'is-selected' : ''}">۰٫۵</button><button data-action="assessment-bonus" data-value="1" class="${bonus === 1 ? 'is-selected' : ''}">۱</button><button data-action="assessment-bonus" data-value="1.5" class="${bonus === 1.5 ? 'is-selected' : ''}">۱٫۵</button><button data-action="assessment-bonus" data-value="2" class="${bonus === 2 ? 'is-selected' : ''}">۲</button></div></div>
      <div class="field"><label for="assessment-bonus-reason">دلیل تشویق ${bonus > 0 ? '<span class="required">الزامی</span>' : ''}</label><input id="assessment-bonus-reason" value="${esc(draft.bonusReason)}" placeholder="مثال: کمک مؤثر به گروه و رفع خطا"></div>` : '<div class="inline-notice">در ثبت گروهی یا کل کلاس، نمره تشویقی اعمال نمی‌شود. پس از ثبت می‌توان پرونده هر دانش‌آموز را جداگانه ویرایش کرد.</div>'}
    <div class="field"><label for="assessment-note">یادداشت معلم</label><textarea id="assessment-note" rows="3" placeholder="اختیاری">${esc(draft.note)}</textarea></div>`;
}

function captureAssessment() {
  const draft = state.assessment;
  if (!draft) return;
  if (draft.step === 1) {
    draft.month = document.querySelector('#assessment-month')?.value || draft.month;
    draft.date = document.querySelector('#assessment-date')?.value || draft.date;
    if (draft.mode === 'individual') draft.targetIds = [document.querySelector('#assessment-student')?.value].filter(Boolean);
    if (draft.mode === 'group') draft.targetIds = [...document.querySelectorAll('[data-assessment-target]:checked')].map(item => item.value);
    if (draft.mode === 'class') draft.targetIds = studentsForClass(draft.classId).map(item => item.id);
  }
  if (draft.step === 4) {
    draft.bonusReason = normalize(document.querySelector('#assessment-bonus-reason')?.value || '');
    draft.note = normalize(document.querySelector('#assessment-note')?.value || '');
  }
}

function validateAssessmentStep(draft) {
  if (draft.step === 1 && !draft.targetIds.length) return 'حداقل یک دانش‌آموز را انتخاب کنید.';
  if (draft.step === 2 && (!draft.domain || !draft.criterion)) return 'حوزه و معیار را انتخاب کنید.';
  if (draft.step === 3 && !draft.level) return 'سطح عملکرد را انتخاب کنید.';
  if (draft.step === 4 && draft.mode === 'individual' && draft.bonus > 0 && draft.bonusReason.length < 3) return 'دلیل نمره تشویقی را بنویسید.';
  return '';
}

async function saveAssessment() {
  const draft = state.assessment;
  captureAssessment();
  const error = validateAssessmentStep(draft);
  if (error) { showToast(error, 'error'); return; }
  const level = RUBRIC_LEVELS.find(item => item.level === draft.level) || RUBRIC_LEVELS[2];
  const bonus = draft.mode === 'individual' ? Number(draft.bonus || 0) : 0;
  const score = clamp(level.score + bonus, 0, 20);
  const batchId = draft.editId ? model.assessments.find(item => item.id === draft.editId)?.batchId || uuid() : uuid();
  const records = draft.targetIds.map(studentId => ({
    id: draft.editId || uuid(), batchId, studentId, classId: draft.classId, schoolId: draft.schoolId,
    schoolYear: draft.schoolYear, month: draft.month, date: draft.date, domain: draft.domain,
    criterion: draft.criterion, evidenceType: draft.evidenceType, level: draft.level,
    baseScore: level.score, bonus, bonusReason: bonus ? draft.bonusReason : '', score, note: draft.note,
    createdAt: draft.editId ? model.assessments.find(item => item.id === draft.editId)?.createdAt || new Date().toISOString() : new Date().toISOString(),
    updatedAt: new Date().toISOString(), createdBy: CURRENT_USER_ID,
  }));
  await bulkPut('assessments', records);
  model.settings.currentMonth = draft.month;
  await saveSettings(model.settings);
  await refreshModel();
  draft.saved = true;
  draft.savedCount = records.length;
  draft.savedScore = score;
  renderRoute(true);
}

function assessmentSuccess(draft) {
  return `<section class="success-page">${icon('check')}<h1>${draft.editId ? 'ویرایش ذخیره شد' : 'ارزشیابی ثبت شد'}</h1><p>${fa(draft.savedCount || 1)} ثبت برای ماه ${esc(draft.month)} با نمره ${fa(draft.savedScore)} ذخیره شد.</p><div class="button-stack"><button class="primary-button" data-action="new-assessment">ثبت بعدی</button><button class="secondary-button" data-action="navigate" data-route="monthly">مشاهده نمرات ماهانه</button><button class="text-button" data-action="navigate" data-route="home">بازگشت به خانه</button></div></section>`;
}

function monthlyView() {
  const cls = currentClass();
  if (!cls) return `${pageHeading('نمرات ماهانه')}${emptyStructure()}`;
  const month = currentMonth();
  const students = studentsForClass(cls.id);
  const records = recordsForClass(cls.id, month);
  const classAvg = average(records.map(item => item.score));
  const coverage = new Set(records.map(item => item.studentId)).size;
  return `${pageHeading('نمرات و آرشیو ماهانه', `پایه ${cls.grade} · ${cls.title}`)}
    <section class="month-picker"><button data-action="previous-month" aria-label="ماه قبل">‹</button><select id="monthly-month">${SCHOOL_MONTHS.map(item => `<option ${item === month ? 'selected' : ''}>${item}</option>`).join('')}</select><button data-action="next-month" aria-label="ماه بعد">›</button></section>
    <section class="monthly-summary"><div><span>مستمر ${esc(month)}</span><b>${displayScore(classAvg)}</b><small>میانگین همه نمرات اکتساب‌شده کلاس در این ماه</small></div><div><span>پوشش</span><b>${fa(coverage)} / ${fa(students.length)}</b><small>${fa(records.length)} ثبت</small></div></section>
    <section class="section"><div class="section-heading"><h2>مستمر دانش‌آموزان</h2><small>میانگین ثبت‌های ${esc(month)}</small></div><div class="monthly-student-list">${students.map(student => {
      const own = records.filter(item => item.studentId === student.id);
      return `<button data-action="open-student" data-id="${student.id}"><span><b>${esc(student.name)}</b><small>${own.length ? `${fa(own.length)} نمره ثبت‌شده` : 'بدون نمره در این ماه'}</small></span><strong>${displayScore(average(own.map(item => item.score)))}</strong>${icon('chevron')}</button>`;
    }).join('')}</div></section>
    <section class="section"><div class="section-heading"><h2>آرشیو ماه‌های سال</h2></div><div class="month-archive">${SCHOOL_MONTHS.map(item => {
      const monthRecords = recordsForClass(cls.id, item);
      return `<button data-action="select-month" data-value="${item}" class="${item === month ? 'is-current' : ''}"><span>${esc(item)}</span><b>${displayScore(average(monthRecords.map(record => record.score)))}</b><small>${fa(monthRecords.length)} ثبت</small></button>`;
    }).join('')}</div></section>`;
}

function studentView(studentId) {
  const student = studentById(studentId);
  if (!student) return '<div class="empty-state"><h2>دانش‌آموز پیدا نشد</h2></div>';
  const all = recordsForStudent(student.id);
  return `${pageHeading(student.name, `${student.studentCode || 'بدون شناسه'} · سال ${formatYear(student.schoolYear)}`, `<button class="primary-button small" data-action="assess-student" data-id="${student.id}">${icon('plus')} ثبت نمره</button>`)}
    <section class="month-archive student-archive">${SCHOOL_MONTHS.map(month => {
      const records = all.filter(item => item.month === month);
      return `<article><span>${esc(month)}</span><b>${displayScore(average(records.map(item => item.score)))}</b><small>${fa(records.length)} ثبت</small></article>`;
    }).join('')}</section>
    <section class="section"><div class="section-heading"><h2>سوابق ارزشیابی</h2></div><div class="record-list">${all.length ? [...all].sort((a, b) => String(b.date).localeCompare(String(a.date))).map(record => {
      const criterion = RUBRIC_LIBRARY[record.domain]?.criteria?.[record.criterion];
      return `<button data-action="edit-record" data-id="${record.id}"><span><b>${esc(record.month)} · ${esc(criterion?.title || 'ارزشیابی')}</b><small>${fa(record.date)} · ${esc(record.bonus ? `تشویقی ${fa(record.bonus)}` : 'بدون تشویقی')}</small></span><strong>${displayScore(record.score)}</strong>${icon('edit')}</button>`;
    }).join('') : '<div class="empty-inline">هنوز نمره‌ای ثبت نشده است.</div>'}</div></section>`;
}

function communityView() {
  const connected = Boolean(model.settings.apiBase) && navigator.onLine;
  const posts = [...model.content].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  return `${pageHeading('هم‌افزایی دبیران', connected ? 'متصل به شبکه سازمانی' : navigator.onLine ? 'آنلاین؛ سرور سازمانی تعریف نشده است' : 'آفلاین؛ محتوای محلی در دسترس است', `<button class="primary-button small" data-action="new-post">${icon('plus')} محتوا</button>`)}
    <section class="network-status ${connected ? 'is-connected' : ''}">${icon('cloud')}<div><b>${connected ? 'شبکه هم‌افزایی آماده است' : 'حالت محلی'}</b><p>${connected ? 'انتشار، دریافت تجربه‌ها و تعامل از طریق سرور سازمانی انجام می‌شود.' : 'کانال و محتوا روی این دستگاه ذخیره می‌شود. برای تعامل واقعی بین معلمان، نشانی سرور در تنظیمات وارد شود.'}</p></div>${!connected ? '<button class="secondary-button small" data-action="open-network-settings">تنظیم اتصال</button>' : '<button class="secondary-button small" data-action="sync-community">همگام‌سازی</button>'}</section>
    <div class="tabs"><button data-action="community-tab" data-value="feed" class="${state.communityTab === 'feed' ? 'is-selected' : ''}">تجربه‌ها</button><button data-action="community-tab" data-value="channels" class="${state.communityTab === 'channels' ? 'is-selected' : ''}">کانال‌های پادکست</button><button data-action="community-tab" data-value="mine" class="${state.communityTab === 'mine' ? 'is-selected' : ''}">محتوای من</button></div>
    ${state.communityTab === 'channels' ? channelList() : postList(state.communityTab === 'mine' ? posts.filter(item => item.authorId === CURRENT_USER_ID) : posts)}`;
}

function channelList() {
  return `<section class="section"><div class="section-heading"><h2>کانال‌های پادکست</h2><button class="text-button" data-action="new-channel">ساخت کانال</button></div><div class="channel-list">${model.channels.length ? model.channels.map(channel => {
    const episodes = model.content.filter(item => item.channelId === channel.id);
    return `<article><span class="channel-icon">${icon('podcast')}</span><div><h3>${esc(channel.title)}</h3><p>${esc(channel.description || channel.topic || 'بدون توضیح')}</p><small>${fa(episodes.length)} قسمت · ${channel.ownerId === CURRENT_USER_ID ? 'کانال من' : 'کانال دبیر'}</small></div><button class="secondary-button small" data-action="edit-channel" data-id="${channel.id}">${channel.ownerId === CURRENT_USER_ID ? 'ویرایش' : 'دنبال‌کردن'}</button></article>`;
  }).join('') : '<div class="empty-state"><h2>کانالی ساخته نشده است</h2><p>یک کانال پادکستی بسازید و تجربه‌های آموزشی را به‌صورت قسمت‌های منظم منتشر کنید.</p><button class="primary-button" data-action="new-channel">ساخت نخستین کانال</button></div>'}</div></section>`;
}

function postList(posts) {
  return `<section class="section"><div class="post-list">${posts.length ? posts.map(post => {
    const channel = model.channels.find(item => item.id === post.channelId);
    const comments = model.comments.filter(item => item.contentId === post.id);
    return `<button class="post-card" data-action="open-post" data-id="${post.id}"><span class="post-type">${post.type === 'podcast' ? icon('podcast') : icon('message')}</span><span><small>${esc(post.type === 'podcast' ? channel?.title || 'پادکست' : post.type === 'question' ? 'پرسش حرفه‌ای' : 'تجربه کلاسی')}</small><b>${esc(post.title)}</b><p>${esc(post.summary || '')}</p><em>${fa(comments.length)} گفت‌وگو · ${post.status === 'queued' ? 'در صف انتشار' : 'محلی'}</em></span>${icon('chevron')}</button>`;
  }).join('') : '<div class="empty-state"><h2>محتوایی ثبت نشده است</h2><p>تجربه، پرسش یا قسمت پادکست خود را ایجاد کنید.</p><button class="primary-button" data-action="new-post">ایجاد محتوا</button></div>'}</div></section>`;
}

function channelEditorView(channelId) {
  const channel = model.channels.find(item => item.id === channelId);
  return `${pageHeading(channel ? 'ویرایش کانال' : 'کانال پادکست جدید')}
    <form id="channel-form" class="form-card" data-id="${channel?.id || ''}"><div class="field"><label for="channel-title">نام کانال</label><input id="channel-title" value="${esc(channel?.title || '')}" maxlength="80" required></div><div class="field"><label for="channel-topic">موضوع اصلی</label><input id="channel-topic" value="${esc(channel?.topic || '')}" maxlength="100" placeholder="مثال: تجربه‌های تدریس پروژه‌های پایه هفتم"></div><div class="field"><label for="channel-description">معرفی کوتاه</label><textarea id="channel-description" rows="4" maxlength="400">${esc(channel?.description || '')}</textarea></div><button class="primary-button wide" type="submit">ذخیره کانال</button></form>`;
}

function postEditorView(postId) {
  const post = model.content.find(item => item.id === postId);
  return `${pageHeading(post ? 'ویرایش محتوا' : 'محتوای جدید')}
    <form id="post-form" class="form-card" data-id="${post?.id || ''}"><div class="two-fields"><div class="field"><label for="post-type">نوع</label><select id="post-type"><option value="experience" ${post?.type === 'experience' ? 'selected' : ''}>تجربه کلاسی</option><option value="question" ${post?.type === 'question' ? 'selected' : ''}>پرسش حرفه‌ای</option><option value="podcast" ${post?.type === 'podcast' ? 'selected' : ''}>قسمت پادکست</option></select></div><div class="field"><label for="post-channel">کانال</label><select id="post-channel"><option value="">بدون کانال</option>${model.channels.map(channel => `<option value="${channel.id}" ${post?.channelId === channel.id ? 'selected' : ''}>${esc(channel.title)}</option>`).join('')}</select></div></div><div class="field"><label for="post-title">عنوان</label><input id="post-title" value="${esc(post?.title || '')}" maxlength="120" required></div><div class="field"><label for="post-summary">خلاصه</label><textarea id="post-summary" rows="3" maxlength="350" required>${esc(post?.summary || '')}</textarea></div><div class="field"><label for="post-body">متن یا شرح قسمت</label><textarea id="post-body" rows="7" maxlength="6000">${esc(post?.body || '')}</textarea></div><div class="field"><label for="post-media-url">پیوند فایل صوتی یا ویدئویی</label><input id="post-media-url" type="url" value="${esc(post?.mediaUrl || '')}" placeholder="https://..."><small>در نسخه سروری، فایل داخل خود پلتفرم بارگذاری خواهد شد.</small></div><button class="primary-button wide" type="submit">ذخیره و آماده انتشار</button></form>`;
}

function postView(postId) {
  const post = model.content.find(item => item.id === postId);
  if (!post) return '<div class="empty-state"><h2>محتوا پیدا نشد</h2></div>';
  const comments = model.comments.filter(item => item.contentId === post.id).sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)));
  return `${pageHeading(post.title, post.type === 'podcast' ? 'قسمت پادکست' : 'تجربه و گفت‌وگوی حرفه‌ای', post.authorId === CURRENT_USER_ID ? `<button class="secondary-button small" data-action="edit-post" data-id="${post.id}">${icon('edit')} ویرایش</button>` : '')}
    <article class="post-detail"><p>${esc(post.summary || '')}</p>${post.body ? `<div>${esc(post.body).replace(/\n/g, '<br>')}</div>` : ''}${post.mediaUrl ? `<a href="${esc(post.mediaUrl)}" target="_blank" rel="noopener">بازکردن فایل رسانه‌ای</a>` : ''}</article>
    <section class="section"><div class="section-heading"><h2>گفت‌وگو</h2><small>${fa(comments.length)} پیام</small></div><div class="comment-list">${comments.map(comment => `<article><b>${esc(comment.authorName || model.profile.name || 'دبیر')}</b><p>${esc(comment.body)}</p><small>${fa(comment.createdAt.slice(0, 10))}</small></article>`).join('') || '<div class="empty-inline">هنوز گفت‌وگویی ثبت نشده است.</div>'}</div><form id="comment-form" data-id="${post.id}" class="comment-form"><input id="comment-body" placeholder="نظر یا تجربه خود را بنویسید" required><button class="primary-button small" type="submit">ارسال</button></form></section>`;
}

function settingsView() {
  const connected = Boolean(model.settings.apiBase);
  return `${pageHeading('تنظیمات', `نسخه ${APP_VERSION}`)}
    <section class="settings-list">
      <button data-action="profile-settings">${icon('user')}<span><b>مشخصات دبیر</b><small>${esc(model.profile.name || 'نام ثبت نشده')}</small></span>${icon('chevron')}</button>
      <button data-action="network-settings">${icon('cloud')}<span><b>اتصال هم‌افزایی</b><small>${connected ? 'نشانی سرور ثبت شده است' : 'سرور سازمانی تعریف نشده'}</small></span>${icon('chevron')}</button>
      <button data-action="backup-center">${icon('download')}<span><b>پشتیبان و بازیابی</b><small>حفاظت از داده‌های محلی</small></span>${icon('chevron')}</button>
      <button data-action="appearance-settings">${icon('settings')}<span><b>نمایش</b><small>${model.settings.theme === 'dark' ? 'حالت تیره' : 'حالت روشن'}</small></span>${icon('chevron')}</button>
    </section>
    <section class="danger-zone"><h2>مدیریت داده‌ها</h2><button class="danger-button" data-action="clear-data">${icon('trash')} حذف کامل اطلاعات این دستگاه</button></section>
    <div class="version-line">نسخه برنامه ${esc(APP_VERSION)} · روبریک ${esc(RUBRIC_VERSION)}</div>`;
}

function helpView() {
  return `${pageHeading('راهنمای استفاده')}
    <section class="help-list"><article><b>۱. انتخاب سال و کلاس</b><p>از منوی همبرگری، مدرسه و کلاس جاری را تغییر دهید. همه نمرات با سال تحصیلی و ماه ذخیره می‌شوند.</p></article><article><b>۲. ثبت ارزشیابی</b><p>چهار مرحله را به‌ترتیب انجام دهید: دانش‌آموز و ماه، معیار، سطح عملکرد و نمره نهایی.</p></article><article><b>۳. مستمر ماهانه</b><p>مستمر هر ماه میانگین همه نمرات اکتساب‌شده همان ماه است. آرشیو ماه‌ها در صفحه «ماهانه» و پرونده دانش‌آموز دیده می‌شود.</p></article><article><b>۴. هم‌افزایی</b><p>کانال و محتوا در حالت آفلاین محلی‌اند. تعامل واقعی بین معلمان نیازمند اتصال برنامه به سرور سازمانی است.</p></article></section>`;
}

function openDialog(title, body, footer = '') {
  dialog.innerHTML = `<div class="dialog-shell"><header><h2>${esc(title)}</h2><button class="icon-button" data-action="close-dialog" aria-label="بستن">${icon('close')}</button></header><div class="dialog-body">${body}</div>${footer ? `<footer>${footer}</footer>` : ''}</div>`;
  if (!dialog.open) dialog.showModal();
}

function closeDialog() {
  if (dialog.open) dialog.close();
  dialog.innerHTML = '';
}

function contextDialog() {
  const year = selectedYear();
  const schools = model.schools.filter(item => item.schoolYear === year);
  const schoolId = currentSchool()?.id || schools[0]?.id || '';
  const classes = model.classes.filter(item => item.schoolId === schoolId && item.schoolYear === year);
  openDialog('انتخاب سال، مدرسه و کلاس', `<div class="field"><label for="context-year">سال تحصیلی</label><select id="context-year">${yearOptions(year)}</select></div><div class="field"><label for="context-school">مدرسه</label><select id="context-school"><option value="">انتخاب مدرسه</option>${schools.map(item => `<option value="${item.id}" ${item.id === schoolId ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select></div><div class="field"><label for="context-class">کلاس</label><select id="context-class"><option value="">انتخاب کلاس</option>${classes.map(item => `<option value="${item.id}" ${item.id === model.settings.selectedClassId ? 'selected' : ''}>پایه ${esc(item.grade)} · ${esc(item.title)}</option>`).join('')}</select></div>`, '<button class="secondary-button" data-action="close-dialog">انصراف</button><button class="primary-button" data-action="save-context">تأیید</button>');
}

function addStudentDialog() {
  openDialog('افزودن دانش‌آموز', `<div class="field"><label for="student-name">نام و نام خانوادگی</label><input id="student-name"></div><div class="two-fields"><div class="field"><label for="student-code">شناسه دانش‌آموز</label><input id="student-code"></div><div class="field"><label for="student-father">نام پدر</label><input id="student-father"></div></div><div class="two-fields"><div class="field"><label for="student-birth">تاریخ تولد</label><input id="student-birth" placeholder="۱۳۹۲/۰۲/۱۲"></div><div class="field"><label for="student-national">کد ملی</label><input id="student-national" inputmode="numeric"></div></div>`, '<button class="secondary-button" data-action="close-dialog">انصراف</button><button class="primary-button" data-action="save-student">ذخیره</button>');
}

function profileDialog() {
  openDialog('مشخصات دبیر', `<div class="field"><label for="profile-name">نام و نام خانوادگی</label><input id="profile-name" value="${esc(model.profile.name || '')}"></div><div class="field"><label for="profile-role">عنوان</label><input id="profile-role" value="${esc(model.profile.roleLabel || 'دبیر کار و فناوری')}"></div>`, '<button class="secondary-button" data-action="close-dialog">انصراف</button><button class="primary-button" data-action="save-profile">ذخیره</button>');
}

function networkDialog() {
  openDialog('اتصال شبکه هم‌افزایی', `<div class="inline-notice">GitHub Pages فقط میزبان رابط است. برای دیدن تجربه‌های سایر معلمان، حساب کاربری و سرور مرکزی لازم است.</div><div class="field"><label for="api-base">نشانی سرور سازمانی</label><input id="api-base" type="url" value="${esc(model.settings.apiBase || '')}" placeholder="https://api.example.ir"><small>پس از راه‌اندازی سرور رسمی وارد شود. نشانی آزمایشی یا ناشناس وارد نکنید.</small></div>`, '<button class="secondary-button" data-action="close-dialog">انصراف</button><button class="primary-button" data-action="save-network">ذخیره اتصال</button>');
}

async function backupDialog() {
  const info = await storageInfo();
  openDialog('پشتیبان و بازیابی', `<div class="settings-list compact"><button data-action="export-backup">${icon('download')}<span><b>دریافت فایل پشتیبان</b><small>مدارس، کلاس‌ها، دانش‌آموزان و نمرات</small></span>${icon('chevron')}</button><button data-action="import-backup">${icon('upload')}<span><b>بازیابی پشتیبان</b><small>ادغام فایل با داده‌های فعلی</small></span>${icon('chevron')}</button><button data-action="persist-storage">${icon('check')}<span><b>درخواست نگهداری پایدار</b><small>${info.persisted ? 'فعال است' : 'برای کاهش خطر پاک‌شدن داده‌ها'}</small></span>${icon('chevron')}</button></div>`);
}

function appearanceDialog() {
  openDialog('نمایش برنامه', `<div class="field"><label for="appearance-theme">حالت رنگ</label><select id="appearance-theme"><option value="light" ${model.settings.theme !== 'dark' ? 'selected' : ''}>روشن</option><option value="dark" ${model.settings.theme === 'dark' ? 'selected' : ''}>تیره</option></select></div>`, '<button class="secondary-button" data-action="close-dialog">انصراف</button><button class="primary-button" data-action="save-appearance">اعمال</button>');
}

async function saveAttendance() {
  const cls = currentClass();
  const selects = [...document.querySelectorAll('[data-attendance]')];
  await put('attendance', {
    id: `${cls.id}-${today()}`, classId: cls.id, schoolId: cls.schoolId, schoolYear: cls.schoolYear,
    date: today(), absentIds: selects.filter(item => item.value === 'absent').map(item => item.dataset.attendance),
    lateIds: selects.filter(item => item.value === 'late').map(item => item.dataset.attendance), updatedAt: new Date().toISOString(),
  });
  await refreshModel();
  showToast('حضور و غیاب ذخیره شد.', 'success');
}

async function saveStudent() {
  const cls = currentClass();
  const name = normalize(dialog.querySelector('#student-name')?.value);
  const code = normalize(dialog.querySelector('#student-code')?.value) || `${cls.code}-${String(studentsForClass(cls.id).length + 1).padStart(2, '0')}`;
  const fatherName = normalize(dialog.querySelector('#student-father')?.value);
  const birthDate = normalize(dialog.querySelector('#student-birth')?.value);
  const nationalId = normalize(dialog.querySelector('#student-national')?.value);
  if (name.length < 2) { showToast('نام دانش‌آموز را کامل وارد کنید.', 'error'); return; }
  const duplicate = model.students.find(item => item.schoolId === cls.schoolId && item.schoolYear === cls.schoolYear && (
    normalizeKey(item.studentCode) === normalizeKey(code) ||
    (nationalId && item.nationalId && normalizeKey(item.nationalId) === normalizeKey(nationalId)) ||
    (normalizeKey(item.name) === normalizeKey(name) && fatherName && normalizeKey(item.fatherName) === normalizeKey(fatherName) && birthDate && item.birthDate === birthDate)
  ));
  if (duplicate) { showToast('این دانش‌آموز قبلاً در همین سال تحصیلی ثبت شده است.', 'error'); return; }
  await put('students', { id: uuid(), classId: cls.id, schoolId: cls.schoolId, schoolYear: cls.schoolYear, name, studentCode: code, fatherName, birthDate, nationalId, active: true, createdAt: new Date().toISOString() });
  closeDialog();
  await refreshModel();
  renderRoute();
  showToast('دانش‌آموز اضافه شد.', 'success');
}

async function saveChannel() {
  const form = document.querySelector('#channel-form');
  const title = normalize(document.querySelector('#channel-title')?.value);
  if (title.length < 3) { showToast('نام کانال را کامل وارد کنید.', 'error'); return; }
  const id = form.dataset.id || uuid();
  const existing = model.channels.find(item => item.id === id);
  await put('channels', {
    ...existing, id, ownerId: CURRENT_USER_ID, title, topic: normalize(document.querySelector('#channel-topic')?.value),
    description: normalize(document.querySelector('#channel-description')?.value), createdAt: existing?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(),
  });
  await refreshModel();
  state.communityTab = 'channels';
  navigate('community', {}, { replace: true });
  showToast('کانال ذخیره شد.', 'success');
}

async function savePost() {
  const form = document.querySelector('#post-form');
  const title = normalize(document.querySelector('#post-title')?.value);
  const summary = normalize(document.querySelector('#post-summary')?.value);
  if (title.length < 3 || summary.length < 5) { showToast('عنوان و خلاصه را کامل وارد کنید.', 'error'); return; }
  const id = form.dataset.id || uuid();
  const existing = model.content.find(item => item.id === id);
  const queued = Boolean(model.settings.apiBase);
  const post = {
    ...existing, id, authorId: CURRENT_USER_ID, authorName: model.profile.name || 'دبیر',
    type: document.querySelector('#post-type')?.value || 'experience', channelId: document.querySelector('#post-channel')?.value || '',
    title, summary, body: normalize(document.querySelector('#post-body')?.value), mediaUrl: document.querySelector('#post-media-url')?.value?.trim() || '',
    status: queued ? 'queued' : 'local', createdAt: existing?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(),
  };
  await put('content', post);
  if (queued) await put('syncQueue', { id: uuid(), entity: 'content', entityId: id, operation: existing ? 'update' : 'create', status: 'pending', createdAt: new Date().toISOString() });
  await refreshModel();
  navigate('community', {}, { replace: true });
  showToast(queued ? 'محتوا در صف همگام‌سازی قرار گرفت.' : 'محتوا روی این دستگاه ذخیره شد.', 'success');
}

async function saveComment(contentId) {
  const body = normalize(document.querySelector('#comment-body')?.value);
  if (body.length < 2) { showToast('متن گفت‌وگو را وارد کنید.', 'error'); return; }
  const comment = { id: uuid(), contentId, authorId: CURRENT_USER_ID, authorName: model.profile.name || 'دبیر', body, createdAt: new Date().toISOString(), status: model.settings.apiBase ? 'queued' : 'local' };
  await put('comments', comment);
  if (model.settings.apiBase) await put('syncQueue', { id: uuid(), entity: 'comment', entityId: comment.id, operation: 'create', status: 'pending', createdAt: new Date().toISOString() });
  await refreshModel();
  renderRoute();
}

async function exportBackup() {
  const payload = await exportDatabase({ includeMedia: false });
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `hamyar-backup-${today()}.karo.json`;
  link.click();
  URL.revokeObjectURL(url);
}

async function importBackup(file) {
  const payload = JSON.parse(await file.text());
  await importDatabase(payload, { mode: 'merge' });
  closeDialog();
  await refreshModel();
  renderRoute();
  showToast('پشتیبان بازیابی شد.', 'success');
}

async function handleRosterFile(file) {
  const text = await file.text();
  const lines = text.split(/\r?\n/).filter(Boolean);
  const cls = pendingRosterClassId ? classById(pendingRosterClassId) : currentClass();
  if (!cls) return;
  const rows = lines.slice(lines[0]?.includes('name') || lines[0]?.includes('نام') ? 1 : 0).map(line => {
    const parts = line.split(',').map(normalize);
    return { name: parts[0], studentCode: parts[1], fatherName: parts[2], birthDate: parts[3], nationalId: parts[4] };
  }).filter(item => item.name);
  const existing = model.students.filter(item => item.schoolId === cls.schoolId && item.schoolYear === cls.schoolYear);
  const accepted = [];
  for (const [index, row] of rows.entries()) {
    const code = row.studentCode || `${cls.code}-${String(index + 1).padStart(2, '0')}`;
    const duplicate = existing.find(item => normalizeKey(item.studentCode) === normalizeKey(code) || (row.nationalId && item.nationalId && normalizeKey(item.nationalId) === normalizeKey(row.nationalId)));
    if (!duplicate) accepted.push({ id: uuid(), classId: cls.id, schoolId: cls.schoolId, schoolYear: cls.schoolYear, ...row, studentCode: code, active: true, createdAt: new Date().toISOString() });
  }
  await bulkPut('students', accepted);
  await refreshModel();
  renderRoute();
  showToast(`${fa(accepted.length)} دانش‌آموز وارد شد.`, 'success');
}

async function syncCommunity() {
  if (!navigator.onLine) { showToast('اتصال اینترنت برقرار نیست.', 'error'); return; }
  const base = String(model.settings.apiBase || '').replace(/\/$/, '');
  if (!base) { networkDialog(); return; }
  const pending = model.syncQueue.filter(item => item.status === 'pending');
  try {
    const response = await fetch(`${base}/v1/community/sync`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ profile: model.profile, channels: model.channels, content: model.content, comments: model.comments, queue: pending }),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    await bulkPut('channels', payload.channels || []);
    await bulkPut('content', payload.content || []);
    await bulkPut('comments', payload.comments || []);
    await bulkPut('syncQueue', pending.map(item => ({ ...item, status: 'done', syncedAt: new Date().toISOString() })));
    await refreshModel();
    renderRoute();
    showToast('هم‌افزایی به‌روز شد.', 'success');
  } catch (error) {
    console.error(error);
    showToast('سرور هم‌افزایی پاسخ نداد. اطلاعات محلی حفظ شد.', 'error');
  }
}

async function handleAction(element) {
  const action = element.dataset.action;
  if (action === 'navigate') navigate(element.dataset.route);
  else if (action === 'toggle-drawer') { state.drawerOpen = !state.drawerOpen; renderDrawer(); }
  else if (action === 'close-drawer') { state.drawerOpen = false; renderDrawer(); }
  else if (action === 'back') goBack();
  else if (action === 'start-onboarding') { state.setup = newSetupDraft('onboarding'); navigate('onboarding'); }
  else if (action === 'new-school') { state.setup = newSetupDraft('add-school'); navigate('onboarding', { mode: 'add-school' }); }
  else if (action === 'new-class') { state.setup = newSetupDraft('add-class', element.dataset.schoolId); navigate('onboarding', { mode: 'add-class', schoolId: element.dataset.schoolId }); }
  else if (action === 'setup-back') { captureSetup(); const steps = setupSteps(state.setup); const index = steps.findIndex(item => item.n === state.setup.step); if (index > 0) { state.setup.step = steps[index - 1].n; renderRoute(true); } }
  else if (action === 'setup-next') {
    captureSetup();
    const error = validateSetupStep(state.setup.step, state.setup);
    if (error) { showToast(error, 'error'); return; }
    if (state.setup.step === 5) await saveSetup();
    else { const steps = setupSteps(state.setup); const index = steps.findIndex(item => item.n === state.setup.step); state.setup.step = steps[index + 1].n; renderRoute(true); }
  }
  else if (action === 'add-another-school') { closeDialog(); state.setup = newSetupDraft('add-school'); navigate('onboarding', { mode: 'add-school' }, { replace: true }); }
  else if (action === 'finish-setup') { closeDialog(); navigate('home', {}, { replace: true }); }
  else if (action === 'import-setup-roster') { pendingRosterClassId = null; rosterFile.dataset.setup = 'true'; rosterFile.click(); }
  else if (action === 'open-context') contextDialog();
  else if (action === 'close-dialog') closeDialog();
  else if (action === 'save-context') {
    const year = dialog.querySelector('#context-year')?.value || selectedYear();
    const schoolId = dialog.querySelector('#context-school')?.value || null;
    const classId = dialog.querySelector('#context-class')?.value || null;
    model.settings = { ...model.settings, selectedYear: year, selectedSchoolId: schoolId, selectedClassId: classId };
    await saveSettings(model.settings); closeDialog(); await refreshModel(); renderRoute();
  }
  else if (action === 'open-class') navigate('class', { id: element.dataset.id });
  else if (action === 'activate-class') { const cls = classById(element.dataset.id); model.settings = { ...model.settings, selectedYear: cls.schoolYear, selectedSchoolId: cls.schoolId, selectedClassId: cls.id }; await saveSettings(model.settings); await refreshModel(); renderRoute(); showToast('کلاس جاری تغییر کرد.', 'success'); }
  else if (action === 'class-students') { const cls = classById(element.dataset.id); model.settings.selectedClassId = cls.id; await saveSettings(model.settings); await refreshModel(); navigate('students'); }
  else if (action === 'class-monthly') { const cls = classById(element.dataset.id); model.settings.selectedClassId = cls.id; await saveSettings(model.settings); await refreshModel(); navigate('monthly'); }
  else if (action === 'class-attendance') { const cls = classById(element.dataset.id); model.settings.selectedClassId = cls.id; await saveSettings(model.settings); await refreshModel(); navigate('attendance'); }
  else if (action === 'add-student') addStudentDialog();
  else if (action === 'save-student') await saveStudent();
  else if (action === 'import-roster') { pendingRosterClassId = element.dataset.id || currentClass()?.id; delete rosterFile.dataset.setup; rosterFile.click(); }
  else if (action === 'open-student') navigate('student', { id: element.dataset.id });
  else if (action === 'assess-student') { state.assessment = createAssessmentDraft(); state.assessment.targetIds = [element.dataset.id]; navigate('assessment'); }
  else if (action === 'edit-record') { state.assessment = createAssessmentDraft(element.dataset.id); navigate('assessment', { edit: element.dataset.id }); }
  else if (action === 'save-attendance') await saveAttendance();
  else if (action === 'start-assessment') { state.assessment = createAssessmentDraft(); navigate('assessment'); }
  else if (action === 'assessment-mode') { state.assessment.mode = element.dataset.value; state.assessment.targetIds = state.assessment.mode === 'class' ? studentsForClass(state.assessment.classId).map(item => item.id) : []; renderRoute(); }
  else if (action === 'assessment-domain') { state.assessment.domain = element.dataset.value; state.assessment.criterion = Object.keys(RUBRIC_LIBRARY[state.assessment.domain].criteria)[0]; renderRoute(); }
  else if (action === 'assessment-criterion') { state.assessment.criterion = element.dataset.value; renderRoute(); }
  else if (action === 'assessment-evidence') { state.assessment.evidenceType = element.dataset.value; renderRoute(); }
  else if (action === 'assessment-level') { state.assessment.level = Number(element.dataset.value); renderRoute(); }
  else if (action === 'assessment-bonus') { state.assessment.bonus = Number(element.dataset.value); renderRoute(); }
  else if (action === 'assessment-back') { if (state.assessment.step === 1) { state.assessment = null; navigate('home', {}, { replace: true }); } else { captureAssessment(); state.assessment.step -= 1; renderRoute(true); } }
  else if (action === 'assessment-next') { captureAssessment(); const error = validateAssessmentStep(state.assessment); if (error) { showToast(error, 'error'); return; } if (state.assessment.step === 4) await saveAssessment(); else { state.assessment.step += 1; renderRoute(true); } }
  else if (action === 'new-assessment') { state.assessment = createAssessmentDraft(); renderRoute(true); }
  else if (action === 'previous-month' || action === 'next-month') { const index = SCHOOL_MONTHS.indexOf(currentMonth()); const next = action === 'previous-month' ? Math.max(0, index - 1) : Math.min(SCHOOL_MONTHS.length - 1, index + 1); state.monthlyMonth = SCHOOL_MONTHS[next]; model.settings.currentMonth = state.monthlyMonth; await saveSettings(model.settings); renderRoute(); }
  else if (action === 'select-month') { state.monthlyMonth = element.dataset.value; model.settings.currentMonth = state.monthlyMonth; await saveSettings(model.settings); renderRoute(true); }
  else if (action === 'community-tab') { state.communityTab = element.dataset.value; renderRoute(); }
  else if (action === 'new-channel') navigate('channel-editor');
  else if (action === 'edit-channel') navigate('channel-editor', { id: element.dataset.id });
  else if (action === 'new-post') navigate('post-editor');
  else if (action === 'edit-post') navigate('post-editor', { id: element.dataset.id });
  else if (action === 'open-post') navigate('post', { id: element.dataset.id });
  else if (action === 'open-network-settings' || action === 'network-settings') networkDialog();
  else if (action === 'sync-community') await syncCommunity();
  else if (action === 'profile-settings') profileDialog();
  else if (action === 'save-profile') { const name = normalize(dialog.querySelector('#profile-name')?.value); if (name.length < 3) { showToast('نام را کامل وارد کنید.', 'error'); return; } model.profile = { ...model.profile, name, roleLabel: normalize(dialog.querySelector('#profile-role')?.value) || 'دبیر کار و فناوری' }; await saveProfile(model.profile); closeDialog(); await refreshModel(); renderRoute(); }
  else if (action === 'save-network') { model.settings.apiBase = dialog.querySelector('#api-base')?.value?.trim() || ''; await saveSettings(model.settings); closeDialog(); await refreshModel(); renderRoute(); showToast('تنظیم اتصال ذخیره شد.', 'success'); }
  else if (action === 'backup-center') await backupDialog();
  else if (action === 'export-backup') await exportBackup();
  else if (action === 'import-backup') backupFile.click();
  else if (action === 'persist-storage') { const ok = await requestPersistentStorage(); showToast(ok ? 'نگهداری پایدار فعال شد.' : 'مرورگر درخواست را نپذیرفت.', ok ? 'success' : 'normal'); }
  else if (action === 'appearance-settings') appearanceDialog();
  else if (action === 'save-appearance') { model.settings.theme = dialog.querySelector('#appearance-theme')?.value || 'light'; await saveSettings(model.settings); closeDialog(); await refreshModel(); renderRoute(); }
  else if (action === 'clear-data') openDialog('حذف کامل اطلاعات', '<div class="inline-notice warning">این عملیات مدارس، کلاس‌ها، دانش‌آموزان و همه نمرات این دستگاه را حذف می‌کند.</div><div class="field"><label for="delete-confirm">برای تأیید بنویسید: حذف کامل</label><input id="delete-confirm"></div>', '<button class="secondary-button" data-action="close-dialog">انصراف</button><button class="danger-button" data-action="confirm-clear">حذف کامل</button>');
  else if (action === 'confirm-clear') { if (normalize(dialog.querySelector('#delete-confirm')?.value) !== 'حذف کامل') { showToast('عبارت تأیید درست نیست.', 'error'); return; } await clearAll(); closeDialog(); await ensureSeed(); await refreshModel(); state.setup = newSetupDraft('onboarding'); navigate('onboarding', {}, { replace: true }); }
  else if (action === 'apply-update' && pendingServiceWorker) pendingServiceWorker.postMessage({ type: 'SKIP_WAITING' });
}

app.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (!element || element.disabled) return;
  event.preventDefault();
  handleAction(element).catch(error => { console.error(error); showToast(error.message || 'عملیات انجام نشد.', 'error'); });
});

dialog.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (!element || element.disabled) return;
  event.preventDefault();
  handleAction(element).catch(error => { console.error(error); showToast(error.message || 'عملیات انجام نشد.', 'error'); });
});

dialog.addEventListener('cancel', event => { event.preventDefault(); closeDialog(); });

app.addEventListener('input', event => {
  if (event.target.id === 'student-search') {
    const query = normalize(event.target.value);
    document.querySelectorAll('#student-list [data-search]').forEach(row => { row.hidden = query && !normalize(row.dataset.search).includes(query); });
  }
  if (event.target.id === 'assessment-bonus-reason' && state.assessment) state.assessment.bonusReason = event.target.value;
  if (event.target.id === 'assessment-note' && state.assessment) state.assessment.note = event.target.value;
  if (event.target.id === 'setup-students' && state.setup) state.setup.studentsText = event.target.value;
});

app.addEventListener('change', async event => {
  if (event.target.id === 'structure-year') {
    model.settings.selectedYear = event.target.value;
    model.settings.selectedSchoolId = null;
    model.settings.selectedClassId = null;
    await saveSettings(model.settings);
    await refreshModel();
    renderRoute();
  }
  if (event.target.id === 'monthly-month') {
    state.monthlyMonth = event.target.value;
    model.settings.currentMonth = state.monthlyMonth;
    await saveSettings(model.settings);
    renderRoute();
  }
});

dialog.addEventListener('change', event => {
  if (event.target.id === 'context-year') {
    const year = event.target.value;
    const schools = model.schools.filter(item => item.schoolYear === year);
    const schoolSelect = dialog.querySelector('#context-school');
    const classSelect = dialog.querySelector('#context-class');
    schoolSelect.innerHTML = '<option value="">انتخاب مدرسه</option>' + schools.map(item => `<option value="${item.id}">${esc(item.name)}</option>`).join('');
    classSelect.innerHTML = '<option value="">انتخاب کلاس</option>';
  }
  if (event.target.id === 'context-school') {
    const year = dialog.querySelector('#context-year')?.value || selectedYear();
    const classes = model.classes.filter(item => item.schoolYear === year && item.schoolId === event.target.value);
    dialog.querySelector('#context-class').innerHTML = '<option value="">انتخاب کلاس</option>' + classes.map(item => `<option value="${item.id}">پایه ${esc(item.grade)} · ${esc(item.title)}</option>`).join('');
  }
});

app.addEventListener('submit', event => {
  event.preventDefault();
  if (event.target.id === 'channel-form') saveChannel().catch(error => showToast(error.message, 'error'));
  if (event.target.id === 'post-form') savePost().catch(error => showToast(error.message, 'error'));
  if (event.target.id === 'comment-form') saveComment(event.target.dataset.id).catch(error => showToast(error.message, 'error'));
});

backupFile.addEventListener('change', async () => {
  if (backupFile.files[0]) await importBackup(backupFile.files[0]);
  backupFile.value = '';
});

rosterFile.addEventListener('change', async () => {
  const file = rosterFile.files[0];
  if (!file) return;
  if (rosterFile.dataset.setup === 'true' && state.setup) {
    const text = await file.text();
    state.setup.studentsText = text.split(/\r?\n/).filter(Boolean).slice(text.split(/\r?\n/)[0]?.includes('name') || text.split(/\r?\n/)[0]?.includes('نام') ? 1 : 0).map(line => line.split(',').join('، ')).join('\n');
    renderRoute();
  } else await handleRosterFile(file);
  rosterFile.value = '';
});

window.addEventListener('popstate', event => {
  if (event.state?.route && ROUTES.has(event.state.route)) { state.route = event.state.route; state.params = event.state.params || {}; }
  else parseLocation();
  if (state.route !== 'assessment') state.assessment = null;
  if (state.route !== 'onboarding') state.setup = null;
  state.drawerOpen = false;
  renderRoute(true);
});

window.addEventListener('online', () => { document.querySelector('.topbar-title span')?.replaceChildren('آنلاین'); showToast('اتصال اینترنت برقرار شد.'); });
window.addEventListener('offline', () => { document.querySelector('.topbar-title span')?.replaceChildren('آفلاین'); showToast('برنامه آفلاین است؛ ثبت محلی ادامه دارد.'); });

async function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  try {
    const registration = await navigator.serviceWorker.register('./service-worker.js?v=2.1.0-rc1', { scope: './', updateViaCache: 'none' });
    if (registration.waiting) { pendingServiceWorker = registration.waiting; state.updateReady = true; renderUpdateBanner(); }
    registration.addEventListener('updatefound', () => {
      const worker = registration.installing;
      worker?.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) { pendingServiceWorker = registration.waiting || worker; state.updateReady = true; renderUpdateBanner(); }
      });
    });
    let reloading = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (!reloading) { reloading = true; location.reload(); } });
  } catch (error) { console.warn('Service worker registration failed', error); }
}

async function init() {
  await ensureSeed();
  await refreshModel();
  parseLocation();
  if (!model.settings.onboardingDone && !model.classes.length) {
    state.route = 'onboarding';
    state.setup = newSetupDraft('onboarding');
  } else if (model.classes.length && !model.settings.onboardingDone) {
    model.settings.onboardingDone = true;
    await saveSettings(model.settings);
  }
  history.replaceState({ route: state.route, params: state.params }, '', routeUrl(state.route, state.params));
  renderShell();
  renderRoute();
  await registerServiceWorker();
}

init().catch(error => {
  console.error(error);
  app.innerHTML = `<div class="fatal-error"><h1>راه‌اندازی برنامه ناموفق بود</h1><p>${esc(error.message || 'خطای ناشناخته')}</p><button onclick="location.reload()">تلاش دوباره</button></div>`;
});
